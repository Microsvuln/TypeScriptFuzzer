import { cubicIn } from "./index";
export = cubicIn;
