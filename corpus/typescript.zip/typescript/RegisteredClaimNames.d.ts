export const ISSUER: string;
export const SUBJECT: string;
export const AUDIENCE: string;
export const EXPIRATION_TIME: string;
export const NOT_BEFORE: string;
export const ISSUED_AT: string;
export const JWT_ID: string;
