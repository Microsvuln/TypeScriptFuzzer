export function normalizeString(str: string): string;

export function getSubstringIndex(str: string, substr: string, ignoreAccents?: boolean): number;
