export default class Locations {
    constructor(gl: WebGLRenderingContext, program: WebGLProgram);
}
