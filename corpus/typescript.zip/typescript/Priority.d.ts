export interface Priority {
    max: 'max';
    high: 'high';
    default: 'default';
    low: 'low';
    min: 'min';
}
