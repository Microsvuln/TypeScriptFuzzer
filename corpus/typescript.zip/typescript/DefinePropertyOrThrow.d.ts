import DefinePropertyOrThrow = require('../2015/DefinePropertyOrThrow');
export = DefinePropertyOrThrow;
