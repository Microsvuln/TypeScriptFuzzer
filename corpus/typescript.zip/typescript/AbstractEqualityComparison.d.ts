declare function AbstractEqualityComparison(x: unknown, y: unknown): boolean;
export = AbstractEqualityComparison;
