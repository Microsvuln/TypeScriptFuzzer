declare module "cli-check-node"
