import { RefractorSyntax } from '../core';
declare const lang: RefractorSyntax;
export = lang;
