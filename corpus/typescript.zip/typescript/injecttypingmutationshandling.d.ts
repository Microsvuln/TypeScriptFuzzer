import { Editor } from "@ckeditor/ckeditor5-core";

export default function injectTypingMutationsHandling(editor: Editor): void;
