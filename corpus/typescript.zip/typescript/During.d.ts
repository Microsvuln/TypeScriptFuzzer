import Comparison from './Comparison';

export default class During extends Comparison {
    constructor(propertyName: string, begin: string, end: string);
}
