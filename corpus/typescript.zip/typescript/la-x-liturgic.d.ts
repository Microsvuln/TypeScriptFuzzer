import { PatternsDefinition } from "..";

/** The hyphenation patterns definition for this language. */
declare const patterns: PatternsDefinition;

export = patterns;
