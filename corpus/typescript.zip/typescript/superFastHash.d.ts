declare function _exports(str: string): number;
export = _exports;
