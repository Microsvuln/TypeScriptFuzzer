declare function _exports(ds: any, fieldNames: string[]): number;
export = _exports;
