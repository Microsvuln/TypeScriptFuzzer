import urljoin = require("url-join");
import urljoin2 = require("url-join");

const s: string = urljoin("foo", "bar", "baz");
const s2: string = urljoin2("foo", "bar", "baz");
