declare const words: readonly string[];

export = words;
