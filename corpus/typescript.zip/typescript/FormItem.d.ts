import * as React from "react";
import { ReactDivAttr } from "../../../typings/shared";

export interface FormItemProps extends  ReactDivAttr { }

declare const FormItem: React.FC<FormItemProps>;

export default FormItem;
