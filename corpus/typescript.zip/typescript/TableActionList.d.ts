import * as React from "react";
import { ReactDivAttr } from "../../../typings/shared";

export interface TableActionListProps extends ReactDivAttr { }

declare const TableActionList: React.FC<TableActionListProps>;

export default TableActionList;
