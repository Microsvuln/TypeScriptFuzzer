function main() {
    const v2 = [
        407694.49019308784,
        407694.49019308784,
        407694.49019308784,
        407694.49019308784,
        407694.49019308784
    ];
    const v3 = [];
    let v4 = v3;
    function v5(v6, v7) {
        const v10 = [
            13.37,
            13.37,
            13.37,
            13.37,
            13.37
        ];
        const v11 = [];
        let v12 = v11;
        function v13(v14, v15) {
            const v19 = {
                a: 1447909605,
                d: 'asyncIterator'
            };
            const v20 = {
                a: v19,
                b: 13.37
            };
            const v24 = [
                1337,
                -1000000,
                -1000000,
                -1000000,
                -1000000
            ];
            const v25 = [];
            let v26 = v25;
            function v27(v28, v29) {
                const v32 = [
                    13.37,
                    13.37,
                    13.37,
                    13.37,
                    13.37
                ];
                const v33 = [];
                let v34 = v33;
                function v35(v36, v37) {
                    let v40 = 0;
                    const v44 = [
                        13.37,
                        13.37,
                        13.37,
                        13.37,
                        13.37
                    ];
                    let v45 = 1337;
                    function v46(v47, v48) {
                        for (let v53 = 0; v53 < 100; v53++) {
                            let v55 = Float32Array;
                            const v56 = v55.__proto__;
                            try {
                                const v57 = v56.of();
                            } catch (v58) {
                            }
                        }
                        let v62 = 0;
                        const v63 = v62 + 1;
                        v62 = v63;
                        let v66 = 0;
                        const v69 = v66 + 1;
                        v66 = v69;
                    }
                    const v70 = [];
                    let v71 = v70;
                    const v72 = v46(...v71, v45, ...v44, 10, 13.37);
                    const v79 = v40 + 1;
                    v40 = v79;
                }
                const v80 = [];
                let v81 = v80;
                const v82 = v35(...v81, v34, ...v32, 10, 13.37);
            }
            const v83 = [];
            let v84 = v83;
            const v85 = v27(...v84, v26, ...v24, 10, v20);
        }
        const v86 = [];
        let v87 = v86;
        const v88 = v13(...v87, v12, ...v10, 10, 13.37);
    }
    const v89 = [];
    let v90 = v89;
    const v91 = v5(...v90, v4, ...v2, 10, 407694.49019308784);
}
main();