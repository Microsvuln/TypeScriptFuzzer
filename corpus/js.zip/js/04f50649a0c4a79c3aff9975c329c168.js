function main() {
    for (let v3 = 0; v3 != 8; v3++) {
        let v5 = -3479607989;
        function v9(v10, v11, v12, v13) {
            const v18 = [
                1337,
                1337,
                1337
            ];
            const v19 = [
                13.37,
            ];
            const v20 = {};
            const v21 = {
                constructor: v18,
                valueOf: 'split',
                c: v20,
                a: 1337,
                e: v19
            };
            let v22 = v21;
            const v24 = new Uint8Array(v22);
            v24[0] = 0;
        }
        for (let v29 = 0; v29 < 100; v29++) {
            const v30 = v9(1337, v5, -1024, 0);
        }
    }
}
main();