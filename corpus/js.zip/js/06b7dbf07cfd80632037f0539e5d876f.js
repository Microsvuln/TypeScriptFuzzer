var networks = [
    'Facebook',
    'Twitter',
    'GooglePlus'
];
var loggedInCount = 0;
var twitterLoggedIn = false;
var facebookLoggedIn = false;
var googleLoggedIn = false;
function show_login_status(network, status) {
    if (status) {
        $('#' + network + 'Status').html('You are currently logged in to <span class=\'red\'>' + network + '</span>');
    } else {
        $('#' + network + 'Status').html('You are not currently logged in to <span class=\'green\'>' + network + '</span>');
    }
    var i = networks.indexOf(network);
    if (i >= 0)
        networks.splice(i, 1);
    if (status) {
        ++loggedInCount;
        switch (network) {
        case 'Twitter':
            $('#rb-tw').removeAttr('disabled');
            twitterLoggedIn = true;
            break;
        case 'Facebook':
            $('#rb-fb').removeAttr('disabled');
            facebookLoggedIn = true;
            break;
        case 'GooglePlus':
            $('#rb-gp').removeAttr('disabled');
            googleLoggedIn = true;
            break;
        }
    } else {
        switch (network) {
        case 'Twitter':
            $('#rb-tw').attr('disabled', 'disabled');
            twitterLoggedIn = false;
            break;
        case 'Facebook':
            $('#rb-fb').attr('disabled', 'disabled');
            facebookLoggedIn = false;
            break;
        case 'GooglePlus':
            $('#rb-gp').attr('disabled', 'disabled');
            googleLoggedIn = false;
            break;
        }
    }
    if (networks.length == 0) {
        var cookieFacebook = $.cookie('facebook-checked');
        var cookieTwitter = $.cookie('twitter-checked');
        var cookieGoogle = $.cookie('google-checked');
        if (cookieFacebook) {
            console.log('Facebook Cookie exists');
        }
        if (cookieTwitter) {
            console.log('Twitter Cookie exists');
        }
        if (cookieGoogle) {
            console.log('Google Cookie exists');
        }
        if (facebookLoggedIn && cookieFacebook == null) {
            console.log('starting facebook script');
            $.cookie('facebook-checked', 'true');
            $.startFacebook();
        } else if (twitterLoggedIn && cookieTwitter == null) {
            console.log('starting twitter 2 script');
            $.startTwitter();
        } else if (googleLoggedIn && cookieGoogle == null) {
            console.log('starting google+ script');
            $.startGoogle();
        } else {
            console.log('all cookies set. nothing left to do.');
        }
    }
}