function main() {
    const v2 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v3 = [];
    let v4 = v3;
    function v5(v6, v7) {
        let v9 = 0;
        while (v9 < 13.37) {
            const v10 = v9 + 1;
            for (let v14 = 0; v14 < 10; v14++) {
                const v15 = [];
                let v16 = v15;
                let v18 = Float32Array;
                const v19 = v18.__proto__;
                try {
                    v19.__proto__ = v16;
                    const v23 = v19.of();
                } catch (v24) {
                }
                let v27 = 0;
            }
            v9 = v10;
            let v33 = 0;
            const v34 = v33 + 1;
            v33 = v34;
        }
    }
    const v35 = [];
    let v36 = v35;
    const v37 = v5(...v36, v4, ...v2, 10, 13.37);
}
main();