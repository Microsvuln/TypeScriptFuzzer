try {
    var __str = 'She sells seashells by the seashore.';
    var __re = /sh/g;
    if (__str.replace(__re, '$`' + 'sch') !== 'She sells seaShe sells seaschells by the seaShe sells seashells by the seaschore.') {
        testFailed('#1: var __str = \'She sells seashells by the seashore.\'; var __re = /sh/g; __str.replace(__re, "$`" + \'sch\')===\'She sells seaShe sells seaschells by the seaShe sells seashells by the seaschore.\'. Actual: ' + __str.replace(__re, '$`' + 'sch'));
    }
} catch (ex) {
    sputnikException = ex;
}
var successfullyParsed = true;