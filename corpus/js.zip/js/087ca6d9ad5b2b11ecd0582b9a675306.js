console.time('create');
for (var i = 0; i < 1000; i++) {
}
console.timeEnd('create');
console.time('invoke');
for (var i = 0; i < 10000000; i++) {
}
console.timeEnd('invoke');
var signature0 = function (a, b) {
    return 'a is a number, b is a string';
};
var signature1 = function (a, b) {
    return 'a is a number, b is a number';
};
var test0 = function (x) {
    return typeof x === 'number';
};
var test1 = function (x) {
    return typeof x === 'string';
};
var createError = function () {
    console.log('Error');
};
function fn2(arg0, arg1) {
    'use strict';
    if (test0(arg0)) {
        if (test1(arg1)) {
            if (arguments.length === 2) {
                return signature0(arg0, arg1);
            }
            if (arguments.length > 2) {
                throw createError('', [
                    arg0,
                    arg1
                ], 2);
            }
        }
        if (test0(arg1)) {
            if (arguments.length === 2) {
                return signature1(arg0, arg1);
            }
            if (arguments.length > 2) {
                throw createError('', [
                    arg0,
                    arg1
                ], 2);
            }
        }
        throw createError('', [
            arg0,
            arg1
        ], 1, 'string,number');
    }
    throw createError('', [
        arg0,
        arg1
    ], 0, 'number');
}
console.time('invoke2');
for (var i = 0; i < 10000000; i++) {
    var res = fn2(2, 'foo');
}
console.timeEnd('invoke2');
function fn3(arg0, arg1) {
    'use strict';
    if (typeof arg0 === 'number') {
        if (typeof arg1 === 'string') {
            if (arguments.length === 2) {
                return signature0(arg0, arg1);
            }
            if (arguments.length > 2) {
                throw createError('', [
                    arg0,
                    arg1
                ], 2);
            }
        }
        if (typeof arg1 === 'number') {
            if (arguments.length === 2) {
                return signature1(arg0, arg1);
            }
            if (arguments.length > 2) {
                throw createError('', [
                    arg0,
                    arg1
                ], 2);
            }
        }
        throw createError('', [
            arg0,
            arg1
        ], 1, 'string,number');
    }
    throw createError('', [
        arg0,
        arg1
    ], 0, 'number');
}
console.time('invoke3');
for (var i = 0; i < 10000000; i++) {
    var res = fn3(2, 'foo');
}
console.timeEnd('invoke3');