function main() {
    const v2 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    try {
        const v7 = [
            1337,
            1337,
            1337
        ];
        const v10 = { get: gc };
        const v12 = Object.defineProperty(v7, 3880591546, v10);
        const v13 = { set: gc };
        const v15 = Object.defineProperty(v7, 255, v13);
        const v16 = {
            getPrototypeOf: gc,
            ownKeys: Object,
            setPrototypeOf: isFinite,
            defineProperty: gc,
            construct: Object,
            set: gc,
            call: Object,
            preventExtensions: Object
        };
        const v18 = new Proxy(isFinite, v16);
        const v20 = [
            -441746.4139016614,
            -441746.4139016614,
            -441746.4139016614,
            -441746.4139016614,
            -441746.4139016614
        ];
        const v21 = [];
        let v22 = v21;
        function v23(v24, v25) {
            const v27 = v7.splice(10, 1337, v18, v2);
        }
        const v28 = [];
        let v29 = v28;
        const v30 = v23(...v29, ...v22, ...v20, 1337, -441746.4139016614);
    } catch (v31) {
    }
}
main();