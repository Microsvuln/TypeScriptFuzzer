var data = new Uint8Array(256);
var wabx = new Map([
    [
        -9007199254740994,
        -2147483649,
        data['244'],
        3037000498
    ],
    [
        1.7976931348623157e+308,
        data['229'],
        data['184'],
        data['166'],
        9007199254740991
    ]
]);
var NQAm = new Uint8ClampedArray([
    data['42'],
    -4294967297,
    0.1
]);
var XkDz = new Array([]);
for (i = 0; i < 256; i++)
    data[i] = 65;
f = new Function('vuln=(function(){  "use asm";  function f(i){   for(i=0;i<0x10000;i++){     var a= new Uint8Array(data);     with(a[0]){};   }  }  return f;})();');
var nRpf = +-Infinity;
data['227'] = 1518500249 <= -9007199254740992;
var ymFa = !-1;
data = nRpf.valueOf();
var EDpt = ~NaN;
var ZMki = new ArrayBuffer(data['115']);
var xZZP = new Uint8Array([
    4294967297,
    -4294967295,
    -4294967297,
    data['84'],
    data['189'],
    4294967297
]);
var baKb = +-1;