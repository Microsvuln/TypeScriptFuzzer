if (!globalsearchformaction) {
    var globalsearchformaction = '';
}
var defaultQuery = '\uFFFD\uFFFD\uFFFD\uFFFD\uFFFD\uFFFD\uFFFDѯ\uFFFD\uFFFD';
var manulQuery = '\uFFFD\uFFFD\uFFFD\uFFFDŮ\uFFFD\uFFFD\uFFFD\uFFFD';
var tabIdx = 2;
function showTag(n) {
    tabIdx = n;
    var hasContent = 1;
    for (var i = 1; i <= 7; i++) {
        if (i == n) {
            getObject('tag' + i).className = 'tagThis hand';
            if (getObject('scontent' + i))
                getObject('scontent' + i).style.display = '';
            else
                hasContent = 0;
            switchSearch(n);
            globalsearchformaction = document.searchform.action;
        } else {
            getObject('tag' + i).className = 'tagOut hand';
            if (getObject('scontent' + i))
                getObject('scontent' + i).style.display = 'none';
        }
    }
    if (hasContent == 0)
        getObject('scontent2').style.display = '';
}
function transTag(n) {
    if (getObject('tag' + n).className != 'tagThis hand') {
        getObject('tag' + n).className = 'tagTrans hand';
    }
}
function transTagOut(n) {
    if (getObject('tag' + n).className != 'tagThis hand') {
        getObject('tag' + n).className = 'tagOut hand';
    }
}
function s(o) {
    var w = getObject('searchform').query;
    if (w.value.length > 0 && w.value != defaultQuery && w.value != manulQuery) {
        var h = o.href;
        var q = encodeURIComponent(w.value);
        if (h.indexOf('kw=') > 0) {
            o.href = h.replace(new RegExp('kw=[^&$]*'), 'kw=' + q);
        } else {
            if (h.indexOf('?') > 0) {
                o.href += '&kw=' + q;
            } else {
                o.href += '?kw=' + q;
            }
        }
    }
}
;
function switchSearch(n) {
    if (n) {
        var sf = getObject('searchform');
        var pid = getObject('pid');
        var rid = getObject('rid');
        var po = getObject('po');
        var md = getObject('saymd');
        var sayname = getObject('sayname');
        switch (n) {
        case 1:
            sf.action = 'http://news.sogou.com/news';
            pid.value = '01040301';
            rid.value = '03999999';
            po.value = '';
            md.value = '';
            sayname.value = '';
            with (sf.query) {
                if (value == '' || value == manulQuery) {
                    value = defaultQuery;
                    style.color = '#666';
                }
            }
            break;
        case 2:
            sf.action = 'http://www.sogou.com/sohu';
            pid.value = '01040100';
            rid.value = '01999999';
            md.value = '';
            po.value = '';
            sayname.value = '';
            with (sf.query) {
                if (value == '' || value == defaultQuery) {
                    value = manulQuery;
                    style.color = '#666';
                }
            }
            break;
        case 3:
            sf.action = 'http://mp3.sogou.com/music.so';
            pid.value = '01040200';
            rid.value = '02999999';
            md.value = '';
            po.value = '';
            sayname.value = '';
            with (sf.query) {
                if (value == '' || value == manulQuery) {
                    value = defaultQuery;
                    style.color = '#666';
                }
            }
            break;
        case 4:
            sf.action = 'http://pic.sogou.com/pics';
            pid.value = '01040501';
            rid.value = '05999999';
            md.value = '';
            po.value = '';
            sayname.value = '';
            with (sf.query) {
                if (value == '' || value == manulQuery) {
                    value = defaultQuery;
                    style.color = '#666';
                }
            }
            break;
        case 5:
            sf.action = 'http://map.sogou.com/new';
            pid.value = '01040400';
            rid.value = '04999999';
            po.value = '';
            with (sf.query) {
                if (value == '' || value == manulQuery) {
                    value = defaultQuery;
                    style.color = '#666';
                }
            }
            break;
        case 6:
            sf.action = 'http://v.sogou.com/v';
            pid.value = '01040600';
            rid.value = '06999999';
            md.value = '';
            po.value = '';
            sayname.value = '';
            with (sf.query) {
                if (value == '' || value == manulQuery) {
                    value = defaultQuery;
                    style.color = '#666';
                }
            }
            break;
        case 7:
            sf.action = 'http://zhishi.sogou.com/zhishi';
            pid.value = '01040800';
            rid.value = '08999999';
            md.value = '';
            po.value = '';
            sayname.value = '';
            with (sf.query) {
                if (value == '' || value == manulQuery) {
                    value = defaultQuery;
                    style.color = '#666';
                }
            }
            break;
        }
    }
}