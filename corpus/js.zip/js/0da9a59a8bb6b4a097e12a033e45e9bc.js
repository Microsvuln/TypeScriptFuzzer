function main() {
    for (let v4 = 0; v4 < 1337; v4 = v4 + 13.37) {
        const v5 = 'y16nxE/PQ8'.indexOf(v4, 0);
    }
}
main();