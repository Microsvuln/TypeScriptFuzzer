try {
    var __condition = 0, __odds = 0;
    __evaluated = eval('while(__condition < 10) { __condition++; if (((\'\'+__condition/2).split(\'.\')).length>1) continue; __odds++;}');
    if (__odds !== 5) {
        testFailed('#1: __odds === 5. Actual:  __odds ===' + __odds);
    }
    if (__evaluated !== 4) {
        testFailed('#2: __evaluated === 4. Actual:  __evaluated ===' + __evaluated);
    }
} catch (ex) {
    sputnikException = ex;
}
var successfullyParsed = true;