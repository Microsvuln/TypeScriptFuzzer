function main() {
    const v2 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v3 = [];
    let v4 = v3;
    function v5(v6, v7) {
        let v10 = 0;
        while (v10 < 10) {
            const v12 = [
                1337,
                1337,
                1337,
                1337,
                1337
            ];
            const v13 = [];
            let v14 = v13;
            const v16 = [
                1337,
                1337,
                1337,
                1337,
                1337
            ];
            for (const v17 of v16) {
            }
            try {
                for (const v18 of v12) {
                    const v20 = { get: v18 };
                    const v22 = Object.defineProperty(v13, 'd', v20);
                }
            } catch (v23) {
            }
            let v26 = 0;
            while (v26 < 9) {
                if (v7) {
                } else {
                }
                for (let v30 = 0; v30 < 10; v30++) {
                    for (let v34 = 0; v34 < 100; v34++) {
                    }
                    const v36 = [
                        1337,
                        1337,
                        1337,
                        1337,
                        1337
                    ];
                    for (const v37 in v36) {
                    }
                }
                const v38 = v26 + 1;
                v26 = v38;
            }
            const v39 = v14[1000];
            for (let v43 = 0; v43 < 8; v43++) {
                for (let v47 = 0; v47 < 5; v47++) {
                }
            }
            const v48 = v10 + 1;
            v10 = v48;
        }
    }
    const v49 = [];
    let v50 = v49;
    const v51 = v5(...v50, v4, ...v2, 10, 13.37);
}
main();