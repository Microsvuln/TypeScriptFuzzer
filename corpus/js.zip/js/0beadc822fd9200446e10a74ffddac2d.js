function main() {
    const v2 = String.fromCodePoint(1337);
    const v4 = v2.padEnd(1337, v2);
    const v6 = {
        b: 0,
        e: String
    };
    const v7 = v6[v4];
}
main();