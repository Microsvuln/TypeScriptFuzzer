function getQuery(name) {
    var regex = new RegExp('[?&]' + name.replace(/[\-\/\\\^$*+?.()|\[\]{}]/g, '\\$&') + '=([^&]*)(?:$|&)', 'i');
}
var callback = getQuery('callback');
if (callback && parent.window[callback]) {
    parent.window[callback](JSON.parse(getQuery('data')));
}