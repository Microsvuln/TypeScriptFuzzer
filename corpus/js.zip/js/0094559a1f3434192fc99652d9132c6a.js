function main() {
    const v2 = [
        -195200.749232491,
        -195200.749232491,
        -195200.749232491,
        -195200.749232491,
        -195200.749232491
    ];
    const v3 = [];
    let v4 = v3;
    function v5(v6, v7) {
        let v10 = 0;
        while (v10 < 10) {
            let v14 = 0;
            const v15 = Math + 1;
            v14 = v15;
            const v16 = Math.exp(v14);
            for (let v19 = 0; v19 < 8; v19++) {
                for (let v23 = 0; v23 < 5; v23++) {
                }
            }
            const v24 = v10 + 1;
            v10 = v24;
        }
    }
    const v25 = [];
    let v26 = v25;
    const v27 = v5(...v26, v4, ...v2, 10, -195200.749232491);
}
main();