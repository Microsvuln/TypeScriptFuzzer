function main() {
    const v2 = [
        13.37,
        13.37
    ];
    const v4 = [1337];
    const v5 = [
        1337,
        13.37,
        'caller',
        v2
    ];
    const v7 = typeof 1337;
    const v9 = v7 === 'object';
    let v10 = 'object';
    let v16 = 0;
    const v17 = v16 + 1;
    v16 = v17;
    let v21 = 0;
    for (let v29 = 0; v29 < 10; v29++) {
        v10 = v21;
        const v32 = 'p76QI.ipnu' >> 10;
        const v33 = 'p76QI.ipnu'.split('p76QI.ipnu', 10);
        const v34 = [
            v33,
            v33,
            v32
        ];
        const v36 = [
            13.37,
            13.37,
            13.37,
            13.37,
            13.37
        ];
        let v40 = 10;
        const v41 = v34 + 1;
        v40 = 'p76QI.ipnu';
        const v42 = v34.__proto__;
        v40 = v36;
    }
}
main();