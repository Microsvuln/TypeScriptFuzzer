function main() {
    const v12 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v13 = [];
    let v14 = v13;
    function v15(v16, v17) {
        const v19 = [1337];
        for (let v23 = 0; v23 < 100; v23++) {
            const v24 = typeof v19;
            const v26 = v24 > 'xtL*kGMU/q';
            const v31 = {
                valueOf: 1000000000,
                d: -2191938590,
                __proto__: 'boolean',
                c: 1337
            };
            function v32(v33, v34, v35) {
            }
            for (let v44 = 0; v44 < 100; v44++) {
                const v45 = v32(v31);
            }
            v19.d = v26;
            let v47 = v26;
            while (v47 > 4) {
            }
        }
    }
    const v50 = [];
    let v51 = v50;
    const v52 = v15(...v51, v14, ...v12, 212695203, 13.37);
}
main();