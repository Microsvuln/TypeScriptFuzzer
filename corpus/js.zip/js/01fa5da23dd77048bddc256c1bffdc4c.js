var dst_data = [];
var base_ms = 1383454200000;
for (var x = base_ms; x < base_ms + 1000 * 60 * 80; x += 1000) {
    dst_data.push([
        new Date(x),
        x
    ]);
}
var base_ms_spring = 1299999000000;
var dst_data_spring = [];
for (var x = base_ms_spring; x < base_ms_spring + 1000 * 60 * 80; x += 1000) {
    dst_data_spring.push([
        new Date(x),
        x
    ]);
}