;
(function () {
    function scoper(css) {
        var id = generateID();
        var prefix = '#' + id;
        css = css.replace(/\/\*[\s\S]*?\*\//g, '');
        var re = new RegExp('([^\r\n,{}]+)(,(?=[^}]*{)|s*{)', 'g');
        css = css.replace(re, function (g0, g1, g2) {
            if (g1.match(/^\s*(@media|@keyframes|to|from|@font-face)/)) {
                return g1 + g2;
            }
            if (g1.match(/:scope/)) {
                g1 = g1.replace(/([^\s]*):scope/, function (h0, h1) {
                    if (h1 === '') {
                        return '> *';
                    } else {
                        return '> ' + h1;
                    }
                });
            }
            g1 = g1.replace(/^(\s*)/, '$1' + prefix + ' ');
            return g1 + g2;
        });
        addStyle(css, id + '-style');
        return id;
    }
    function generateID() {
        var id = ('scoped' + Math.random()).replace('0.', '');
        if (document.getElementById(id)) {
            return generateID();
        } else {
            return id;
        }
    }
    var isIE = function () {
    }();
    function addStyle(cssText, id) {
        var d = document, someThingStyles = d.createElement('style');
        d.getElementsByTagName('head')[0].appendChild(someThingStyles);
        someThingStyles.setAttribute('type', 'text/css');
        someThingStyles.setAttribute('id', id);
        if (isIE) {
            someThingStyles.styleSheet.cssText = cssText;
        } else {
            someThingStyles.textContent = cssText;
        }
    }
}());
