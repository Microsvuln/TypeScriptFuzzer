function main() {
    let v2 = 0;
    do {
        const v5 = [
            13.37,
            13.37,
            13.37,
            13.37,
            13.37
        ];
        const v6 = [];
        let v7 = v6;
        function v8(v9, v10) {
            const v13 = [
                13.37,
                13.37,
                13.37
            ];
            const v14 = new Set(v13);
            const v15 = v14.has();
            const v18 = new Uint32Array(11105);
            for (const v19 of v18) {
            }
        }
        const v20 = [];
        let v21 = v20;
        const v22 = v8(...v21, v7, ...v5, 10, 13.37);
        const v23 = v2 + 1;
        v2 = v23;
    } while (v2 < 10);
}
main();