function main() {
    for (let v5 = -2; v5 < 1000; v5++) {
        try {
            const v6 = [];
            let v8 = v5;
            const v10 = [
                13.37,
                13.37,
                13.37,
                v8,
                13.37
            ];
            let v11 = v5;
            function v12(v13, v14) {
                let v17 = String;
                const v18 = v17.fromCharCode(1000, v5, 1337, v5, 255);
                const v19 = eval(v18);
            }
            let v20 = v6;
            const v21 = v12(...v20, v11, ...v10, 1000, 13.37);
        } catch (v22) {
        }
    }
}
main();