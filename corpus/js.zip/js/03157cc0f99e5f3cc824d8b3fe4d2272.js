var min_date = new Date();
var max_date = new Date();
min_date.setFullYear(min_date.getFullYear() - 2);
max_date.setFullYear(max_date.getFullYear() + 2);