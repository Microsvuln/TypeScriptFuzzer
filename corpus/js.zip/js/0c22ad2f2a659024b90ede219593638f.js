function main() {
    const v2 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v3 = [];
    let v4 = v3;
    function v5(v6, v7) {
        const v12 = {
            valueOf: 13.37,
            d: -2191938590,
            __proto__: 'ldq5vGcKyJ',
            c: 128
        };
        function v13(v14, v15, v16) {
            const v18 = 128 in WeakMap;
            let v20 = arguments;
        }
        for (let v24 = -65535; v24 < 100; v24++) {
            const v25 = v13(v12);
        }
    }
    const v26 = [];
    let v27 = v26;
    const v28 = v5(...v27, v4, ...v2, 10, 13.37);
}
main();