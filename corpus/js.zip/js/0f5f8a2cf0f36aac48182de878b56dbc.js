try {
    function getPrecision(num) {
        log2num = Math.log(Math.abs(num)) / Math.LN2;
        pernum = Math.ceil(log2num);
        return 2 * Math.pow(2, -52 + pernum);
    }
    var prec;
    function isEqual(num1, num2) {
        if (num1 === Infinity && num2 === Infinity) {
            return true;
        }
        if (num1 === -Infinity && num2 === -Infinity) {
            return true;
        }
        prec = getPrecision(Math.min(Math.abs(num1), Math.abs(num2)));
        return Math.abs(num1 - num2) <= prec;
    }
    y = +0;
    x = new Array();
    x[0] = -1e-15;
    x[2] = -Infinity;
    x[1] = -1;
    xnum = 3;
    for (i = 0; i < xnum; i++) {
        if (!isEqual(Math.atan2(y, x[i]), Math.PI))
            testFailed('#1: Math.abs(Math.atan2(' + y + ', ' + x[i] + ') - Math.PI) >= ' + prec);
    }
} catch (ex) {
    sputnikException = ex;
}
var successfullyParsed = true;