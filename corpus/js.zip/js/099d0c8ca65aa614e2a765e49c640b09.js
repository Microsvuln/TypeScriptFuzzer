var arr = [];
for (var i = 0; i < 28000; i++) {
    arr.push(new RegExp('prefix' + i.toString() + i.toString() + i.toString()));
}