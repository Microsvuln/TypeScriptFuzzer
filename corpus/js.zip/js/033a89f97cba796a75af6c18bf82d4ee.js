function main() {
    const v2 = [
        1337,
        1337,
        1337,
        1337,
        1337
    ];
    const v3 = [];
    const v4 = {
        b: 536870912,
        valueOf: 1337,
        d: 1337,
        a: v2
    };
    const v5 = {
        b: v4,
        valueOf: v3,
        constructor: v4,
        e: v3
    };
    let v6 = v5;
    for (let v13 = 0; v13 < 100; v13++) {
        let v15 = undefined;
        const v21 = [
            1337,
            1337,
            1337,
            1337
        ];
        const v22 = {
            e: '0MS*nEwLSL',
            valueOf: v21
        };
    }
    const v25 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v26 = [];
    let v27 = v26;
    function v28(v29, v30) {
        let v33 = 0;
        while (v33 < 10) {
            for (let v37 = 0; v37 < 8; v37++) {
                for (let v41 = 0; v41 < 5; v41++) {
                    const v44 = new Int8Array(1);
                }
            }
            const v45 = v33 + 1;
            v33 = v45;
        }
    }
    const v46 = [];
    let v47 = v46;
    const v54 = typeof v28;
    const v56 = v54 === 'undefined';
    const v57 = v28(...v47, v27, ...v25, 10, 13.37);
}
main();