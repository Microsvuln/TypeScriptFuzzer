function main() {
    const v2 = new Float64Array(65537);
    const v3 = v2.buffer;
    const v4 = v2.set(v2);
}
main();