function main() {
    const v2 = new Uint8Array(64111);
    try {
        const v5 = [
            -441746.4139016614,
            -441746.4139016614,
            -441746.4139016614,
            -441746.4139016614,
            -441746.4139016614
        ];
        const v6 = [];
        let v7 = v6;
        function v8(v9, v10) {
            const v13 = [
                719904.8518018327,
                719904.8518018327,
                719904.8518018327,
                719904.8518018327,
                719904.8518018327
            ];
            let v17 = v7;
            function v18(v19, v20) {
                delete 1553479343[v20];
                const v22 = [
                    13.37,
                    13.37,
                    13.37
                ];
                const v25 = [
                    -280462.64487138006,
                    -280462.64487138006
                ];
                const v26 = [
                    Uint8Array,
                    v25
                ];
                const v27 = v26.toLocaleString();
                const v29 = [
                    -283826799,
                    -283826799,
                    v27,
                    -283826799,
                    -283826799
                ];
                const v32 = new Int8Array('boolean');
                const v34 = v27 + 1;
                v32[v29] = v34;
                const v36 = {
                    __proto__: -1225146152,
                    d: v32
                };
                const v39 = [
                    v36,
                    1337,
                    1337
                ];
                const v40 = {
                    toString: v39,
                    c: 'nD5oAVnhbb'
                };
                const v41 = [v40];
                const v42 = [v41];
                const v43 = [v42];
                const v45 = JSON.stringify(v43, JSON, v42);
                const v46 = eval(v45);
                const v48 = [
                    13.37,
                    13.37,
                    13.37,
                    13.37
                ];
                for (const v49 of v2) {
                    const v50 = { c: 719904.8518018327 };
                }
                v10.toString = v22;
                let v52 = 0;
                const v55 = [
                    1000,
                    1000,
                    v18,
                    'Mlfj0iZP0R'
                ];
                const v57 = [
                    -2.220446049250313e-16,
                    v55
                ];
                const v58 = v57.toLocaleString();
                const v59 = v58.substring(1000, 128);
                const v60 = eval(v59);
            }
            const v61 = [];
            let v62 = v61;
            const v63 = v18(...v62, v17, ...v13, 10, 719904.8518018327);
        }
        const v64 = [];
        let v65 = v64;
        const v66 = v8(...v65, ...v7, ...v5, 1337, -441746.4139016614);
    } catch (v67) {
    }
}
main();