function main() {
    let v2 = 0;
    while (v2 < 255) {
        const v5 = [
            13.37,
            13.37,
            13.37,
            13.37,
            13.37
        ];
        function v6(v7, v8) {
            let v10 = 0;
            const v13 = new Int16Array(eval);
            const v15 = Math.max(13.37, v10);
            const v18 = [
                13.37,
                13.37,
                13.37,
                13.37,
                13.37
            ];
            const v19 = [];
            let v20 = v19;
            function v21(v22, v23) {
            }
            const v24 = [];
            let v25 = v24;
            const v26 = v21(...v25, v20, ...v18, 1337, 13.37);
        }
        const v27 = v6(13.37, v5);
        const v28 = v2 + 1;
        v2 = v28;
    }
}
main();