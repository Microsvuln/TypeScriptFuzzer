(function () {
    var k = this, m = function (a, b) {
            var c = a.split('.'), d = k;
            c[0] in d || !d.execScript || d.execScript('var ' + c[0]);
            for (var e; c.length && (e = c.shift());)
                c.length || void 0 === b ? d = d[e] ? d[e] : d[e] = {} : d[e] = b;
        }, n = function (a) {
            return 'string' == typeof a;
        }, q = function (a, b) {
            function c() {
            }
            c.prototype = b.prototype;
            a.i = b.prototype;
            a.prototype = new c();
        };
    var r = function (a) {
        Error.captureStackTrace ? Error.captureStackTrace(this, r) : this.stack = Error().stack || '';
        a && (this.message = String(a));
    };
    q(r, Error);
    var ba = function (a, b) {
        for (var c = a.split('%s'), d = '', e = Array.prototype.slice.call(arguments, 1); e.length && 1 < c.length;)
            d += c.shift() + e.shift();
        return d + c.join('%s');
    };
    var s = function (a, b) {
        b.unshift(a);
        r.call(this, ba.apply(null, b));
        b.shift();
    };
    q(s, r);
    var ca = function (a, b, c) {
        if (!a) {
            var d = Array.prototype.slice.call(arguments, 2), e = 'Assertion failed';
            if (b)
                var e = e + (': ' + b), f = d;
            throw new s('' + e, f || []);
        }
    };
    var t = Array.prototype, da = t.indexOf ? function (a, b, c) {
            ca(null != a.length);
            return t.indexOf.call(a, b, c);
        } : function (a, b, c) {
            c = null == c ? 0 : 0 > c ? Math.max(0, a.length + c) : c;
            if (n(a))
                return n(b) && 1 == b.length ? a.indexOf(b, c) : -1;
            for (; c < a.length; c++)
                if (c in a && a[c] === b)
                    return c;
            return -1;
        };
    var u, v, w, x, z = function () {
            return k.navigator ? k.navigator.userAgent : null;
        };
    x = w = v = u = !1;
    var A;
    if (A = z()) {
        var ea = k.navigator;
        u = 0 == A.lastIndexOf('Opera', 0);
        v = !u && (-1 != A.indexOf('MSIE') || -1 != A.indexOf('Trident'));
        w = !u && -1 != A.indexOf('WebKit');
        x = !u && !w && !v && 'Gecko' == ea.product;
    }
    var B = u, C = v, F = x, G = w, H = function () {
            var a = k.document;
            return a ? a.documentMode : void 0;
        }, I;
    n: {
        var J = '', K;
        if (B && k.opera)
            var L = k.opera.version, J = 'function' == typeof L ? L() : L;
        else if (F ? K = /rv\:([^\);]+)(\)|;)/ : C ? K = /\b(?:MSIE|rv)[: ]([^\);]+)(\)|;)/ : G && (K = /WebKit\/(\S+)/), K)
            var M = K.exec(z()), J = M ? M[1] : '';
        if (C) {
            var N = H();
            if (N > parseFloat(J)) {
                I = String(N);
                break n;
            }
        }
        I = J;
    }
    var O = I, P = {}, Q = function (a) {
            var b;
            if (!(b = P[a])) {
                b = 0;
                for (var c = String(O).replace(/^[\s\xa0]+|[\s\xa0]+$/g, '').split('.'), d = String(a).replace(/^[\s\xa0]+|[\s\xa0]+$/g, '').split('.'), e = Math.max(c.length, d.length), f = 0; 0 == b && f < e; f++) {
                    var p = c[f] || '', l = d[f] || '', D = RegExp('(\\d*)(\\D*)', 'g'), E = RegExp('(\\d*)(\\D*)', 'g');
                    do {
                        var g = D.exec(p) || [
                                '',
                                '',
                                ''
                            ], h = E.exec(l) || [
                                '',
                                '',
                                ''
                            ];
                        if (0 == g[0].length && 0 == h[0].length)
                            break;
                        b = ((0 == g[1].length ? 0 : parseInt(g[1], 10)) < (0 == h[1].length ? 0 : parseInt(h[1], 10)) ? -1 : (0 == g[1].length ? 0 : parseInt(g[1], 10)) > (0 == h[1].length ? 0 : parseInt(h[1], 10)) ? 1 : 0) || ((0 == g[2].length) < (0 == h[2].length) ? -1 : (0 == g[2].length) > (0 == h[2].length) ? 1 : 0) || (g[2] < h[2] ? -1 : g[2] > h[2] ? 1 : 0);
                    } while (0 == b);
                }
                b = P[a] = 0 <= b;
            }
            return b;
        }, R = k.document, fa = R && C ? H() || ('CSS1Compat' == R.compatMode ? parseInt(O, 10) : 5) : void 0;
    C && Q('9');
    !G || Q('528');
    F && Q('1.9b') || C && Q('8') || B && Q('9.5') || G && Q('528');
    F && !Q('8') || C && Q('9');
    !F && !C || C && C && 9 <= fa || F && Q('1.9.1');
    C && Q('9');
    var S = function (a) {
            var b = document;
            return n(a) ? b.getElementById(a) : a;
        }, T = function (a, b) {
            var c, d, e, f;
            c = document;
            c = b || c;
            if (c.querySelectorAll && c.querySelector && a)
                return c.querySelectorAll('' + (a ? '.' + a : ''));
            if (a && c.getElementsByClassName) {
                var p = c.getElementsByClassName(a);
                return p;
            }
            p = c.getElementsByTagName('*');
            if (a) {
                f = {};
                for (d = e = 0; c = p[d]; d++) {
                    var l = c.className;
                    'function' == typeof l.split && 0 <= da(l.split(/\s+/), a) && (f[e++] = c);
                }
                f.length = e;
                return f;
            }
            return p;
        }, U = function (a) {
            var b = typeof a;
            return ('object' == b && null != a || 'function' == b) && 1 == a.nodeType;
        };
    var V = function (a, b) {
        a.style.display = b ? '' : 'none';
    };
    var W = function (a) {
        this.a = a;
    };
    W.prototype.g = '&#43;';
    W.prototype.d = '&#8722';
    var X = function (a) {
            return T('esc-extension-container', a.a)[0];
        }, Y = function (a) {
            return T('esc-extension-see-more', a.a)[0];
        }, Z = function (a) {
            return T('esc-extension-see-less', a.a)[0];
        }, $ = function (a) {
            return T('esc-extension-toggle-icon', a.a)[0];
        };
    m('nws.tgv', function (a) {
        try {
            if (n(a)) {
                var b = S('esc-video-' + a);
                if (U(b) && 'none' != b.style.display) {
                    var c = S('esc-video-' + a), d = S('video-expand-' + a);
                    U(c) && U(d) && (V(c, !1), d.innerHTML = '&#43;');
                } else {
                    var e = S('esc-video-' + a), f = S('video-expand-' + a);
                    U(e) && U(f) && (V(e, !0), f.innerHTML = '&#8722');
                }
            }
        } catch (p) {
        }
    });
    m('nws.tge', function (a) {
        try {
            if (n(a)) {
                var b, c = S('esc-story-cluster-id-' + a);
                if (b = c ? new W(c) : null) {
                    var d = X(b);
                    if (U(d) && 'none' != d.style.display) {
                        var e = X(b), f = Y(b), p = Z(b), l = $(b);
                        if (U(e) && U(l)) {
                            V(e, !1);
                            V(f, !0);
                            V(p, !1);
                            l.innerHTML = b.g;
                            var D = l && l.getAttribute ? l.getAttribute('data-ved') || '' : '';
                            D && google.log('etcl', '&ved=' + D);
                        }
                    } else {
                        var E = X(b), g = Y(b), h = Z(b), y = $(b);
                        if (U(E) && U(y)) {
                            V(E, !0);
                            V(g, !1);
                            V(h, !0);
                            y.innerHTML = b.d;
                            var aa = y && y.getAttribute ? y.getAttribute('data-ved') || '' : '';
                            aa && google.log('etcm', '&ved=' + aa);
                        }
                    }
                }
            }
        } catch (ga) {
        }
    });
}());