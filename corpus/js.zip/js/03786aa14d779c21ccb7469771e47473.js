function isValid(eleVal, eleId, regEx) {
    var alphaExp = regEx;
    if (eleVal.match(alphaExp)) {
        return true;
    } else {
        $('#' + eleId + 'err').html('* Please Enter Valid Value');
        $('#' + eleId).css('border-color', '#E61E26');
        $('#' + eleId).focus();
        return false;
    }
}
function ValidateContactForm() {
    var valid = true;
    $('.error').html('');
    var count = 0;
    $('.default-value').each(function () {
        var thisVal;
        var thisId = this.id;
        if (this.type == 'select-one') {
            thisVal = $(this).find('option:selected').text();
        } else {
            thisVal = $(this).val();
        }
        if (thisVal == 'First Name' || thisVal == 'Choose' || thisVal == 'Card Type' || thisVal == 'Credit Card Number' || thisVal == 'Expiration Date' || thisVal == 'Last Name' || thisVal == 'Address 1' || thisVal == 'City' || thisVal == 'Zip' || thisVal == 'Email') {
            $('#' + this.id + 'err').html('* Please Enter your ' + thisVal);
            this.focus();
            count++;
        } else {
            var regEx = '';
            if (thisId == 'firstname' || thisId == 'lastname' || thisId == 'city') {
                regEx = /^[A-Za-z_]*[A-Za-z][A-Za-z_]+$/;
            } else if (thisId == 'address') {
                regEx = /^[A-Za-z0-9 _]*[A-Za-z0-9][A-Za-z0-9 _]+$/;
            } else if (thisId == 'email') {
                regEx = /^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-z0-9]{2,4}$/;
            } else if (thisId == 'zip') {
                regEx = /^[0-9]+$/;
            } else if (thisId == 'cc_num') {
                regEx = /^(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|6(?:011|5[0-9][0-9])[0-9]{12}|3[47][0-9]{13}|3(?:0[0-5]|[68][0-9])[0-9]{11}|(?:2131|1800|35\d{3})\d{11})$/;
            }
            if (regEx != '') {
                valid = isValid(thisVal, thisId, regEx);
                if (valid == false) {
                    count++;
                }
            }
        }
    });
    if (count > 0) {
        valid = false;
    }
    return valid;
}