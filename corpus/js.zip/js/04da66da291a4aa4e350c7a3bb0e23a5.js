
//立即购买
var hasoption = <!--@php echo $goods['hasoption']=='1'?'true':'false'@-->;
function buy(){
    var ret = option_selected();
        if(ret.no!=''){
           tip("请选择" + ret.no + "!",true);
            return;
        }
         var total = $("#total").val();
           <!--@php  if($stock!=-1) { @-->
          if(total>parseInt($("#goodstotail").html()))
        {
        	tip("最多只能购买" + parseInt($("#goodstotail").html()) + "件!",true);
            return;
        	
        }
         	<!--@php  } @-->
     var total = $("#total").val();
}
//添加到购物车
function addtocart(){
    var ret = option_selected();
        if(ret.no!=''){
           tip("请选择" + ret.no + "!",true);
            return;
        }
        
         var total = $("#total").val();
          <!--@php  if($stock!=-1) { @-->
        if(total>parseInt($("#goodstotail").html()))
        {
        	tip("最多只能购买" + parseInt($("#goodstotail").html()) + "件!",true);
            return;
        	
        }  	<!--@php  } @-->
        
        tip("正在处理数据...");
        $.getJSON(url, function(s){
        if(s.result==0){
            tip("只能购买 " + s.maxbuy + " 件!");
        }else{
            tip_close();
				  	tip("已加入购物车!");
			//alert("已加入购物车!");
           $('#globalId').css({'width':'22px', 'height':'16px', 'line-height':'16px'}).html(s.total).animate({'width':'15px', 'height':'16px', 'line-height':'20px'}, 'slow');
           $('#carId').css({'width':'22px', 'height':'16px', 'line-height':'16px'}).html(s.total).animate({'width':'15px', 'height':'16px', 'line-height':'20px'}, 'slow');
       }
        });
}



function option_selected(){
   
     var ret= {
         no: "",
         all: []
     };
    if(!hasoption){
        return ret;
    }
            $(".optionid").each(function(){
                ret.all.push($(this).val());
                if($(this).val()==''){
                    ret.no = $(this).attr("title");
                    return false;
                }
     })
     return ret;
}
