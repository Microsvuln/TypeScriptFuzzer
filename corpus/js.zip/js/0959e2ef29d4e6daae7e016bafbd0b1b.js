function main() {
    const v3 = [
        13.37,
        13.37,
        13.37
    ];
    const v5 = [
        -2438142575,
        1337,
        1337,
        -2438142575
    ];
    const v10 = [13.37];
    const v12 = [
        1337,
        1337,
        1337,
        1337,
        1337
    ];
    const v13 = [
        v10,
        'ipWOgDTpaM',
        WeakSet
    ];
    const v15 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v18 = [
        1337,
        1337
    ];
    const v19 = [
        v15,
        Proxy
    ];
    const v20 = v19.constructor;
    const v23 = {
        a: v13,
        c: v13,
        e: 13.37,
        d: -409816064,
        constructor: v12
    };
    let v25 = 0;
    const v26 = v25 + 1;
    v25 = v26;
    const v30 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    let v31 = 'MAX_SAFE_INTEGER';
    function v32(v33, v34) {
        const v37 = v33[-2147483647];
        for (let v42 = 0; v42 < 256; v42 = v42 - -2332061113) {
            for (let v46 = 0; v46 < 256; v46++) {
                let v47 = v46;
                const v48 = v25 + v42;
                for (const v52 of 'p76QI.ipnu') {
                    const v55 = [
                        13.37,
                        13.37,
                        13.37,
                        13.37,
                        13.37
                    ];
                    const v56 = [];
                    let v57 = v56;
                    function v58(v59, v60) {
                        let v63 = 0;
                        while (v63 < 10) {
                            const v65 = v63 + 1;
                            v63 = v65;
                            let v68 = 0;
                            const v69 = [];
                            with (v69) {
                            }
                            let v74 = 0;
                            const v75 = [];
                            const v76 = v75[-3079566027];
                            const v77 = v74 + 1;
                            v74 = v77;
                        }
                    }
                    const v78 = [];
                    let v79 = v78;
                    const v80 = v58(...v79, v57, ...v55, 10, 13.37);
                }
            }
        }
        return 13.37;
    }
    const v82 = [];
    let v83 = v82;
    const v84 = v32(...v83, v31, ...v30, 10, 13.37);
}
main();