function main() {
    const v4 = {
        preventExtensions: String,
        apply: Object,
        construct: Object,
        call: Object,
        setPrototypeOf: String,
        isExtensible: Array,
        get: Object
    };
    const v6 = new Proxy(Object, v4);
    const v7 = Object.isSealed(v6);
}
main();