function main() {
    let v2 = 0;
    do {
        const v3 = v2 + 1;
        v2 = v3;
        let v6 = 0;
        while (v6 < 10) {
            const v9 = [
                13.37,
                13.37,
                13.37,
                13.37,
                13.37
            ];
            const v10 = [];
            let v11 = v10;
            function v12(v13, v14) {
                const v18 = [
                    1,
                    1,
                    1
                ];
                const v19 = {
                    d: 1,
                    valueOf: v18,
                    e: 5
                };
                with (v19) {
                    let v22 = 0;
                    while (v22 < 8) {
                        const v23 = -Infinity;
                        const v24 = [
                            v23,
                            v23,
                            v23,
                            v23,
                            v23
                        ];
                        const v25 = v24.toLocaleString();
                        const v26 = v22 + 1;
                        v22 = v26;
                    }
                }
                let v28 = 0;
                while (v28 < 10) {
                    for (let v32 = 0; v32 < 8; v32++) {
                    }
                    const v33 = v28 + 1;
                    v28 = v33;
                }
            }
            const v34 = [];
            let v35 = v34;
            const v36 = v12(...v35, v11, ...v9, 10, 13.37);
            const v37 = v6 + 1;
            v6 = v37;
        }
    } while (v2 < 2);
}
main();