function main() {
    try {
        const v2 = new Set(1337);
    } catch (v3) {
    }
}
main();