try {
    x = true;
    x /= '1';
    if (x !== 1) {
        testFailed('#1: x = true; x /= "1"; x === 1. Actual: ' + x);
    }
    x = '1';
    x /= true;
    if (x !== 1) {
        testFailed('#2: x = "1"; x /= true; x === 1. Actual: ' + x);
    }
    x = new Boolean(true);
    x /= '1';
    if (x !== 1) {
        testFailed('#3: x = new Boolean(true); x /= "1"; x === 1. Actual: ' + x);
    }
    x = '1';
    x /= new Boolean(true);
    if (x !== 1) {
        testFailed('#4: x = "1"; x /= new Boolean(true); x === 1. Actual: ' + x);
    }
    x = true;
    x /= new String('1');
    if (x !== 1) {
        testFailed('#5: x = true; x /= new String("1"); x === 1. Actual: ' + x);
    }
    x = new String('1');
    x /= true;
    if (x !== 1) {
        testFailed('#6: x = new String("1"); x /= true; x === 1. Actual: ' + x);
    }
    x = new Boolean(true);
    x /= new String('1');
    if (x !== 1) {
        testFailed('#7: x = new Boolean(true); x /= new String("1"); x === 1. Actual: ' + x);
    }
    x = new String('1');
    x /= new Boolean(true);
    if (x !== 1) {
        testFailed('#8: x = new String("1"); x /= new Boolean(true); x === 1. Actual: ' + x);
    }
} catch (ex) {
    sputnikException = ex;
}
var successfullyParsed = true;