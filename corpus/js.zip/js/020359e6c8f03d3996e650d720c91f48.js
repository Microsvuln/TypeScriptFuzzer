function main() {
    const v2 = [
        1337,
        1337,
        1337,
        1337,
        1337
    ];
    const v3 = {
        b: 1337,
        a: v2,
        valueOf: 1337,
        e: 1337,
        d: Symbol
    };
    let v6 = 0;
    while (v6 < 9) {
        for (let v10 = 0; v10 < 10; v10++) {
            const v13 = [
                1337,
                1337,
                1337,
                1337,
                1337
            ];
            const v14 = {
                b: 1337,
                a: v13,
                valueOf: 1337,
                e: 1337,
                d: Symbol
            };
            const v18 = [
                13.37,
                13.37,
                13.37,
                13.37,
                13.37
            ];
            const v20 = [
                1337,
                1337,
                1337,
                1337,
                1337
            ];
            const v21 = {
                e: v20,
                length: 13.37,
                d: v20,
                __proto__: Symbol,
                valueOf: v18,
                c: 'p76QI.ipnu'
            };
            let v29 = 0;
            let v32 = 0;
            const v33 = v32 + 1;
            v32 = v33;
            let v36 = 0;
            const v37 = v36 + 1;
            v36 = v37;
            const v38 = v29 + 1;
            v29 = v38;
            try {
                const v39 = Symbol.keyFor(v21);
            } catch (v40) {
                for (const v41 in v40) {
                }
            }
            let v44 = 0;
            const v45 = v44 + 1;
            v44 = v45;
            const v47 = [
                1337,
                1337,
                1337,
                1337,
                1337
            ];
            let v50 = 0;
            const v51 = v50 + 1;
            v50 = v51;
            let v53 = v3;
            for (const v54 in v47) {
                const v57 = new Uint16Array(53865);
            }
        }
        const v58 = v6 + 1;
        v6 = v58;
    }
    let v61 = 0;
    const v62 = v61 + 1;
    v61 = v62;
    let v66 = 0;
}
main();