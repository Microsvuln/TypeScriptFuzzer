function main() {
    const v3 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v4 = [];
    let v5 = v4;
    function v6(v7, v8) {
        let v11 = 13.37;
        let v13 = 0;
        while (v13 < 10) {
            const v18 = new Float32Array(10152);
            v18[257] = 13.37;
            for (let v21 = 0; v21 < 256; v21++) {
                for (let v25 = 0; v25 < 256; v25++) {
                }
            }
            let v27 = eval;
            const v28 = v8 + 1;
            const v29 = v11 || v18;
            v13 = v28;
            const v30 = v18[10000];
            v18[10] = v7;
        }
    }
    const v31 = [];
    let v32 = v31;
    const v33 = v6(...v32, v5, ...v3, 10, 13.37);
    const v34 = v6('uJwLzOo8c8', 'uJwLzOo8c8');
}
main();