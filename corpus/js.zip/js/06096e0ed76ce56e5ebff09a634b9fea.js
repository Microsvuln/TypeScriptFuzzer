function main() {
    function v0(v1, v2, v3, v4, v5) {
        const v8 = [
            306123.66252946644,
            306123.66252946644,
            306123.66252946644,
            306123.66252946644,
            306123.66252946644
        ];
        const v9 = [];
        let v10 = v9;
        function v11(v12, v13) {
            for (let v17 = 0; v17 < 10; v17++) {
                const v20 = [
                    13.37,
                    13.37,
                    13.37,
                    13.37,
                    13.37
                ];
                const v21 = [];
                let v22 = v21;
                function v23(v24, v25) {
                    const v31 = new ArrayBuffer(13.37);
                    const v32 = new DataView(v31);
                    const v33 = v32.getInt32(2, 1337);
                }
                const v34 = [];
                let v35 = v34;
                const v36 = v23(...v35, v22, ...v20, 10, 13.37);
            }
        }
        const v37 = [];
        let v38 = v37;
        const v39 = v11(...v38, v10, ...v8, 10, 306123.66252946644);
    }
    for (let v43 = 0; v43 < 100; v43++) {
        const v44 = v0(v0);
    }
}
main();