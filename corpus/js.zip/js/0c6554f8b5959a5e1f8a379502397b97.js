function main() {
    const v3 = String.fromCodePoint(1337);
    const v4 = Symbol.for(v3);
    const v5 = String(v4);
}
main();