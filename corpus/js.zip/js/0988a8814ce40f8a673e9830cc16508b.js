'use strict';
const wrap = (type, text) => '<span class=\'' + type + '\'>' + escape(text) + '</span>';
const bar = '<span class=\'indent\'></span>';
const bar_end = '<span class=\'indent-end\'></span>';
const syntax1 = color => (output, position, text) => {
    output.push(wrap(color, text[position.index]));
    ++position.index;
};
const specials = {
    ' ': (output, position, text) => {
        output.push(text[position.index]);
        ++position.index;
    },
    '#': (output, position, text) => {
        const a = [];
        while (position.index < text.length) {
            const c = text[position.index];
            a.push(c);
            ++position.index;
        }
        output.push(wrap('syntax', a.join('')));
    },
    '"': (output, position, text) => {
        const a = [text[position.index]];
        ++position.index;
        while (position.index < text.length) {
            const c = text[position.index];
            a.push(c);
            ++position.index;
            if (c === '"') {
                break;
            }
        }
        output.push(wrap('literal', a.join('')));
    },
    '&': syntax1('syntax'),
    '~': syntax1('syntax'),
    '@': syntax1('syntax'),
    '.': (output, position, text) => {
        syntax1('syntax')(output, position, text);
        output.push(wrap('literal', parse_variable(position, text)));
    },
    '(': syntax1('syntax'),
    '[': syntax1('syntax'),
    '{': syntax1('syntax'),
    ')': syntax1('syntax'),
    ']': syntax1('syntax'),
    '}': syntax1('syntax')
};
const variable = s => {
    if (s === '_' || s === '->' || s === '<=' || s === '=' || s === '::') {
        return wrap('syntax', s);
    } else if (s[0] === '*') {
        return wrap('literal', s);
    } else if (s[0] === '$') {
        return wrap('protocol', s);
    } else if (/^[0-9]+$/.test(s)) {
        return wrap('literal', s);
    } else if (/^[^a-z]+$/.test(s)) {
        return wrap('special', s);
    } else if (/^[A-Z]/.test(s)) {
        return wrap('type', s);
    } else {
        return escape(s);
    }
};
const escape = s => s.replace(/</g, '&lt;');
const parse_variable = (position, text) => {
    const a = [];
    while (position.index < text.length) {
        const c = text[position.index];
        if (specials[c]) {
            break;
        } else {
            a.push(c);
            ++position.index;
        }
    }
    return a.join('');
};
const add_bars = indents => {
    let max = 0;
    const length = indents.length;
    const output = [];
    for (let i = 0; i < length; ++i) {
        const x = indents[i];
        output.push(new Array(x.indent - max - 2 + 1).join(' '));
        output.push(x.last ? bar_end : bar);
        output.push(new Array(2 + 1).join(' '));
        max = x.indent;
    }
    return output.join('');
};
const get_previous = (lines, index) => {
    for (let i = index - 1; i >= 0; --i) {
        const line = lines[i];
        if (line.text !== '') {
            return line;
        }
    }
    return null;
};
const push_previous = (lines, index, indent) => {
    for (let i = index - 1; i >= 0; --i) {
        const line = lines[i];
        if (line.text === '' || line.indent > indent) {
            let seen = false;
            for (let i = 0; i < line.indents.length; ++i) {
                const x = line.indents[i];
                if (x.indent === indent) {
                    seen = true;
                    break;
                }
            }
            if (!seen) {
                line.indents.unshift({
                    last: false,
                    indent: indent
                });
            }
        } else {
            break;
        }
    }
};
const markup = text => {
    const lines = [];
    text.split(/\n/).forEach((s, index) => {
        let indent = 0;
        while (indent < s.length) {
            const c = s[indent];
            if (c === ' ') {
                ++indent;
            } else {
                break;
            }
        }
        const text = s.slice(indent);
        const previous = get_previous(lines, index);
        const indents = [];
        if (previous !== null) {
            for (let i = 0; i < previous.indents.length; ++i) {
                const x = previous.indents[i];
                if (x.indent < indent) {
                    indents.push({
                        last: false,
                        indent: x.indent
                    });
                } else if (text !== '' && x.indent > indent) {
                    x.last = true;
                }
            }
        }
        if (indent !== 0) {
            push_previous(lines, index, indent);
            indents.push({
                last: false,
                indent: indent
            });
        }
        lines.push({
            indent: indent,
            indents: indents,
            text: text
        });
    });
    console.log(JSON.stringify(lines.map(x => x.indents), null, 2));
    const output = new Array(lines.length);
    const indents = [];
    for (let i = 0; i < lines.length; ++i) {
        const line = lines[i];
        const indent = line.indent;
        const text = line.text;
        const a = [];
        const position = { index: 0 };
        while (position.index < text.length) {
            const c = text[position.index];
            if (specials[c]) {
                specials[c](a, position, text);
            } else {
                a.push(variable(parse_variable(position, text)));
            }
        }
        output[i] = '<span class=\'line-number\'>' + (i + 1) + '</span>' + add_bars(line.indents) + a.join('');
    }
    return output.join('\n');
};
let timer = null;