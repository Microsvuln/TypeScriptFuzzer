function main() {
    function v0(v1, v2) {
        const v5 = Uint32Array(11105);
    }
    let v8 = 0;
    const v17 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    let v18 = 10;
    function v19(v20, v21) {
        const v23 = 'split'.match;
        delete 'p76QI.ipnu'[3652309175];
        const v27 = [
            13.37,
            13.37,
            13.37
        ];
        function v28(v29, v30) {
        }
        const v31 = v19 + 1;
        const v32 = [
            610042.8479218336,
            v31
        ];
        const v33 = v32.map(v23, v17);
    }
    const v34 = [];
    let v35 = v34;
    const v36 = v19(...v35, v18, ...v17, 10, 13.37);
}
main();