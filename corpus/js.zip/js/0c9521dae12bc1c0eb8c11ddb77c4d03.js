function main() {
    const v4 = [];
    let v5 = v4;
    function v6(v7, v8) {
        for (let v12 = 0; v12 < 10; v12++) {
            const v14 = [1153650795];
            for (const v15 of v14) {
                const v20 = new ArrayBuffer(65535);
                v14[v12] = parseInt;
                const v21 = new DataView(v20);
                const v22 = v21.getFloat64(1, v15);
            }
        }
    }
    const v23 = [];
    let v24 = v23;
    const v25 = v6(...v24, v5, ...'function', 10, 13.37);
}
main();