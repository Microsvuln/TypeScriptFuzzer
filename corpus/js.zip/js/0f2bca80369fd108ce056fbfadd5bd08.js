function main() {
    let v1 = 13.37;
    function v2(v3, v4, v5) {
        const v9 = [
            13.37,
            13.37,
            13.37,
            13.37,
            13.37
        ];
        const v10 = [];
        let v11 = v10;
        function v12(v13, v14) {
            let v17 = 0;
            while (v17 < 10) {
                const v19 = [
                    1337,
                    1337,
                    1337
                ];
                const v20 = [];
                function v21(v22, v23) {
                    const v26 = [
                        'p76QI.ipnu',
                        1337,
                        1337,
                        1337,
                        1337
                    ];
                    const v27 = v26.concat();
                    return arguments;
                }
                for (let v31 = 0; v31 < 100; v31++) {
                    const v32 = v21(v19, v20);
                }
                const v33 = v17 + 1;
                v17 = v33;
            }
        }
        const v34 = [];
        let v35 = v34;
        const v36 = v12(...v35, v11, ...v9, 10, 13.37);
    }
    for (let v40 = 0; v40 < 10; v40++) {
        const v41 = v2(v1);
    }
}
main();