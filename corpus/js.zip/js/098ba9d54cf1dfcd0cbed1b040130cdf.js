function main() {
    let v6 = 0;
    const v9 = new Uint16Array(9640);
    const v10 = new Int16Array(v9);
}
main();