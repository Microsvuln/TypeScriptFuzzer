(function () {
    var now = Number(new Date());
    while (now + 2000 > Number(new Date())) {
        console.log('Waiting...');
    }
    ;
}());