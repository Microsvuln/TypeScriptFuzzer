function main() {
    function v1(v2, v3, v4) {
        'use strict';
        const v7 = [
            -441746.4139016614,
            -441746.4139016614,
            -441746.4139016614,
            -441746.4139016614,
            -441746.4139016614
        ];
        const v8 = [];
        let v9 = v8;
        function v10(v11, v12) {
            const v14 = [
                1337,
                1337,
                1337,
                1337,
                1337
            ];
            for (let v19 = 0; v19 < 1000; v19++) {
                try {
                    const v20 = [];
                    let v22 = v19;
                    const v25 = [
                        v19,
                        13.37,
                        13.37,
                        v22,
                        13.37
                    ];
                    let v26 = v19;
                    function v27(v28, v29) {
                        let v33 = String;
                        const v34 = v33.fromCharCode(2339146182, 4061361086, v19, v19, v14);
                        const v35 = RegExp(v34);
                        v35[v34] = 65537;
                        return v35;
                    }
                    let v36 = v20;
                    const v37 = v27(...v36, v26, ...v25, 65537, 13.37);
                    const v38 = 'NEGATIVE_INFINITY'.replace(v37, v37);
                } catch (v39) {
                }
            }
        }
        const v40 = [];
        let v41 = v40;
        const v42 = v10(...v41, v9, v7, 1337, -441746.4139016614);
    }
    const v43 = v1(-673446.2322328449);
}
main();