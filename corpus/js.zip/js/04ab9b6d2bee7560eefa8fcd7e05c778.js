let ab = new ArrayBuffer(1024);
var jfHQ = !-9007199254740991;
function hax(o, changeProto) {
    var Xecf = !NaN;
    let y = {
        slots: 13.37,
        elements: 13.38,
        buffer: ab,
        length: 13.39,
        byteOffset: 13.4,
        data: 3.54484805889626e-310
    };
    var TZtA = +-1.7976931348623157e+308;
    var DkcR = pwn(0, 3.141592653589793);
    hax(-2147483647, 3.141592653589793);
    hax(1518500249, 1e+81);
    var wtCr = pwn(-9007199254740992, 4);
    var cE8D = !1.3;
    var kZGp = new Map([
        [
            9007199254740991,
            0,
            5e-324,
            0,
            0
        ],
        [
            10000,
            153,
            1e-81,
            9007199254740992,
            4,
            -1,
            1518500249,
            4294967297
        ]
    ]);
    var KmDR = pwn(0, 4294967296);
    var aJHM = pwn(-9007199254740994, -Infinity);
    pwn(-4294967296, 1200);
    pwn(1.3, 1e+400);
    var HwaJ = hax(0, 3);
    var dpKK = 9007199254740994 == -Infinity;
    var jsxd = new SharedArrayBuffer(4);
    var FwQR = 42 <= -4294967297;
    var nAdn = pwn(4294967297, 153);
    var ZWje = pwn(-4294967297, 42);
    hax(759250124, NaN);
    var ntEw = hax(4294967297, 1.7976931348623157e+308);
    pwn(9007199254740991, 3.141592653589793);
    var eXCK = 1.3 > 1e+400;
    var MJse = pwn(-2147483649, 5);
    var WtGr = hax(1.7976931348623157e+308, -1.7976931348623157e+308);
    pwn(0, -1.7976931348623157e+308);
    hax(0, NaN);
    var sYec = pwn(-9007199254740994, 0.1);
    var ZkRW = hax(0.1, 1.7976931348623157e+308);
    pwn(4, -2147483648);
    var QfWJ = pwn(-2147483648, 9007199254740991);
    pwn(9007199254740992, -2147483648);
    var ZStQ = hax(1, -9007199254740994);
    pwn(2147483647, -Infinity);
    var CcPC = pwn(759250124, 3);
    var YbHm = pwn(1e+400, -9007199254740991);
    var yxKK = pwn(1e+81, 1e+81);
    var hcwM = hax(9007199254740991, 4);
    var eAFJ = hax(1, 5e-324);
    var TrdN = pwn(5, -Infinity);
    var nFfM = hax(1.7976931348623157e+308, 673720360);
    if (changeProto) {
        o.__proto__ = {};
    }
    return o;
}
function pwn(o, trigger) {
    if (trigger) {
    } else {
        return 42;
    }
}
for (let i = 0; i < 10000; i++) {
    var YDNd = !9007199254740994;
    var MEXr = jfHQ.toString(1200, jfHQ, ab);
    var KGTH = ab.slice(MEXr.length, MEXr.length);
    var BMYs = YDNd.valueOf();
    var GNaN = BMYs.toString(MEXr.length, MEXr.length, MEXr.length);
    var Cnai = ab.slice(MEXr.length, MEXr.length);
}
let evilObj;
for (let i = 0; i < 10000; i++) {
}
for (let i = 0; i < 100000; i++) {
    pwn(evilObj, false);
}
pwn(evilObj, true);