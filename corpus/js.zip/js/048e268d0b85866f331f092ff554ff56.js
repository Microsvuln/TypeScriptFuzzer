function main() {
    const v1 = [13.37];
    const v2 = {
        length: 13.37,
        valueOf: 13.37,
        a: v1
    };
    const v5 = new Int16Array(58071);
    const v7 = v5.set(v2, 0);
}
main();