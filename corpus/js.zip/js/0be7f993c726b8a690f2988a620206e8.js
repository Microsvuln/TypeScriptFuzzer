function Ok() {
    var sHtml;
    var sPastingType = dialog.Args().CustomValue;
    if (sPastingType == 'Word' || sPastingType == 'Security') {
        var oFrame = document.getElementById('frmData');
        var oBody;
        if (oFrame.contentDocument)
            oBody = oFrame.contentDocument.body;
        else
            oBody = oFrame.contentWindow.document.body;
        if (sPastingType == 'Word') {
            if (typeof FCK.CustomCleanWord == 'function')
                sHtml = FCK.CustomCleanWord(oBody, document.getElementById('chkRemoveFont').checked, document.getElementById('chkRemoveStyles').checked);
            else
                sHtml = CleanWord(oBody, document.getElementById('chkRemoveFont').checked, document.getElementById('chkRemoveStyles').checked);
        } else
            sHtml = oBody.innerHTML;
        var re;
        sHtml = sHtml.replace(re, '#');
    } else {
        dialog.Selection.EnsureSelection();
        range.MoveToSelection();
        range.DeleteContents();
        var marker = [];
        for (var i = 0; i < 5; i++)
            marker.push(parseInt(Math.random() * 100000, 10));
        marker = marker.join('');
        range.InsertNode(oDoc.createTextNode(marker));
        var bookmark = range.CreateBookmark();
        var htmlString = oDoc.body.innerHTML;
        var index = htmlString.indexOf(marker);
        var htmlList = [];
        htmlList.push(htmlString.substr(0, index));
        htmlList.push(sHtml);
        htmlList.push(htmlString.substr(index + marker.length));
        htmlString = htmlList.join('');
        if (!oEditor.FCKBrowserInfo.IsIE)
            oDoc.body.innerHTML = htmlString;
        range.MoveToBookmark(bookmark);
        range.Collapse(false);
        range.Select();
        range.Release();
        return true;
    }
    return true;
}
function CleanWord(oNode, bIgnoreFont, bRemoveStyles) {
    var html = oNode.innerHTML;
    html = html.replace(/<o:p>\s*<\/o:p>/g, '');
    html = html.replace(/<o:p>.*?<\/o:p>/g, '&nbsp;');
    html = html.replace(/\s*mso-[^:]+:[^;"]+;?/gi, '');
    html = html.replace(/\s*MARGIN: 0cm 0cm 0pt\s*;/gi, '');
    html = html.replace(/\s*MARGIN: 0cm 0cm 0pt\s*"/gi, '"');
    html = html.replace(/\s*TEXT-INDENT: 0cm\s*;/gi, '');
    html = html.replace(/\s*TEXT-INDENT: 0cm\s*"/gi, '"');
    html = html.replace(/\s*TEXT-ALIGN: [^\s;]+;?"/gi, '"');
    html = html.replace(/\s*PAGE-BREAK-BEFORE: [^\s;]+;?"/gi, '"');
    html = html.replace(/\s*FONT-VARIANT: [^\s;]+;?"/gi, '"');
    html = html.replace(/\s*tab-stops:[^;"]*;?/gi, '');
    html = html.replace(/\s*tab-stops:[^"]*/gi, '');
    if (bIgnoreFont) {
        html = html.replace(/\s*face="[^"]*"/gi, '');
        html = html.replace(/\s*face=[^ >]*/gi, '');
        html = html.replace(/\s*FONT-FAMILY:[^;"]*;?/gi, '');
    }
    html = html.replace(/<(\w[^>]*) class=([^ |>]*)([^>]*)/gi, '<$1$3');
    if (bRemoveStyles)
        html = html.replace(/<(\w[^>]*) style="([^\"]*)"([^>]*)/gi, '<$1$3');
    html = html.replace(/\s*style="\s*"/gi, '');
    html = html.replace(/<SPAN\s*[^>]*>\s*&nbsp;\s*<\/SPAN>/gi, '&nbsp;');
    html = html.replace(/<SPAN\s*[^>]*><\/SPAN>/gi, '');
    html = html.replace(/<(\w[^>]*) lang=([^ |>]*)([^>]*)/gi, '<$1$3');
    html = html.replace(/<SPAN\s*>(.*?)<\/SPAN>/gi, '$1');
    html = html.replace(/<FONT\s*>(.*?)<\/FONT>/gi, '$1');
    html = html.replace(/<\\?\?xml[^>]*>/gi, '');
    html = html.replace(/<\/?\w+:[^>]*>/gi, '');
    html = html.replace(/<\!--.*?-->/g, '');
    html = html.replace(/<w:[^>]*>(.*?)<\/w:[^>]*>/gi, '');
    html = html.replace(/<meta[^>]*>/gi, '');
    html = html.replace(/<link[^>]*>/gi, '');
    html = html.replace(/<style[^>]*>([\w|\W|\n]*?)<\/style>/gim, '');
    html = html.replace(/<\!--([\w|\W|\n]*?)-->/gm, '');
    html = html.replace(/<(U|I|STRIKE)>&nbsp;<\/\1>/g, '&nbsp;');
    html = html.replace(/<H\d>\s*<\/H\d>/gi, '');
    html = html.replace(/<font>|<\/font>/gi, '');
    html = html.replace(/<(\w+)[^>]*\sstyle="[^"]*DISPLAY\s?:\s?none(.*?)<\/\1>/ig, '');
    html = html.replace(/<(\w[^>]*) language=([^ |>]*)([^>]*)/gi, '<$1$3');
    html = html.replace(/<(\w[^>]*) onmouseover="([^\"]*)"([^>]*)/gi, '<$1$3');
    html = html.replace(/<(\w[^>]*) onmouseout="([^\"]*)"([^>]*)/gi, '<$1$3');
    if (FCKConfig.CleanWordKeepsStructure) {
        html = html.replace(/<H(\d)([^>]*)>/gi, '<h$1>');
        html = html.replace(/<(H\d)><FONT[^>]*>(.*?)<\/FONT><\/\1>/gi, '<$1>$2</$1>');
        html = html.replace(/<(H\d)><EM>(.*?)<\/EM><\/\1>/gi, '<$1>$2</$1>');
    } else {
        html = html.replace(/<H1([^>]*)>/gi, '<div$1><b><font size="6">');
        html = html.replace(/<H2([^>]*)>/gi, '<div$1><b><font size="5">');
        html = html.replace(/<H3([^>]*)>/gi, '<div$1><b><font size="4">');
        html = html.replace(/<H4([^>]*)>/gi, '<div$1><b><font size="3">');
        html = html.replace(/<H5([^>]*)>/gi, '<div$1><b><font size="2">');
        html = html.replace(/<H6([^>]*)>/gi, '<div$1><b><font size="1">');
        html = html.replace(/<\/H\d>/gi, '</font></b></div>');
        var re = new RegExp('(<P)([^>]*>.*?)(</P>)', 'gi');
        html = html.replace(re, '<div$2</div>');
        html = html.replace(/<([^\s>]+)(\s[^>]*)?>\s*<\/\1>/g, '');
        html = html.replace(/<([^\s>]+)(\s[^>]*)?>\s*<\/\1>/g, '');
        html = html.replace(/<([^\s>]+)(\s[^>]*)?>\s*<\/\1>/g, '');
    }
    return html;
}