function main() {
    const v4 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v5 = [];
    let v6 = v5;
    function v7(v8, v9) {
        for (let v14 = 0; v14 < 1000; v14++) {
            try {
                let v16 = v9;
                const v18 = [
                    524987.369375993,
                    524987.369375993,
                    524987.369375993,
                    v16,
                    524987.369375993
                ];
                let v19 = v14;
                function v20(v21, v22) {
                    let v24 = String;
                    const v25 = v24.fromCharCode(v21, v21, v16, v6, v14);
                    const v26 = Function(v25);
                }
                let v27 = v18;
                const v28 = v20(...v27, v19, ...v18, 1337, 524987.369375993);
            } catch (v29) {
                v6 = v14;
            }
        }
        return v5;
    }
    const v30 = [];
    let v31 = v30;
    const v32 = v7(...v31, Uint32Array, ...v4, 10, 13.37);
    let v35 = 0;
    const v36 = v35 + 1;
    v35 = v36;
    let v39 = 0;
    const v40 = v39 + 1;
    v39 = v40;
    const v41 = v7(1337, 9);
}
main();