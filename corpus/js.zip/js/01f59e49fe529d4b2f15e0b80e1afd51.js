function main() {
    const v4 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v6 = [1337];
    const v7 = {
        __proto__: v6,
        d: v4,
        e: 13.37,
        c: 65536
    };
    let v8 = v4;
    try {
        const v14 = [
            13.37,
            13.37,
            13.37,
            13.37,
            13.37
        ];
        const v15 = [];
        let v16 = v15;
        function v17(v18, v19) {
            const v21 = [
                13.37,
                13.37,
                13.37,
                13.37,
                13.37
            ];
            for (const v22 of v21) {
                const v26 = [
                    1337,
                    1337,
                    1337,
                    1337,
                    1337
                ];
                const v27 = {
                    b: 1337,
                    a: v26,
                    valueOf: 1337,
                    e: 1337,
                    d: Symbol
                };
                const v28 = v18 === 'gytSEGkfIk';
                let v29 = v27;
                function v31(v32, v33, v34, v35, ...v36) {
                    let v39 = 0;
                }
                let v42 = 0;
                const v43 = v28 << v7;
                const v44 = v42 + 1;
                v42 = v44;
                const v46 = [
                    v19,
                    v19
                ];
                v14.toString = v17;
                const v59 = [
                    13.37,
                    13.37,
                    13.37,
                    13.37,
                    13.37
                ];
                const v60 = [];
                let v61 = v60;
                function v62(v63, v64) {
                    const v66 = 0 - v14;
                    let v68 = 0;
                    const v69 = v68 + 1;
                    let v72 = 0;
                    do {
                    } while (v72 < Symbol);
                    const v73 = Symbol(v19);
                    function v74(v75, v76, v77, v78) {
                        'use strict';
                        return v64;
                    }
                    const v80 = v18 || v8;
                    const v82 = [
                        13.37,
                        v64
                    ];
                    for (let v88 = 0; v88 < 8; v88++) {
                        for (let v95 = 0; v95 < 10; v95++) {
                            const v98 = [
                                13.37,
                                13.37,
                                13.37,
                                13.37,
                                13.37
                            ];
                            const v99 = [];
                            let v100 = v99;
                            function v101(v102, v103) {
                            }
                            const v109 = [];
                            let v110 = v109;
                            let v113 = 0;
                            while (v113 < 4) {
                                function v119(v120, v121) {
                                }
                                const v125 = v113 + 1;
                            }
                            const v126 = v101(...v110, v100, ...v98, 10, 13.37);
                        }
                    }
                }
                const v127 = [];
                let v128 = v127;
                const v129 = v62(...v128, v61, ...v59, 10, 13.37);
                const v134 = {
                    setPrototypeOf: Symbol,
                    get: Symbol,
                    defineProperty: Symbol,
                    has: Symbol,
                    preventExtensions: Symbol,
                    construct: Symbol,
                    call: Symbol,
                    ownKeys: Symbol,
                    set: Symbol,
                    getPrototypeOf: Infinity,
                    apply: gc
                };
            }
            return v16;
        }
        const v138 = [];
        let v139 = v138;
        const v140 = v17(...v139, v16, ...v14, 1337, 13.37);
    } catch (v141) {
    }
}
main();