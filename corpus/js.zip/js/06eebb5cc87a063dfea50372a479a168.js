function main() {
    const v1 = [
        13.37,
        13.37,
        13.37
    ];
    const v4 = [
        1337,
        1337,
        1337,
        1337
    ];
    const v7 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v8 = [];
    let v9 = v8;
    function v10(v11, v12) {
        for (const v13 in v12) {
            const v14 = ~v1;
        }
        const v15 = 'XmPV1VqcVG' === v12;
        for (let v19 = -65537; v19 < 8; v19++) {
        }
    }
    const v20 = [];
    let v21 = v20;
    const v22 = v10(...v21, v9, ...v7, 1337, 13.37);
    const v23 = v10(13.37, v4);
}
main();