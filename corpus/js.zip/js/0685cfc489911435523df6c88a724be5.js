function quit() {
    ipc.send('terminate');
}
function browser() {
    ipc.send('browser');
}
function homepage() {
    ipc.send('homepage');
}