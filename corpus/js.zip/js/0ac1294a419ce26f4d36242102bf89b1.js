function main() {
    try {
        const v2 = [
            13.37,
            13.37,
            13.37,
            13.37,
            13.37
        ];
        const v3 = [];
        let v4 = v3;
        function v5(v6, v7) {
            v2.toString = v5;
            const v10 = [
                13.37,
                13.37,
                13.37,
                13.37,
                13.37
            ];
            const v15 = [
                1337,
                1337
            ];
            let v16 = String;
            const v17 = v16.fromCharCode(1337, v15, Object, -536870912);
            const v18 = [];
            let v19 = v18;
            function v20(v21, v22) {
                const v24 = 0 - v2;
                let v27 = 0;
            }
            const v28 = [];
            let v29 = v28;
            const v30 = v20(...v29, v19, ...v10, 10, 13.37);
        }
        const v31 = [];
        let v32 = v31;
        const v33 = v5(...v32, v4, ...v2, 1337, 13.37);
    } catch (v34) {
    }
}
main();