function main() {
    const v6 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v12 = [
        1337,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v13 = [];
    let v14 = v13;
    function v15(v16, v17) {
        let v20 = 0;
        while (v20 < 10) {
            for (let v24 = 0; v24 < 8; v24++) {
                for (let v28 = 0; v28 < 5; v28++) {
                }
            }
            const v29 = v20 + 1;
            v20 = v29;
            const v32 = new Uint32Array(11105);
            const v33 = v32 <= Uint32Array;
            const v35 = [
                13.37,
                13.37,
                13.37,
                13.37,
                13.37
            ];
            const v37 = v35 in Symbol;
            const v42 = [
                13.37,
                13.37,
                13.37,
                13.37,
                13.37
            ];
            const v44 = [
                1337,
                1337,
                1337,
                1337,
                1337
            ];
            const v46 = [];
            const v47 = {
                e: v44,
                length: 13.37,
                d: v44,
                __proto__: Symbol,
                valueOf: v42,
                c: 'p76QI.ipnu'
            };
            const v48 = {
                b: 1337,
                a: v44,
                valueOf: 1337,
                e: 1337,
                d: Symbol
            };
            let v49 = v46;
            10 .toString = 10;
            const v51 = 10[-1109617344];
            Symbol.valueOf = Symbol;
            const v54 = 'p76QI.ipnu'.padEnd(v51, 'p76QI.ipnu');
            v54.c = Symbol;
            const v55 = 'p76QI.ipnu'.substring(v51, v51);
            const v57 = [
                13.37,
                13.37,
                13.37,
                13.37,
                13.37
            ];
            const v59 = [
                1337,
                1337,
                1337,
                1337,
                1337
            ];
            const v60 = [];
            const v61 = {
                e: v59,
                length: 1337,
                d: v59,
                __proto__: Symbol,
                valueOf: v57,
                c: 'p76QI.ipnu'
            };
            const v62 = {
                b: 1337,
                a: v59,
                valueOf: 1337,
                e: 1337,
                d: Symbol
            };
            let v63 = v57;
            let v70 = 0;
            while (v70 < 5) {
                const v71 = 1337 && 'p76QI.ipnu';
                const v72 = v70 + 1;
                v70 = v72;
            }
            const v73 = v63.find(Symbol, v62);
            const v74 = typeof v60;
            const v76 = v74 === 'boolean';
            let v77 = v76;
            if (v73) {
                const v78 = 'p76QI.ipnu'.__proto__;
                v77 = v61;
            } else {
                const v79 = v59 << v77;
                v77 = Symbol;
            }
            let v80 = v76;
            if (v76) {
                const v81 = v55.__proto__;
                v80 = v76;
            } else {
                const v83 = {
                    get: v51,
                    set: Symbol
                };
                const v85 = Object.defineProperty(v62, 4104864933, v83);
                v80 = v61;
            }
            const v86 = [
                -4294967295,
                -4294967295,
                -4294967295,
                -4294967295,
                -4294967295
            ];
            for (let v113 = 0; v113 < -4135770668; v113++) {
            }
            const v114 = v37 != v33;
        }
    }
    let v115 = v6;
    const v116 = v15(...v115, v14, ...v12, 10, 13.37);
}
main();