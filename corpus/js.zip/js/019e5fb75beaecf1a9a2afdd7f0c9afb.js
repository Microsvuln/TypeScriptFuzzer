function main() {
    const v1 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v2 = [];
    let v3 = v2;
    function v4(v5, v6) {
        let v9 = 0;
        while (v9 < 10) {
            const v12 = Math.round(v6);
            function v13(v14, v15, v16, v17, ...v18) {
            }
            const v22 = v13();
            const v23 = Math.log2(v6);
            for (let v26 = 0; v26 < 8; v26++) {
                for (let v30 = 0; v30 < 5; v30++) {
                }
            }
            const v31 = v9 + 1;
            v9 = v31;
        }
    }
    const v32 = [];
    let v33 = v32;
    const v34 = v4(...v33, v3, ...v1, v33, 13.37);
}
main();