var a = {
    0: { a: 'a' },
    1: { b: 'b' },
    2: { c: 'c' },
    length: 3,
    d: '4'
};
var res = [].slice.call(a, 1);
var a1 = res[0].b == 'b';
var res = [].slice.call(a, 0, 2);
var a2 = res[0].a == 'a';
var a3 = res[1].b == 'b';
a1;
a2;
a3;