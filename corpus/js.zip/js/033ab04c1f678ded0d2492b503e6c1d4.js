function main() {
    const v5 = [
        1337,
        1337,
        1337,
        1337
    ];
    let v33 = 0;
    while (v33 < 3) {
        const v34 = v33 + 1;
        v33 = v34;
    }
    let v37 = 0;
    const v45 = [
        1337,
        1337,
        1337
    ];
    for (let v50 = 0; v50 < 10; v50++) {
        const v53 = [
            1337,
            1337,
            1337,
            1337,
            1337
        ];
        const v56 = [
            13.37,
            13.37,
            13.37,
            13.37,
            13.37
        ];
        const v57 = [];
        let v58 = v57;
        const v59 = v45.some(parseFloat, 1);
        function v62(v63, v64) {
            let v75 = 0;
            while (v75 < 10) {
                for (let v82 = 0; v82 < 5; v82++) {
                    for (let v86 = 0; v86 < 4; v86++) {
                    }
                    const v87 = v53.some(Symbol, v75);
                }
                const v90 = 'p76QI.ipnu' instanceof Symbol;
                const v91 = v75 + 1;
                v75 = v91;
            }
            const v97 = [
                1337,
                1337,
                1337
            ];
            delete 13.37[v5];
            const v109 = [
                13.37,
                13.37,
                13.37,
                13.37,
                13.37
            ];
            const v110 = [];
            let v111 = v110;
            function v112(v113, v114) {
            }
            const v134 = [];
            let v135 = v134;
            const v136 = v112(...v135, v111, ...v109, 10, 13.37);
        }
        const v138 = [];
        let v139 = v138;
        const v140 = v62(...v139, v58, ...v56, 10, 13.37);
    }
}
main();