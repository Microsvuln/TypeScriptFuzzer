function main() {
    const v3 = [
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v4 = [Map];
    const v5 = {
        d: 10000,
        toString: 10000,
        e: v4,
        b: Map
    };
    let v6 = v5;
    let v8 = Object;
    const v12 = Object.getOwnPropertyDescriptors(v6);
    const v13 = v5 == v3;
    let v16 = 0;
    const v17 = v8.create(v5, v12);
}
main();