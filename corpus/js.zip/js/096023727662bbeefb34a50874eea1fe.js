function main() {
    let v2 = 0;
    while (v2 < 10) {
        const v5 = [
            13.37,
            13.37,
            13.37,
            13.37,
            13.37
        ];
        const v6 = [];
        let v7 = v6;
        function v8(v9, v10) {
            const v16 = [
                13.37,
                1337,
                1337
            ];
            const v17 = {
                e: 1337,
                c: 7,
                b: v16,
                d: 7,
                length: 1337
            };
            const v21 = new Uint16Array(36118);
            const v22 = v21.every(Symbol, v17);
            let v23 = 0;
            while (v23 < 10) {
                const v28 = [1337];
                const v29 = [v28];
                const v30 = {
                    a: -1707458645,
                    c: v29,
                    toString: Float32Array,
                    valueOf: 13.37,
                    e: 13.37,
                    d: v29
                };
                const v32 = new Int8Array(v30);
                v32[1] = v32;
                const v33 = v23 + 1;
                v23 = v33;
            }
        }
        const v34 = [];
        let v35 = v34;
        const v36 = v8(...v35, v7, ...v5, 10, 13.37);
        const v37 = v2 + 1;
        v2 = v37;
    }
}
main();