function main() {
    let v2 = 0;
    const v3 = v2 + 1;
    v2 = v3;
    const v5 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v8 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v10 = [
        1337,
        1337,
        1337,
        1337,
        1337
    ];
    const v11 = [];
    const v12 = {
        b: 1337,
        a: v10,
        valueOf: 1337,
        e: 1337,
        d: Symbol
    };
    let v13 = v8;
    let v17 = 0;
    const v18 = v17 + 1;
    v17 = v18;
    const v19 = v13.find(Symbol, v12);
    const v20 = typeof v11;
    const v22 = v20 === 'boolean';
    for (let v29 = 0; v29 < 100; v29++) {
        function v30(v31, v32, v33, v34, v35) {
            const v38 = eval('toString');
        }
        for (let v42 = 0; v42 < 100; v42++) {
            const v43 = v30(v30);
        }
    }
}
main();