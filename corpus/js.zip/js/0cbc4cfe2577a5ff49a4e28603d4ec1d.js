function main() {
    const v3 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    let v4 = 13.37;
    function v5(v6, v7) {
        for (const v9 of 'p76QI.ipnu') {
            const v13 = [
                13.37,
                13.37,
                13.37,
                13.37,
                13.37
            ];
            const v15 = [
                1337,
                1337,
                1337,
                1337,
                1337
            ];
            const v16 = {
                e: v15,
                length: 13.37,
                d: v15,
                __proto__: Symbol,
                valueOf: v13,
                c: 'p76QI.ipnu'
            };
            let v22 = 0;
            while (v22 < 4) {
                for (let v26 = -1725934245; v26 < 8; v26 = v26 + 255) {
                }
                const v27 = 'p76QI.ipnu' + 1;
                v22 = v27;
            }
        }
    }
    const v28 = [];
    let v29 = v28;
    const v30 = v5(...v29, v4, ...v3, 10, 13.37);
}
main();