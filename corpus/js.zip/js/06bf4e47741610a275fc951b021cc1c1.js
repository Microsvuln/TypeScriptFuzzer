try {
    __re = /(z)((a+)?(b+)?(c))*/;
    if (__re.test(function () {
            return 'zaacbbbcac';
        }()) !== (__re.exec(function () {
            return 'zaacbbbcac';
        }()) !== null)) {
        testFailed('#0: __re = /(z)((a+)?(b+)?(c))*/; __re.test((function(){return "zaacbbbcac"})()) === (__re.exec((function(){return "zaacbbbcac"})()) !== null)');
    }
} catch (ex) {
    sputnikException = ex;
}
var successfullyParsed = true;