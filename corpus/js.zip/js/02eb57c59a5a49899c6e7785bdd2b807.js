function main() {
    const v2 = [
        13.37,
        13.37,
        13.37
    ];
    const v3 = {
        a: 13.37,
        valueOf: v2
    };
    const v8 = [
        1337,
        -5,
        -5,
        -5,
        'arguments'
    ];
    let v9 = v3;
    function v10(v11, v12) {
        const v17 = {
            get: Map,
            set: Symbol
        };
        const v19 = Object.defineProperty(Symbol, 'length', v17);
    }
    const v20 = [];
    let v21 = v20;
    const v22 = v10(...v21, v9, ...v8, 10, -5);
    try {
        let v24 = Int16Array;
        const v26 = new v24(Symbol);
    } catch (v27) {
    }
}
main();