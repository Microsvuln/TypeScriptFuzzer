function main() {
    const v23 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v24 = [];
    let v25 = v24;
    function v26(v27, v28) {
        for (let v34 = 0; v34 < 6; v34++) {
            const v78 = [
                13.37,
                13.37,
                13.37,
                13.37,
                13.37
            ];
            const v79 = [];
            let v80 = v79;
            function v81(v82, v83) {
                const v94 = Object.keys(Promise);
                const v149 = arguments.__proto__;
            }
            const v164 = [];
            let v165 = v164;
            const v166 = v81(...v165, v80, ...v78, 10, 13.37);
        }
        let v167 = 0;
        while (v167 < 65535) {
            const v168 = v167 + 1;
            v167 = v168;
        }
    }
    const v170 = [];
    let v171 = v170;
    const v172 = v26(...v171, v25, ...v23, 10, 13.37);
}
main();