try {
    var obj = {};
    obj.pop = Array.prototype.pop;
    obj[0] = -1;
    obj.length = {
        valueOf: function () {
            return 1;
        }
    };
    var pop = obj.pop();
    if (pop !== -1) {
        testFailed('#1: obj[0] = -1; obj.length = {valueOf: function() {return 1}}  obj.pop() === -1. Actual: ' + pop);
    }
    obj[0] = -1;
    obj.length = {
        valueOf: function () {
            return 1;
        },
        toString: function () {
            return 0;
        }
    };
    var pop = obj.pop();
    if (pop !== -1) {
        testFailed('#0: obj[0] = -1; obj.length = {valueOf: function() {return 1}, toString: function() {return 0}}  obj.pop() === -1. Actual: ' + pop);
    }
    obj[0] = -1;
    obj.length = {
        valueOf: function () {
            return 1;
        },
        toString: function () {
            return {};
        }
    };
    var pop = obj.pop();
    if (pop !== -1) {
        testFailed('#3: obj[0] = -1; obj.length = {valueOf: function() {return 1}, toString: function() {return {}}}  obj.pop() === -1. Actual: ' + pop);
    }
    try {
        obj[0] = -1;
        obj.length = {
            valueOf: function () {
                return 1;
            },
            toString: function () {
                throw 'error';
            }
        };
        var pop = obj.pop();
        if (pop !== -1) {
            testFailed('#4.1: obj[0] = -1; obj.length = {valueOf: function() {return 1}, toString: function() {throw "error"}}; obj.pop() === ",". Actual: ' + pop);
        }
    } catch (e) {
        if (e === 'error') {
            testFailed('#4.2: obj[0] = -1; obj.length = {valueOf: function() {return 1}, toString: function() {throw "error"}}; obj.pop() not throw "error"');
        } else {
            testFailed('#4.3: obj[0] = -1; obj.length = {valueOf: function() {return 1}, toString: function() {throw "error"}}; obj.pop() not throw Error. Actual: ' + e);
        }
    }
    obj[0] = -1;
    obj.length = {
        toString: function () {
            return 0;
        }
    };
    var pop = obj.pop();
    if (pop !== undefined) {
        testFailed('#5: obj[0] = -1; obj.length = {toString: function() {return 0}}  obj.pop() === undefined. Actual: ' + pop);
    }
    obj[0] = -1;
    obj.length = {
        valueOf: function () {
            return {};
        },
        toString: function () {
            return 0;
        }
    };
    var pop = obj.pop();
    if (pop !== undefined) {
        testFailed('#6: obj[0] = -1; obj.length = {valueOf: function() {return {}}, toString: function() {return 0}}  obj.pop() === undefined. Actual: ' + pop);
    }
    try {
        obj[0] = -1;
        obj.length = {
            valueOf: function () {
                throw 'error';
            },
            toString: function () {
                return 0;
            }
        };
        var pop = obj.pop();
        testFailed('#7.1: obj[0] = -1; obj.length = {valueOf: function() {throw "error"}, toString: function() {return 0}}; obj.pop() throw "error". Actual: ' + pop);
    } catch (e) {
        if (e !== 'error') {
            testFailed('#7.2: obj[0] = -1; obj.length = {valueOf: function() {throw "error"}, toString: function() {return 0}}; obj.pop() throw "error". Actual: ' + e);
        }
    }
    try {
        obj[0] = -1;
        obj.length = {
            valueOf: function () {
                return {};
            },
            toString: function () {
                return {};
            }
        };
        var pop = obj.pop();
        testFailed('#8.1: obj[0] = -1; obj.length = {valueOf: function() {return {}}, toString: function() {return {}}}  obj.pop() throw TypeError. Actual: ' + pop);
    } catch (e) {
        if (e instanceof TypeError !== true) {
            testFailed('#8.2: obj[0] = -1; obj.length = {valueOf: function() {return {}}, toString: function() {return {}}}  obj.pop() throw TypeError. Actual: ' + e);
        }
    }
} catch (ex) {
    sputnikException = ex;
}
var successfullyParsed = true;