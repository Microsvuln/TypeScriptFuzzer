var NEAR = 0.000001, FAR = 1e+27;
var screensplit = 0.25, screensplit_right = 0;
var mouse = [
    0.5,
    0.5
];
var zoompos = -100, minzoomspeed = 0.015;
var zoomspeed = minzoomspeed;
var container, stats;
var objects = {};
var labeldata = [
    {
        size: 0.01,
        scale: 0.001,
        label: 'microscopic (1µm)',
        scale: 0.0001
    },
    {
        size: 0.01,
        scale: 0.1,
        label: 'minuscule (1mm)',
        scale: 0.1
    },
    {
        size: 0.01,
        scale: 1,
        label: 'tiny (1cm)',
        scale: 1
    },
    {
        size: 1,
        scale: 1,
        label: 'child-sized (1m)',
        scale: 1
    },
    {
        size: 10,
        scale: 1,
        label: 'tree-sized (10m)',
        scale: 1
    },
    {
        size: 100,
        scale: 1,
        label: 'building-sized (100m)',
        scale: 1
    },
    {
        size: 1000,
        scale: 1,
        label: 'medium (1km)',
        scale: 1
    },
    {
        size: 10000,
        scale: 1,
        label: 'city-sized (10km)',
        scale: 1
    },
    {
        size: 3400000,
        scale: 1,
        label: 'moon-sized (3,400 Km)',
        scale: 1
    },
    {
        size: 12000000,
        scale: 1,
        label: 'planet-sized (12,000 km)',
        scale: 1
    },
    {
        size: 1400000000,
        scale: 1,
        label: 'sun-sized (1,400,000 km)',
        scale: 1
    },
    {
        size: 7470000000000,
        scale: 1,
        label: 'solar system-sized (50Au)',
        scale: 1
    },
    {
        size: 9460528400000000,
        scale: 1,
        label: 'gargantuan (1 light year)',
        scale: 1
    },
    {
        size: 30856775800000000,
        scale: 1,
        label: 'ludicrous (1 parsec)',
        scale: 1
    },
    {
        size: 10000000000000000000,
        scale: 1,
        label: 'mind boggling (1000 light years)',
        scale: 1
    },
    {
        size: 1.135e+21,
        scale: 1,
        label: 'galaxy-sized (120,000 light years)',
        scale: 1
    },
    {
        size: 9.46e+23,
        scale: 1,
        label: '... (100,000,000 light years)',
        scale: 1
    }
];
init();
function init() {
}
function initView(scene, name, logDepthBuf) {
    var framecontainer = document.getElementById('container_' + name);
    var camera = new THREE.PerspectiveCamera(50, screensplit * SCREEN_WIDTH / SCREEN_HEIGHT, NEAR, FAR);
    scene.add(camera);
    var renderer = new THREE.WebGLRenderer({
        antialias: true,
        logarithmicDepthBuffer: logDepthBuf
    });
    renderer.setSize(SCREEN_WIDTH / 2, SCREEN_HEIGHT);
    renderer.domElement.style.position = 'relative';
    renderer.domElement.id = 'renderer_' + name;
    framecontainer.appendChild(renderer.domElement);
    return {
        container: framecontainer,
        renderer: renderer,
        scene: scene,
        camera: camera
    };
}
function initScene(font) {
    var scene = new THREE.Scene();
    var light = new THREE.DirectionalLight(16777215, 1);
    light.position.set(100, 100, 100);
    scene.add(light);
    var materialargs = {
        color: 16777215,
        specular: 328965,
        shininess: 50,
        shading: THREE.SmoothShading,
        emissive: 0
    };
    var meshes = [];
    var coloroffset = 0;
    var colorskip = [
        'black',
        'antiquewhite',
        'bisque',
        'beige',
        'blanchedalmond',
        'darkblue',
        'darkcyan'
    ];
    var colorkeys = Object.keys(THREE.ColorKeywords);
    var geometry = new THREE.SphereBufferGeometry(0.5, 24, 12);
    for (var i = 0; i < labeldata.length; i++) {
        var scale = labeldata[i].scale || 1;
        var labelgeo = new THREE.TextGeometry(labeldata[i].label, {
            font: font,
            size: labeldata[i].size,
            height: labeldata[i].size / 2
        });
        labelgeo.computeBoundingSphere();
        labelgeo.translate(-labelgeo.boundingSphere.radius, 0, 0);
        while (colorskip.indexOf(colorkeys[i + coloroffset]) != -1) {
            coloroffset++;
        }
        materialargs.color = THREE.ColorKeywords[colorkeys[i + coloroffset]];
        var material = new THREE.MeshPhongMaterial(materialargs);
        var group = new THREE.Group();
        group.position.z = -labeldata[i].size * scale;
        scene.add(group);
        var textmesh = new THREE.Mesh(labelgeo, material);
        textmesh.scale.set(scale, scale, scale);
        textmesh.position.z = -labeldata[i].size * scale;
        textmesh.position.y = labeldata[i].size / 4 * scale;
        group.add(textmesh);
        var dotmesh = new THREE.Mesh(geometry, material);
        dotmesh.position.y = -labeldata[i].size / 4 * scale;
        dotmesh.scale.multiplyScalar(labeldata[i].size * scale);
        group.add(dotmesh);
    }
    return scene;
}
function updateRendererSizes() {
    screensplit_right = 1 - screensplit;
    objects.normal.renderer.setSize(screensplit * SCREEN_WIDTH, SCREEN_HEIGHT);
    objects.normal.camera.aspect = screensplit * SCREEN_WIDTH / SCREEN_HEIGHT;
    objects.normal.camera.updateProjectionMatrix();
    objects.normal.camera.setViewOffset(SCREEN_WIDTH, SCREEN_HEIGHT, 0, 0, SCREEN_WIDTH * screensplit, SCREEN_HEIGHT);
    objects.normal.container.style.width = screensplit * 100 + '%';
    objects.logzbuf.renderer.setSize(screensplit_right * SCREEN_WIDTH, SCREEN_HEIGHT);
    objects.logzbuf.camera.aspect = screensplit_right * SCREEN_WIDTH / SCREEN_HEIGHT;
    objects.logzbuf.camera.updateProjectionMatrix();
    objects.logzbuf.camera.setViewOffset(SCREEN_WIDTH, SCREEN_HEIGHT, SCREEN_WIDTH * screensplit, 0, SCREEN_WIDTH * screensplit_right, SCREEN_HEIGHT);
    objects.logzbuf.container.style.width = screensplit_right * 100 + '%';
}
function animate() {
    requestAnimationFrame(animate);
    render();
}
function render() {
    var minzoom = labeldata[0].size * labeldata[0].scale * 1;
    var maxzoom = labeldata[labeldata.length - 1].size * labeldata[labeldata.length - 1].scale * 100;
    var damping = Math.abs(zoomspeed) > minzoomspeed ? 0.95 : 1;
    var zoom = THREE.Math.clamp(Math.pow(Math.E, zoompos), minzoom, maxzoom);
    zoompos = Math.log(zoom);
    if (zoom == minzoom && zoomspeed < 0 || zoom == maxzoom && zoomspeed > 0) {
        damping = 0.85;
    }
    zoompos += zoomspeed;
    zoomspeed *= damping;
    objects.normal.camera.position.x = Math.sin(0.5 * Math.PI * (mouse[0] - 0.5)) * zoom;
    objects.normal.camera.position.y = Math.sin(0.25 * Math.PI * (mouse[1] - 0.5)) * zoom;
    objects.normal.camera.position.z = Math.cos(0.5 * Math.PI * (mouse[0] - 0.5)) * zoom;
    objects.normal.camera.lookAt(objects.normal.scene.position);
    objects.logzbuf.camera.position.copy(objects.normal.camera.position);
    objects.logzbuf.camera.quaternion.copy(objects.normal.camera.quaternion);
    if (screensplit_right != 1 - screensplit) {
        updateRendererSizes();
    }
    objects.normal.renderer.render(objects.normal.scene, objects.normal.camera);
    objects.logzbuf.renderer.render(objects.logzbuf.scene, objects.logzbuf.camera);
    stats.update();
}
function onWindowResize(event) {
    updateRendererSizes();
}
function onBorderMouseDown(ev) {
    ev.stopPropagation();
    ev.preventDefault();
}
function onBorderMouseMove(ev) {
    ev.stopPropagation();
}
function onBorderMouseUp(ev) {
}
function onMouseMove(ev) {
}
function onMouseWheel(ev) {
    var amount = -ev.wheelDeltaY || ev.detail;
    if (amount === 0)
        return;
    var dir = amount / Math.abs(amount);
    zoomspeed = dir / 10;
    minzoomspeed = 0.001;
}