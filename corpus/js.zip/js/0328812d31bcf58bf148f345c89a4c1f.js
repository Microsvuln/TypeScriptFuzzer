//<![CDATA[
var lang_type = '{$lang_type}';
var default_style = '{$mi->default_style}';
var bdBubble,lstViewer,loginNo,bdFiles_type,bdImg_opt,bdImg_link,rd_nav_side;
<!--// 로그인(php5+) -->
<!--@if(!$is_logged)-->
var loginLang = '{$lang->bd_login}';
var loginNo = 1;
<!--@end-->
<!--// 말풍선 -->
<!--@if($mi->bubble=='N' || Mobile::isMobileCheckByAgent())-->
var bdBubble = 0;
<!--@end-->
<!--// 목록에서 뷰어버튼 -->
<!--@if($mi->lst_viewer=='Y')-->
var lstViewer = 1;
var viewerTx = '{$lang->with_viewer}';
<!--@end-->
<!--// 본문 옵션 -->
<!--@if($mi->files_type)-->
var bdFiles_type = 1;
<!--@end-->
<!--@if($mi->img_opt)-->
var bdImg_opt = 1;
<!--@end-->
<!--@if($mi->img_link || !Mobile::isMobileCheckByAgent())-->
var bdImg_link = 0;
<!--@end-->
<!--@if($mi->rd_nav_side || $mi->default_style=='blog' || $mi->default_style=='viewer')-->
var rd_nav_side = 0;
<!--@end-->
//]]>