function main() {
    const v4 = [
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v6 = [
        1337,
        1337,
        1337,
        1337,
        1337
    ];
    const v7 = [
        13.37,
        v6,
        'undefined'
    ];
    const v8 = {};
    const v9 = {};
    let v10 = v4;
    const v15 = [
        1337,
        1337,
        1337,
        1337
    ];
    const v16 = {
        c: 13.37,
        d: 1337,
        valueOf: 'byteLength'
    };
    const v19 = [
        1337,
        1337
    ];
    const v22 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v23 = [];
    let v26 = 0;
    while (v26 < 9) {
        const v27 = v23.push(13.37, 1337);
        const v28 = v26 + 1;
        const v31 = [
            1337,
            1337,
            1337,
            1337
        ];
        const v35 = [];
        let v36 = v35;
        function v37(v38, v39) {
            const v41 = { __proto__: -4294967296 };
            let v42 = v41;
            const v45 = [
                13.37,
                13.37,
                13.37,
                v42,
                13.37
            ];
            const v46 = [];
            let v47 = v46;
            function v48(v49, v50) {
                try {
                    const v53 = [
                        -441746.4139016614,
                        -441746.4139016614,
                        -441746.4139016614,
                        -441746.4139016614,
                        -441746.4139016614
                    ];
                    const v54 = [];
                    let v55 = v54;
                    function v56(v57, v58) {
                        const v62 = String.fromCodePoint(1337);
                        const v64 = v62.padEnd(2147483647, 'number');
                        const v65 = v64.slice(10, 1337);
                    }
                    const v66 = [];
                    let v67 = v66;
                    const v68 = v56(...v67, ...v55, ...v53, 1337, -441746.4139016614);
                } catch (v69) {
                }
            }
            const v70 = [];
            let v71 = v70;
            const v72 = v48(...v71, v47, ...v45, 65537, 13.37);
        }
        let v73 = v31;
        const v74 = v37(...v73, v36, ...'function', 10, 13.37);
        const v79 = [
            -441746.4139016614,
            -441746.4139016614,
            -441746.4139016614,
            -441746.4139016614,
            -441746.4139016614
        ];
        const v80 = [];
        let v81 = v80;
        function v82(v83, v84) {
            const v88 = [
                13.37,
                13.37,
                13.37,
                13.37,
                13.37
            ];
            const v89 = [];
            let v90 = v89;
            function v91(v92, v93) {
                const v96 = [
                    13.37,
                    13.37,
                    13.37,
                    13.37,
                    13.37
                ];
                Symbol.__proto__ = v96;
                const v99 = {
                };
                return v27;
            }
            const v102 = [];
            let v103 = v102;
            const v104 = v91(...v103, v90, ...v88, 10, 13.37);
            return v80;
        }
        const v105 = [];
        let v106 = v105;
        const v107 = v82(...v106, v81, ...v79, 1337, -441746.4139016614);
        v26 = v28;
    }
    let v108 = v23;
    function v109(v110, v111) {
        try {
            for (let v115 = 0; v115 < 100; v115++) {
                function v117(v118, v119) {
                    let v122 = String;
                    const v123 = v122.fromCharCode(255, 255, 100, v115, v118);
                    const v124 = eval(v123);
                    return v115;
                }
            }
            const v125 = [
                v110,
                13.37,
                ...v110,
                v19
            ];
        } catch (v126) {
        }
        const v129 = v109.toLocaleString();
        const v130 = v129.replace(13.37, v108);
        const v131 = eval(v130);
        return v109;
    }
    const v132 = [];
    let v133 = v132;
    const v134 = v109(...v133, v108, ...v22, 10, 13.37);
    const v135 = v19.reduce(v134, v23);
    const v136 = v135();
    const v138 = v136(Promise, v23, 0, 0, v16);
    for (let v142 = 0; v142 < 100; v142++) {
        const v143 = v138(v15, 13.37, 9);
    }
}
main();