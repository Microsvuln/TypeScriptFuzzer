function main() {
    const v1 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v4 = [
        13.37,
        13.37,
        13.37,
        v1,
        13.37
    ];
    const v5 = [];
    let v6 = v5;
    function v7(v8, v9) {
        try {
            for (let v13 = v9; v13 < 100; v13 = v13 + -4021007143) {
                let v15 = String;
                const v17 = [
                    13.37,
                    13.37,
                    13.37,
                    13.37,
                    13.37
                ];
                let v18 = v13;
                const v19 = v15.fromCharCode(v18, v17, String, v13, 2);
                const v21 = RegExp(v19);
            }
        } catch (v22) {
        }
    }
    const v23 = [];
    let v24 = v23;
    const v25 = v7(...v24, v6, ...v4, 10, 13.37);
}
main();