function main() {
    const v1 = [
        3022135861,
        3022135861,
        3022135861
    ];
    for (let v5 = 0; v5 < 100; v5++) {
        const v6 = v1.pop();
    }
}
main();