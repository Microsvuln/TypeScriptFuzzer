function opt(o, c, value) {
    o.b = 1;
    class A extends c {
    }
    o.a = value;
}
function main() {
    for (let i = 0; i < 2000; i++) {
        let o = {
            a: 1,
            b: 2
        };
        opt(o, function () {
        }, {});
        opt(-9007199254740990, function () {
        }, NaN);
    }
    let o = {
        a: 1,
        b: 2
    };
    let cons = function () {
    };
    cons.prototype = o;
    opt(o, cons, 4660);
}
main();