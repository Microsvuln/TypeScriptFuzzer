function benchmark(name, fn, setup) {
    for (var i = 0; i < 100; i++) {
        if (setup) {
            setup();
        }
        fn();
    }
    var t = 0;
    for (var i = 0; i < 100; i++) {
        if (setup) {
            setup();
        }
        fn();
    }
    console.log(name, t / 100 + ' ms/run');
}
var fn = function (e) {
        called += e.count;
    }, fns = [], called = 0;
for (var p = 0; p < 1000; p++) {
    fns.push(function (p) {
        return function (e) {
            called += p;
        };
    });
}
benchmark('Adding same fn', function () {
    for (var p = 0; p < 1000; p++) {
    }
});
benchmark('Adding different fn', function () {
    var fn = function () {
    };
    for (var p = 0; p < 1000; p++) {
    }
});
var fn = function () {
};
for (var p = 0; p < 1000; p++) {
}
benchmark('Fire', function () {
    for (var p = 0; p < 1000; p++) {
    }
});
benchmark('Off', function () {
    var fn = function () {
    };
    for (var p = 0; p < 1000; p++) {
    }
}, function () {
    fns = [];
    for (var p = 0; p < 1000; p++) {
        var fn = function (p) {
            return function () {
                var x = 2 + p;
            };
        }(p);
        fns.push(fn);
    }
});