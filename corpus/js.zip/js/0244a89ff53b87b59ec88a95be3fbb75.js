function log(v) {
    if (v === undefined) {
        document.getElementById('console').value = '';
    } else {
        document.getElementById('console').value += '[' + new Date() + ']' + v + '\n';
    }
}
function async() {
    log();
    log('ASYNC');
    var mcu = new mbedJS.Mcu('192.168.128.39', {
        onNew: function () {
            var pin = new mbedJS.PwmOut(mcu, mbedJS.PinName.p21, {
                onNew: function () {
                    log('[PASS]onNew');
                    pin.write(0.33);
                },
                onWrite: function () {
                    log('[PASS]onwrite:');
                    pin.read();
                },
                onRead: function (v) {
                    log('[PASS]onread:' + v);
                    pin.period(1);
                },
                onPeriod: function () {
                    log('[PASS]onPeriod:');
                    pin.period_ms(1);
                },
                onPeriod_ms: function () {
                    log('[PASS]onPeriod_ms:');
                    pin.period_us(10);
                },
                onPeriod_us: function () {
                    log('[PASS]onPeriod_us:');
                    pin.pulsewidth(3);
                },
                onPulsewidth: function () {
                    log('[PASS]onPulseWidth:');
                    pin.pulsewidth_ms(30);
                },
                onPulsewidth_ms: function () {
                    log('[PASS]onPulseWidth_ms:');
                    pin.pulsewidth_us(40);
                },
                onPulsewidth_us: function () {
                    log('[PASS]onPulseWidth_us:');
                    mcu.close();
                }
            });
        },
        onClose: function () {
            log('[PASS]onClose');
        },
        onError: function () {
            alert('Error');
        }
    });
}
function async2() {
    log();
    log('ASYNC2');
    var mcu = new mbedJS.Mcu('192.168.128.39', {
        onNew: function () {
            var pin = new mbedJS.PwmOut(mcu, mbedJS.PinName.p21, function () {
                log('[PASS]onNew');
                pin.write(0.33, function () {
                    log('[PASS]onwrite:');
                    pin.read(function (v) {
                        log('[PASS]onread:' + v);
                        pin.period(1, function () {
                            log('[PASS]onPeriod:');
                            pin.period_ms(1, function () {
                                log('[PASS]onPeriod_ms:');
                                pin.period_us(10, function () {
                                    log('[PASS]onPeriod_us:');
                                    pin.pulsewidth(3, function () {
                                        log('[PASS]onPulseWidth:');
                                        pin.pulsewidth_ms(30, function () {
                                            log('[PASS]onPulseWidth_ms:');
                                            pin.pulsewidth_us(40, function () {
                                                log('[PASS]onPulseWidth_us:');
                                                mcu.close();
                                            });
                                        });
                                    });
                                });
                            });
                        });
                    });
                });
            });
        },
        onClose: function () {
            log('[PASS]onClose');
        },
        onError: function () {
            alert('Error');
        }
    });
}
function sync() {
    log();
    var g = function* () {
        try {
            var mcu = new mbedJS.Mcu('192.168.128.39', g);
            yield mcu.waitForNew();
            var pin = new mbedJS.PwmOut(mcu, mbedJS.PinName.p21, g);
            log('new');
            yield pin.waitForNew();
            log('waitfor');
            yield pin.write(0.33);
            log('[PASS]write:');
            var v = yield pin.read();
            log('[PASS]read:' + v);
            yield pin.period(1);
            log('[PASS]period:');
            yield pin.period_ms(1);
            log('[PASS]period_ms:');
            yield pin.period_us(10);
            log('[PASS]period_us:');
            yield pin.pulsewidth(3);
            log('[PASS]pulseWidth:');
            yield pin.pulsewidth_ms(30);
            log('[PASS]pulseWidth_ms:');
            yield pin.pulsewidth_us(40);
            log('[PASS]pulseWidth_us:');
            yield mcu.close();
        } catch (e) {
            mcu.shutdown();
            alert(e);
            throw e;
        }
    }();
    g.next();
    return;
}