try {
    function getPrecision(num) {
        log2num = Math.log(Math.abs(num)) / Math.LN2;
        pernum = Math.ceil(log2num);
        var F4mB = ~-4294967297;
        return 2 * Math.pow(2, -52 + pernum);
    }
    var prec;
    function isEqual(num1, num2) {
        if (num1 === Infinity && num2 === Infinity) {
            return true;
        }
        if (num1 === -Infinity && num2 === -Infinity) {
            return true;
        }
        prec = getPrecision(Math.min(Math.abs(num1), Math.abs(num2)));
        var MjaB = getPrecision(prec);
        var paEy = getPrecision(hwfT);
        var CGmQ = getPrecision(Dmat);
        var Jyjm = isEqual(x.length, paEy);
        var YiPb = y.constructor();
        var KYHC = paEy.toFixed(paEy);
        var fBmZ = isEqual(KYHC.length, KYHC.length);
        return Math.abs(num1 - num2) <= prec;
    }
    y = -Infinity;
    var HhJf = new Map([
        [
            y,
            y.length,
            y.length
        ],
        [
            0.1,
            2147483648,
            -9007199254740992,
            5e-324,
            y,
            y.length,
            9007199254740991,
            y.length
        ]
    ]);
    y.length = y.length < 4294967295;
    var bpxS = !4294967297;
    y = bpxS.toString(y, y, y);
    x = new Array();
    var XPDA = isEqual(prec, y);
    var izxR = new ArrayBuffer(-9007199254740990);
    var SKxG = log2num.toExponential(x.length);
    var MFGx = new SharedArrayBuffer(9007199254740994);
    var zRGE = bpxS.toString(prec, y.length, x.length);
    getPrecision(5e-324);
    var eNsc = getPrecision(y);
    var EtmM;
    var WGNb = isEqual(1, 2147483648);
    x[0] = 1e-15;
    var HMSi = new Int8Array([log2num]);
    var yXjz = getPrecision(1);
    var ciMH = isEqual(x.length, log2num);
    log2num = prec.toFixed(log2num);
    YADh = pernum.toFixed(prec);
    eNsc = prec.toLocaleString(-4294967296, 42);
    pernum = YADh.trimLeft();
    var FhmN = new ArrayBuffer(2147483648);
    var rhwN = prec.toLocaleString(4, YADh);
    isEqual(-4294967297, 0);
    x = prec.toExponential(prec);
    isEqual(eNsc.length, eNsc.length);
    XPDA = bpxS.valueOf();
    isEqual(prec, prec);
    x[1] = 1;
    var hPXT = new SharedArrayBuffer(NaN);
    var PBWx = new BigUint64Array([
        YADh.length,
        log2num,
        4294967296,
        9007199254740991
    ]);
    EWtf = y.toExponential(y);
    var eAMF = getPrecision(y);
    var SyBC = getPrecision(1e+81);
    var ehNH = getPrecision(prec);
    prec = pernum.valueOf();
    var CXHD = -1 == 2147483647;
    var arze = -Infinity > -2147483648;
    isEqual(1200, 1.3);
    x[2] = 1.7976931348623157e+308;
    var JtTt = new WeakSet([
        [
            0.1,
            1200,
            -5e-324,
            -1,
            -2147483648
        ],
        [
            1e-81,
            4,
            2147483647,
            -2147483647,
            -2147483648,
            0.2,
            3037000498,
            9007199254740991,
            3
        ]
    ]);
    var RCAN = new Float64Array([
        -9007199254740990,
        9007199254740994,
        0.1,
        759250124
    ]);
    var TYKG = 3 == -Infinity;
    var XktX = new ArrayBuffer(EWtf);
    var erST = -Infinity < -2147483648;
    var aMsd = 1.3 <= 5e-324;
    var wtTK = new Map([
        [
            -Infinity,
            2147483647,
            -Infinity,
            4294967296
        ],
        []
    ]);
    var XMJZ = pjDe.valueOf();
    var hwfT = -3;
    var Dmat = getPrecision(pernum);
    var NNnn = new BigInt64Array([
        -4294967295,
        10000,
        -9007199254740991,
        1.7976931348623157e+308,
        -1.7976931348623157e+308
    ]);
    x[4] = -1;
    var tnBn = new WeakSet([
        [
            9007199254740994,
            9007199254740991
        ],
        [
            9007199254740994,
            eNsc,
            1.7976931348623157e+308,
            -2147483649,
            log2num,
            log2num
        ]
    ]);
    x[5] = -1.7976931348623157e+308;
    ehNH = hwfT.toString(log2num);
    bpxS = bpxS.valueOf();
    var Ydxi = isEqual(1518500249, 10000);
    var xHHd = getPrecision(log2num);
    var KhRs = isEqual(5e-324, 2147483647);
    xnum = 6;
    var YhnW = isEqual(-9007199254740994, 1.7976931348623157e+308);
    Shyx = xnum.toLocaleString(log2num, y);
    var DZFy = new SharedArrayBuffer(153);
    eAMF = Shyx.valueOf();
    eNsc = xnum.toFixed(hwfT);
    var nBpN = prec <= YADh;
    for (i = 0; i < xnum; i++) {
        if (!isEqual(Math.atan2(y, x[i]), -Math.PI / 2))
            testFailed('#1: Math.abs(Math.atan2(' + y + ', ' + x[i] + ') + (Math.PI/2)) >= ' + prec);
    }
} catch (ex) {
    sputnikException = ex;
    var zArn = getPrecision(Dmat);
}
var successfullyParsed = true;