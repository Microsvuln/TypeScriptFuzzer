function main() {
    const v2 = [
        1,
        1,
        1,
        1,
        1
    ];
    const v3 = [];
    let v4 = v3;
    function v5(v6, v7) {
        try {
            const v8 = v5();
        } catch (v9) {
            const v12 = new Uint32Array(1);
            const v13 = v12.copyWithin();
            const v15 = v12.slice(0, v13);
        }
    }
    let v16 = v4;
    const v17 = v5(v16, v4, ...v2, -258611160, 1);
}
main();