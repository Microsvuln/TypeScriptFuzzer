for (var i = 0; i < 1024 * 1024 / 16; i++) {
}
array = new Array(10);
array[0] = 1.1;
array[2] = 2.1;
array[3] = 3.1;
var proto = {};
array.__proto__ = proto;
var Pnhw = new Int8Array([
    -2147483648,
    array
]);
var TaEe = new ArrayBuffer(proto);
var ephj = new ArrayBuffer(4);
var nKpZ = new Map([
    [
        9007199254740991,
        -9007199254740991,
        array.length,
        9007199254740992,
        proto,
        array,
        3.141592653589793,
        0
    ],
    [
        array.length,
        array,
        NaN,
        9007199254740991,
        0,
        -4294967296,
        4,
        array.length,
        array.length
    ]
]);
var AEBs = new Int32Array([
    1e+400,
    4294967297,
    nKpZ,
    nKpZ,
    array,
    9007199254740992,
    2147483647,
    array.length
]);
var rxeP = new Uint16Array([]);
var mRMm = new Float32Array([
    4,
    -9007199254740992,
    759250124,
    proto,
    array,
    -4294967295,
    9007199254740990,
    array.length
]);
mRMm['1'] = ~mRMm['2'];
var QNdd = new Uint8ClampedArray([
    array.length,
    4294967297,
    4294967297,
    1.3
]);
4, 673720360, 9007199254740990, QNdd['2'], 1e+400;
var ctzQ = new Uint32Array([
    3.141592653589793,
    9007199254740992,
    -4294967295,
    4294967296,
    4294967297
]);
var NNeB = new ArrayBuffer(array);
var yEmf = new ArrayBuffer(1.3);
var tbwa = new Uint32Array([
    array.length,
    -Infinity,
    3037000498,
    1518500249,
    proto
]);
var miNB = new Int8Array([
    proto,
    tbwa['1'],
    -5e-324,
    tbwa['0'],
    tbwa['3'],
    tbwa['3'],
    proto,
    tbwa['0']
]);
var tQxJ = new Array([
    proto,
    array,
    array.length,
    NaN,
    proto
]);
var cwrn = new Int32Array([
    array,
    1e+400,
    1e+400,
    proto,
    array,
    153
]);
var nCdh = new Int8Array([
    cwrn['0'],
    cwrn,
    proto,
    array,
    -1,
    10000,
    -4294967296,
    -4294967297,
    NaN
]);
var Apmf = new Map([
    [
        proto,
        0,
        array,
        3037000498
    ],
    []
]);
Object.defineProperty(proto, 1, {
    get() {
        array.length = 1;
        return 'value from proto';
    },
    set(new_value) {
    }
});
Array.prototype.concat.call(array);