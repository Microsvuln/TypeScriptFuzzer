function main() {
    const v3 = {
        length: -1586296134,
        __proto__: -1586296134,
    };
    try {
        const v4 = v3 instanceof isNaN;
    } catch (v5) {
    }
}
main();