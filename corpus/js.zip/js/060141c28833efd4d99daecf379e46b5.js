function testClearAll() {
    delete need$;
    delete codeparse;
    delete lp2fmtree;
    delete metaparse;
    delete MetaDecl;
    delete MetaFunction;
    delete jsm2js;
    delete minify;
    delete test;
    delete fact;
    delete gcd;
    delete isEven;
    delete isOdd;
}
function copyTestHTML(domnode) {
    var SCRIPT_RX = /^script$/i, arr = SCRIPT_RX.test(domnode.tagName) ? [domnode] : domnode.getElementsByTagName('script'), retA = [];
    for (var n = arr.length, i = 0; i < n; i++)
        retA.push(arr[i].outerHTML);
    return retA.join('\n');
}
var global_result = true;
function testRun(globalname, name) {
    name || (name = globalname);
    var f = window[globalname];
    var result, expected = true, duration;
    try {
        var start = new Date();
        result = f();
        duration = new Date() - start;
    } catch (e) {
        result = e !== expected ? e : '<error>';
    }
    var success = result === expected;
    if (!success)
        global_result = false;
    return '<p><code>' + (name || globalname || ('' + f).substring(0, 60) + '...') + ':</code>&nbsp;<span class=\'' + (success ? 'happy\'>success</span>, duration: ' + duration + 'ms' : 'sad\'>failure:<br>' + result + '.</span>') + '</p>';
}