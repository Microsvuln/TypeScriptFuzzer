function fa() {
    return arguments.callee.caller;
}
function fat() {
}
fat();
function Animal() {
    this.species = 'animal';
}
function Cat(name, color) {
    this.name = name;
    this.color = color;
}
Cat.prototype = new Animal();
Cat.prototype.constructor = Cat;
var c = new Cat('猫', '灰色');
function Fish(kind) {
    this.kind = kind;
    Animal.apply(this, []);
    this.show = function () {
    };
}
var fish = new Fish('大尾巴金鱼');
fish.show();
function F() {
}
var xy = {
    x: 'XX',
    y: function () {
        return 'YY';
    }
};
function ef() {
    this.e = 'EE';
    this.f = function () {
        return 'FF';
    };
}
F.prototype = xy;
F.prototype.e = new ef().e;
F.prototype.f = new ef().f;
var f1 = new F();
function _join() {
    var s = Array.prototype.join.call(arguments, '-');
}
_join('q', 'w', 'e');
function BaseClass(name) {
    this.TypeName = name;
    this.writeName = writeName;
    function writeName() {
    }
}
function DeriveClass(name) {
    var base = new BaseClass('Cat');
    base.Name = name;
    base.writeName = writeName;
    function writeName() {
    }
    return base;
}
var base = new BaseClass('Cat');
base.writeName();
var derive = new DeriveClass('Tom');
derive.writeName();
function add(a, b, c) {
    return a + b + c;
}
function minus(a, b) {
    return a - b;
}
function multiple(a, b) {
    return a * b;
}
var caculate = function (fn) {
    return fn.name + ' ' + fn.length;
};
var c = caculate(add);