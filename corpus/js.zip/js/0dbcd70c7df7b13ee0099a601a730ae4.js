function main() {
    const v4 = [
        13.37,
        13.37
    ];
    const v6 = [
        1337,
        1337,
        1337,
        1337,
        1337
    ];
    const v7 = [v4];
    const v8 = {
        toString: 'MWxL*x/uI5',
        length: 13.37,
        constructor: v4,
        e: 1337
    };
    const v9 = {
        constructor: -4294967295,
        toString: 1337,
        c: v8,
        b: 1337
    };
    let v10 = Uint32Array;
    const v15 = [13.37];
    const v17 = [
        1337,
        1337,
        1337,
        1337
    ];
    const v18 = [
        v15,
        1337
    ];
    const v19 = {
        d: Proxy,
        length: 'toStringTag',
        c: v18
    };
    const v20 = {
        e: 1337,
        c: Proxy,
        constructor: Proxy,
        d: 13.37,
        length: v17,
        valueOf: v17,
        a: 13.37
    };
    let v21 = 1337;
    const v26 = [13.37];
    const v28 = [
        6,
        6,
        6,
        6
    ];
    const v29 = ['hasInstance'];
    const v30 = {
        a: 'hasInstance',
        constructor: 13.37
    };
    const v31 = {
        toString: Boolean,
        length: Boolean,
        a: 6,
        d: 13.37,
        e: v28
    };
    let v32 = 'hasInstance';
    const v37 = [13.37];
    const v39 = [
        1337,
        1337,
        1337,
        1337,
        1337
    ];
    const v40 = [v37];
    const v41 = {
        e: 'boolean',
        __proto__: 13.37,
        toString: DataView,
        length: -1308410006
    };
    const v42 = {
        d: 13.37,
        c: 'boolean',
        constructor: v37,
        __proto__: 1337,
        toString: 'boolean',
        a: v39,
        length: DataView
    };
    let v43 = v42;
    const v48 = [
        13.37,
        13.37,
        13.37
    ];
    const v50 = [];
    let v51 = v50;
    function v53(v54, v55) {
        v54.e = 2;
        return 2;
    }
    const v57 = ~1;
    for (let v62 = 0; v62 < 127; v62++) {
        for (let v65 = v57; v65 < 100; v65 = v65 + 10) {
            try {
                let v67 = String;
                const v68 = v67.fromCharCode(v65, v62, v65, v62, 1337);
                const v69 = Function(v68, v65);
                const v70 = new Function(v69);
                v42.constructor = 1337;
                const v71 = v69[v69];
                const v72 = v68 + v65;
                const v73 = v69();
            } catch (v74) {
            }
        }
    }
    const v75 = [1337];
    const v76 = [
        v28,
        v48,
        'function'
    ];
    const v77 = {
        __proto__: v48,
        length: -1769104639,
        valueOf: 13.37,
        a: v75,
        e: -1769104639
    };
    const v78 = { valueOf: v26 };
    let v79 = -1769104639;
    const v83 = [-3179590583];
    const v85 = ~1;
    for (let v89 = 0; v89 < v57; v89 = v89 / 1) {
        try {
            let v91 = Function;
            const v93 = [
                13.37,
                13.37,
                13.37,
                v91,
                13.37
            ];
            let v94 = v89;
            function v95(v96, v97) {
                let v99 = String;
                const v100 = v99.fromCharCode(v96, v89, 1337, v89, 1902352450);
                const v101 = v94[v89];
                const v102 = v91(v100, v101);
                return v96;
            }
            let v103 = v83;
            const v104 = v95(v103, v94, ...v93, 1337, 13.37);
        } catch (v105) {
        }
    }
    const v106 = v76[-536870912];
    v43.__proto__ = -1769104639;
    const v108 = 'boolean'.constructor;
    const v109 = v48 + 1;
    delete v41.__proto__;
    const v111 = v76.constructor;
    const v113 = {
        deleteProperty: v53,
        valueOf: Boolean,
        construct: v53,
        get: Boolean,
        defineProperty: v53,
        preventExtensions: Boolean
    };
    const v115 = new Proxy(v77, v113);
}
main();