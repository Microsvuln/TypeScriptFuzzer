try {
    x = '1';
    x >>>= '1';
    if (x !== 0) {
        testFailed('#1: x = "1"; x >>>= "1"; x === 0. Actual: ' + x);
    }
    x = new String('1');
    x >>>= '1';
    if (x !== 0) {
        testFailed('#2: x = new String("1"); x >>>= "1"; x === 0. Actual: ' + x);
    }
    x = '1';
    x >>>= new String('1');
    if (x !== 0) {
        testFailed('#3: x = "1"; x >>>= new String("1"); x === 0. Actual: ' + x);
    }
    x = new String('1');
    x >>>= new String('1');
    if (x !== 0) {
        testFailed('#4: x = new String("1"); x >>>= new String("1"); x === 0. Actual: ' + x);
    }
    x = 'x';
    x >>>= '1';
    if (x !== 0) {
        testFailed('#5: x = "x"; x >>>= "1"; x === 0. Actual: ' + x);
    }
    x = '1';
    x >>>= 'x';
    if (x !== 1) {
        testFailed('#6: x = "1"; x >>>= "x"; x === 1. Actual: ' + x);
    }
} catch (ex) {
    sputnikException = ex;
}
var successfullyParsed = true;