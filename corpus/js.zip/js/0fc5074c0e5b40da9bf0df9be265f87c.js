function main() {
    const v3 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v4 = [];
    let v5 = v4;
    function v6(v7, v8) {
        let v11 = 0;
        while (v11 < 10) {
            const v12 = v11 + 1;
            v11 = v12;
            const v14 = [
                13.37,
                13.37,
                13.37
            ];
            let v15 = v14;
            const v17 = [
                13.37,
                13.37,
                13.37,
                13.37,
                13.37
            ];
            const v20 = [];
            let v21 = v20;
            function v22(v23, v24) {
                let v27 = 0;
                while (v27 < 10) {
                    const v30 = [
                        v15,
                        1337
                    ];
                    const v31 = {
                        length: v30,
                        c: 1337,
                        e: 5,
                        valueOf: 5,
                        b: 5
                    };
                    const v33 = [];
                    const v34 = new Map(v33);
                    const v35 = v34.set(v30, v31);
                    const v36 = v35.set(v30, 13.37);
                    const v37 = v27 + 1;
                    v27 = v37;
                }
            }
            const v38 = [];
            let v39 = v38;
            const v40 = v22(...v39, v21, ...v17, 10, 13.37);
        }
    }
    const v41 = [];
    let v42 = v41;
    const v43 = v6(...v42, v5, ...v3, 10, 13.37);
}
main();