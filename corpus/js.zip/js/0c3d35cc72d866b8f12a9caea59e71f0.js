function main() {
    const v2 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v3 = [];
    let v4 = v3;
    function v5(v6, v7) {
        try {
            const v10 = [
                -441746.4139016614,
                -441746.4139016614,
                -441746.4139016614,
                -441746.4139016614,
                -441746.4139016614
            ];
            const v11 = [];
            let v12 = v11;
            function v13(v14, v15) {
                const v18 = [
                    13.37,
                    13.37,
                    13.37,
                    13.37,
                    13.37
                ];
                const v19 = [];
                let v20 = v19;
                function v21(v22, v23) {
                    const v26 = [
                        1337,
                        1337,
                        WeakMap,
                        1337,
                        1337
                    ];
                    for (let v31 = 0; v31 < 100; v31++) {
                        try {
                            const v34 = [
                                -441746.4139016614,
                                -441746.4139016614,
                                -441746.4139016614,
                                -441746.4139016614,
                                -441746.4139016614
                            ];
                            const v35 = [];
                            let v36 = v35;
                            function v37(v38, v39) {
                                const v42 = [
                                    719904.8518018327,
                                    719904.8518018327,
                                    719904.8518018327,
                                    719904.8518018327,
                                    719904.8518018327
                                ];
                                const v44 = [];
                                let v45 = v44;
                                function v46(v47, v48) {
                                    const v50 = [
                                        v26,
                                        13.37,
                                        13.37,
                                        13.37,
                                        13.37
                                    ];
                                    const v52 = Int16Array > v50;
                                    try {
                                        const v56 = [
                                            -441746.4139016614,
                                            -441746.4139016614,
                                            -441746.4139016614,
                                            -441746.4139016614,
                                            -441746.4139016614
                                        ];
                                        const v57 = [];
                                        v50[1] = 1000;
                                        v34[100] = Int16Array;
                                        for (const v58 of v47) {
                                            const v59 = {
                                                preventExtensions: v48,
                                                call: v38,
                                                apply: v39,
                                                defineProperty: v46,
                                                getPrototypeOf: v48,
                                                get: v46,
                                                construct: eval,
                                                isExtensible: v58,
                                                has: eval,
                                                setPrototypeOf: v47,
                                                ownKeys: eval
                                            };
                                            const v61 = Proxy(v31, v59);
                                        }
                                        v45 = v46;
                                        const v62 = v57 % v56;
                                        let v65 = 0;
                                        const v66 = v65 + 1;
                                        v65 = v66;
                                    } catch (v67) {
                                    }
                                    const v68 = v46.toLocaleString();
                                    const v69 = v68.substring(1000, 128);
                                    const v70 = eval(v69);
                                }
                                const v71 = [];
                                let v72 = v71;
                                const v73 = v46(...v72, v45, ...v42, 10, 719904.8518018327);
                            }
                            const v74 = [];
                            let v75 = v74;
                            const v76 = v37(...v75, ...v36, ...v34, 1337, -441746.4139016614);
                        } catch (v77) {
                        }
                    }
                }
                const v78 = [];
                let v79 = v78;
                const v80 = v21(...v79, v20, ...v18, 3833039903, 13.37);
            }
            const v81 = [];
            let v82 = v81;
            const v83 = v13(...v82, ...v12, ...v10, 1337, -441746.4139016614);
        } catch (v84) {
        }
    }
    const v85 = [];
    let v86 = v85;
    const v87 = v5(...v86, v4, ...v2, -256, 13.37);
}
main();