function log(msg) {
}
var testString = '';
function attempt(length, expected) {
    log('Attempting to insert ' + length + ' characters.');
    if (testString.length > length)
        testString = '';
    for (var i = testString.length; i < length; ++i)
        testString += i % 10;
        log('PASS');
}
attempt(0, 0);
attempt(5, 5);
attempt(1025, 1025);
attempt(524287, 524287);
attempt(524288, 524288);
attempt(524289, 524288);
attempt(530000, 524288);