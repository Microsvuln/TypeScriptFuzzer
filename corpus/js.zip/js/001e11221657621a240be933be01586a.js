function main() {
    const v3 = [
        1337,
        1337,
        1337
    ];
    const v4 = [
        1337,
        -1203618231,
        v3,
        13.37
    ];
    const v8 = [
        13.37,
        13.37,
        13.37,
        13.37,
        v4
    ];
    function v9(v10, v11) {
        for (let v15 = 0; v15 < 100; v15++) {
            const v18 = [
                String,
                2241179979
            ];
            let v19 = String;
            const v20 = -Infinity;
            const v22 = [
                13.37,
                13.37,
                13.37,
                13.37,
                13.37
            ];
            let v23 = v15;
            const v24 = v19.fromCharCode(v23, v22, String, v20, v18);
            const v25 = [v24];
            const v26 = [v25];
            const v27 = [v26];
            const v29 = JSON.stringify(v27, JSON, v26);
            const v30 = JSON.parse(v29);
        }
    }
    const v31 = [];
    let v32 = v31;
    const v33 = v9(...v32, WeakSet, ...v8, -2, 13.37);
}
main();