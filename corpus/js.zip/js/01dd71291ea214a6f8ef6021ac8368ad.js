function main() {
    const v5 = [
        'function',
        'function',
        1337,
        13.37
    ];
    const v13 = [
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v18 = [
        1337,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v19 = [];
    let v20 = v19;
    function v21(v22, v23) {
        let v26 = 0;
        while (v26 < 10) {
            v22[v22] = 13.37;
            const v27 = v22.__proto__;
            for (const v29 of 'p76QI.ipnu') {
                const v31 = [
                    13.37,
                    13.37,
                    13.37
                ];
                let v34 = 0;
                while (v34 < 10) {
                    let v39 = undefined;
                    if (undefined) {
                        const v40 = v39(v31, 10, undefined);
                    } else {
                    }
                    const v43 = Boolean(56696);
                    const v46 = v34 + 1;
                    v34 = v46;
                }
            }
            v22.length = v26;
            v22.__proto__ = v13;
            const v47 = v26 + 1;
            v26 = v47;
        }
        return v21;
    }
    const v48 = [];
    let v49 = v48;
    const v50 = v21(...v49, v20, ...v18, 10, 13.37);
    let v53 = 0;
    const v54 = v53 + 1;
    v53 = v54;
    const v55 = v50(...v5, 1337);
    const v56 = v21(v48, Symbol);
}
main();