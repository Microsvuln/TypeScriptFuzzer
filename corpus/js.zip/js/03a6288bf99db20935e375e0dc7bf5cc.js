var count = 12000;
while (count--) {
    eval('var a = new Object(10); a[2] += 7;');
    var irpx = !-Infinity;
    var iNkM = ~-Infinity;
    var z7yR = ~-Infinity;
}