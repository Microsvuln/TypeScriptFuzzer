var handler;
var coords = [
    -164.55555725097656,
    2.952378511428833,
    -171.4447021484375,
    32.56910705566406
];
var maxHts = [];
for (var j = 0; j < coords.length / 2; j++) {
    maxHts[j] = 500000;
}