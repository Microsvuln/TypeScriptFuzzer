function main() {
    const v1 = [
        1000000000000,
        1000000000000,
        1000000000000
    ];
    const v4 = new Uint32Array(65537);
    const v5 = v4.set(v1);
}
main();