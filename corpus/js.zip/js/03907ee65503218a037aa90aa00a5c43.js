function main() {
    function v1(v2, v3) {
        const v4 = [arguments];
        const v5 = [v4];
        const v6 = [v5];
        const v8 = JSON.stringify(v6, JSON, v5);
        const v11 = [
            -441746.4139016614,
            -441746.4139016614,
            -441746.4139016614,
            -441746.4139016614,
            -441746.4139016614
        ];
        const v12 = [];
        let v13 = v12;
        function v14(v15, v16) {
            const v18 = [
                1337,
                1337
            ];
            const v21 = [
                13.37,
                13.37,
                13.37,
                13.37,
                13.37
            ];
            const v22 = [];
            let v23 = v8;
            function v24(v25, v26) {
                const v29 = [
                    -441746.4139016614,
                    -441746.4139016614,
                    -441746.4139016614,
                    -441746.4139016614,
                    -441746.4139016614
                ];
                function v30(v31, v32) {
                    const v35 = [
                        -441746.4139016614,
                        -441746.4139016614,
                        -441746.4139016614,
                        -441746.4139016614,
                        -441746.4139016614
                    ];
                    const v36 = [];
                    let v37 = v36;
                    function v38(v39, v40) {
                        for (let v44 = 0; v44 < 100; v44++) {
                            try {
                                const v47 = [
                                    -441746.4139016614,
                                    -441746.4139016614,
                                    -441746.4139016614,
                                    -441746.4139016614,
                                    -441746.4139016614
                                ];
                                const v48 = [];
                                let v49 = v48;
                                function v50(v51, v52) {
                                    const v55 = [
                                        719904.8518018327,
                                        719904.8518018327,
                                        719904.8518018327,
                                        719904.8518018327,
                                        719904.8518018327
                                    ];
                                    const v57 = [1337];
                                    const v58 = [];
                                    let v59 = v58;
                                    function v60(v61, v62) {
                                        v57[13.37] = v62;
                                        const v66 = v60.toLocaleString();
                                        const v67 = v66.substring(1000, v44);
                                        const v68 = Function(v67);
                                    }
                                    const v69 = [];
                                    let v70 = v69;
                                    const v71 = v60(...v70, v59, ...v55, 10, 719904.8518018327);
                                }
                                const v72 = [];
                                let v73 = v72;
                                const v74 = v50(...v73, ...v49, v47, 1337, -441746.4139016614);
                            } catch (v75) {
                            }
                        }
                    }
                    const v76 = [];
                    let v77 = v76;
                    const v78 = v38(...v77, ...v37, ...v35, 1337, -441746.4139016614);
                }
                const v79 = [];
                let v80 = v79;
                const v81 = v30(...v80, ...v29, ...v29, 1337, -441746.4139016614);
                const v84 = v24.toLocaleString();
                const v85 = v84.replace(13.37, v23);
                const v86 = eval(v85);
                return v24;
            }
            let v87 = v18;
            const v88 = v24(...v87, v23, ...v21, 10, 13.37);
            const v89 = v18.reduce(v88, v22);
        }
        const v90 = [];
        let v91 = v90;
        const v92 = v14(...v91, ...v13, ...v11, -2418880158, -441746.4139016614);
    }
    const v93 = v1(arguments);
}
main();