function to_弧度(angle) {
    return angle * Math.PI / 180;
}