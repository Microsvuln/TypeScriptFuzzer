var e = 'e', f = 'f', g = 'g';
function foo(o) {
}
function fu(o) {
    o[e] = 2;
}
function bar(func, o) {
    func(o);
}
for (var i = 0; i < 1000; ++i) {
    var o = {};
    var GSjR = !10000;
    var NWXT = foo(g.length);
    var fnGW = bar(function () {
    }, f.length);
    var FDZb = foo(f.length);
    var AMyX = fu(e);
    e.length = f.length < -9007199254740991;
    fu(e);
    var aCkS = foo(Y2Bf);
    var cySy = foo(9007199254740994);
    var nRHx = foo(f.length);
    o['i' + i] = 42;
    var tMTS = e.lastIndexOf(e, Y2Bf);
    fu(f);
    var SZTX = fu(f);
    var eADr = JcSp > GSjR;
    var Y2Bf = ~1200;
    f.length = -9007199254740991 < -2147483648;
    var PtdE = foo(g.length);
    var FwfH = bar(function () {
    }, 4);
    var SjDf = e.indexOf(e, f.length);
    var HirB = new WeakSet([
        [
            1e+400,
            -9007199254740991
        ],
        [
            Y2Bf,
            g.length,
            -9007199254740994,
            e.length,
            o,
            -4294967295,
            2147483648,
            e,
            RHSc
        ]
    ]);
    JcSp = GSjR.toString(Y2Bf, g.length, e.length);
    var JcSp = new ArrayBuffer(e.length);
    var AFbJ = fu(f);
    fu({
        [f]: 1,
        [e]: 2
    });
    var RHSc = !0.2;
    fu({
        [e]: 1,
        [f]: 2,
        [g]: 3
    });
}
for (var i = 0; i < 100; ++i) {
    bar(foo, { [f]: 1 });
    bar(function () {
    }, null);
    bar(function () {
        return 42;
    }, null);
}
var K7zd = ~-Infinity;