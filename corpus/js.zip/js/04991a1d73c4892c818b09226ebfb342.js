function main() {
    const v2 = [
        Infinity,
        Infinity,
        Infinity,
        Infinity,
        Infinity
    ];
    const v3 = [];
    let v4 = v3;
    function v5(v6, v7) {
        try {
            const v8 = v5();
        } catch (v9) {
            const v12 = [
                1337,
                1337,
                Reflect,
                1337
            ];
            const v13 = v12.constructor;
            const v16 = new Int16Array(45669);
            const v17 = {
                set: v13,
                has: v13,
                getPrototypeOf: v13,
                get: v13,
                setPrototypeOf: v13,
                defineProperty: v13,
                getOwnPropertyDescriptor: v13,
                preventExtensions: v13,
                construct: v13,
                deleteProperty: v13,
                call: v13
            };
            const v19 = new Proxy(v16, v17);
            let v20 = v7;
            delete v19[v20];
        }
    }
    let v21 = v4;
    const v22 = v5(v21, v4, ...v2, -258611160, Infinity);
}
main();