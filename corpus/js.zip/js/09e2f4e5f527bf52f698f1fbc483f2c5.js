function main() {
    try {
        const v2 = [
            -441746.4139016614,
            -441746.4139016614,
            -441746.4139016614,
            -441746.4139016614,
            -441746.4139016614
        ];
        const v3 = [];
        let v4 = v3;
        function v5(v6, v7) {
            const v10 = [
                13.37,
                13.37,
                13.37,
                13.37,
                13.37
            ];
            const v14 = [1337];
            const v15 = [
                2322280097,
                v14
            ];
            const v16 = {
                length: 'undefined',
                c: v15,
                __proto__: v15
            };
            const v18 = [
                1553479343,
                1553479343,
                1553479343,
                1553479343
            ];
            let v19 = v18;
            const v23 = [
                Infinity,
                Infinity,
                Infinity,
                Infinity,
                Infinity
            ];
            const v25 = [
                64,
                v16
            ];
            const v26 = [64];
            const v27 = {
                e: 64,
                __proto__: v25,
                valueOf: Proxy,
                d: -441746.4139016614
            };
            const v29 = v23.toLocaleString(128, 128, v27, v25, v26);
            const v30 = v19.join(v29);
            const v31 = [];
            let v32 = v31;
            function v33(v34, v35) {
                const v37 = [
                    13.37,
                    13.37,
                    13.37,
                    13.37,
                    13.37
                ];
                const v39 = Int16Array > v37;
                for (const v42 of v34) {
                    const v43 = 13.37.lastIndexOf(v42, v30, 128, 1000);
                }
                const v44 = [
                    1000,
                    1000,
                    v33,
                    'undefined'
                ];
                const v46 = [
                    -2.220446049250313e-16,
                    v44
                ];
                const v50 = [
                    13.37,
                    13.37
                ];
                const v52 = [1337];
                const v53 = [
                    undefined,
                    64,
                    v52
                ];
                const v54 = {
                    __proto__: 1337,
                    toString: 1337,
                    c: 13.37,
                    constructor: undefined,
                    valueOf: v52
                };
                const v55 = {
                    e: 64,
                    length: 64,
                    valueOf: v52,
                    __proto__: v53
                };
                let v56 = 13.37;
                const v58 = [
                    13.37,
                    13.37,
                    13.37,
                    13.37,
                    13.37
                ];
                try {
                    const v61 = [
                        13.37,
                        1337,
                        13.37,
                        13.37,
                        13.37
                    ];
                    const v62 = [];
                    let v63 = 2322280097;
                    function v64(v65, v66) {
                        v23[-2147483648] = v66;
                        function v67(v68, v69) {
                        }
                        let v72 = 0;
                    }
                } catch (v73) {
                }
                const v74 = v46.toLocaleString();
                const v75 = v74.substring(1000, v74);
                const v76 = eval(v75);
            }
            const v77 = [];
            let v78 = v77;
            const v79 = v33(...v78, v32, ...v10, 10, 13.37);
        }
        const v80 = [];
        let v81 = v80;
        const v82 = v5(...v81, ...v4, ...v2, 1337, -441746.4139016614);
    } catch (v83) {
    }
}
main();