function main() {
    let v2 = 0;
    while (v2 < 10) {
        function v3(v4, v5, v6, v7, ...v8) {
            const v11 = Math.asinh(Int32Array);
        }
        for (let v24 = 0; v24 < 10; v24++) {
            const v25 = v3();
        }
        const v26 = v2 + 1;
        v2 = v26;
    }
}
main();