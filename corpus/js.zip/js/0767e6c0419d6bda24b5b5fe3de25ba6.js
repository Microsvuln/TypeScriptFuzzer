function main() {
    const v3 = [
        1337,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v4 = [];
    let v5 = v4;
    function v6(v7, v8) {
        let v11 = 0;
        while (v11 < 10) {
            const v15 = 1337[eval];
            const v18 = {
                setPrototypeOf: String,
                apply: String,
                has: String,
                preventExtensions: String,
                defineProperty: String,
                getPrototypeOf: String
            };
            try {
                const v19 = 1337 instanceof v18;
            } catch (v20) {
            }
            const v22 = v11 / v11;
            for (let v24 = 0; v24 < 1337; v24++) {
            }
            const v25 = v11 + 1;
            v11 = v25;
        }
    }
    const v26 = [];
    let v27 = v26;
    const v28 = v6(...v27, v5, ...v3, 10, 13.37);
    const v32 = v6(...v5);
}
main();