function main() {
    let v1 = '/6q09ACDCq';
    const v4 = [
        v1,
        -441746.4139016614,
        -441746.4139016614,
        -441746.4139016614,
        -441746.4139016614
    ];
    const v5 = [];
    let v6 = v5;
    function v7(v8, v9) {
        const v12 = [
            719904.8518018327,
            719904.8518018327,
            719904.8518018327,
            719904.8518018327,
            719904.8518018327
        ];
        const v13 = [];
        let v14 = v13;
        function v15(v16, v17) {
            const v20 = [
                1337,
                1337
            ];
            const v23 = [
                13.37,
                13.37,
                13.37,
                13.37,
                13.37
            ];
            const v24 = [];
            let v25 = v24;
            function v26(v27, v28) {
                const v31 = [];
                let v32 = v31;
                function v33(v34, v35) {
                    for (let v38 = v5; v38 < 100; v38 = v38 + -9007199254740992) {
                        const v39 = 13.37 - v38;
                        const v41 = [
                            13.37,
                            13.37,
                            13.37,
                            13.37,
                            13.37
                        ];
                    }
                }
                const v42 = [];
                let v43 = v42;
                const v44 = v33(...v43, ...v32, ...v23, 1337, -441746.4139016614);
                const v47 = v26.toLocaleString();
                const v48 = v47.replace(13.37, v25);
                const v49 = eval(v48);
                return v26;
            }
            const v50 = [];
            let v51 = v50;
            const v52 = v26(...v51, v25, ...v23, 10, 13.37);
            const v53 = v20.some(v52, v24);
        }
        const v54 = [];
        let v55 = v54;
        const v56 = v15(...v55, v14, ...v12, 10, 719904.8518018327);
    }
    const v57 = [];
    let v58 = v57;
    const v59 = v7(...v58, ...v6, ...v4, 2739878671, -441746.4139016614);
}
main();