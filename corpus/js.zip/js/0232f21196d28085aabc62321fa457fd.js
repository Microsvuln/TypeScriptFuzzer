function main() {
    const v3 = [
        1337,
        1337,
        1337
    ];
    const v4 = [
        -4060377408,
        13.37
    ];
    const v5 = {
        d: v4,
        e: 13.37,
        a: 1337,
        valueOf: -4060377408,
        toString: -4060377408,
        b: v3
    };
    let v6 = v4;
    const v7 = {};
    for (let v11 = 0; v11 != 100; v11++) {
        const v13 = [
            13.37,
            13.37,
            13.37,
            13.37,
            13.37
        ];
        const v14 = [];
        let v15 = v14;
        function v16(v17, v18) {
            try {
                const v21 = [
                    13.37,
                    13.37,
                    13.37,
                    13.37,
                    13.37
                ];
                let v22 = v7;
                function v23(v24, v25) {
                    const v27 = [328696.5167743738];
                    try {
                        const v31 = [
                            2.220446049250313e-16,
                            2.220446049250313e-16,
                            2.220446049250313e-16,
                            2.220446049250313e-16,
                            2.220446049250313e-16
                        ];
                        const v32 = [];
                        let v33 = v32;
                        let v34 = 13.37;
                        function v35(v36, v37) {
                            const v39 = -Infinity;
                            const v40 = [
                                v39,
                                v39,
                                v39,
                                v39,
                                2.220446049250313e-16
                            ];
                            const v41 = [];
                            let v42 = v41;
                            function v43(v44, v45) {
                                function v48(v49, v50, v51) {
                                    const v52 = new v36(1000, v49, v34, v39);
                                    return v52;
                                }
                                const v53 = v43.toLocaleString();
                                const v54 = v53.padEnd(1000, v53);
                                const v55 = eval(v54);
                                const v56 = typeof v40;
                                const v57 = !v40;
                                v5.length = -2147483648;
                                const v59 = {};
                                return v27;
                            }
                            const v60 = [];
                            let v61 = v60;
                            const v62 = v43(...v61, v42, ...v40, 10, v39);
                        }
                        const v63 = [];
                        let v64 = v63;
                        const v65 = v35(v64, v33, ...v31, 1337, 2.220446049250313e-16);
                    } catch (v66) {
                    }
                }
                const v67 = [];
                let v68 = v67;
                const v69 = v23(...v68, v22, ...v21, 1337, 13.37);
            } catch (v70) {
            }
        }
        const v71 = [];
        let v72 = v71;
        const v73 = v16(...v72, v15, ...v13, v72, 13.37);
    }
}
main();