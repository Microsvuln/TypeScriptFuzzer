var input = {
    a: {
        0: 'hello',
        x: 'from',
        2: 'javascript',
        z: 'language'
    },
    b: {
        c: { d: { 2: 'two' } },
        3: 'three'
    },
    c: {
        0: 'one',
        1: 'two',
        2: 'three'
    }
};
console.log('input', input);