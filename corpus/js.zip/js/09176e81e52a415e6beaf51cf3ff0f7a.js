function main() {
    const v2 = [13.37];
    for (let v7 = 0; v7 < 127; v7++) {
        for (let v9 = 1; v9 <= 100; v9 = v9 + 13.37) {
            try {
                let v11 = String;
                const v12 = v11.fromCharCode(100, v7, v2, v9, v7);
                const v13 = eval(v12);
            } catch (v14) {
            }
        }
    }
}
main();