var arr, i;
arr = [
    1,
    2,
    3,
    4,
    5
];
i = 1;
try {
    for (eval('i in arr'); 1;) {
        break;
    }
    ;
} catch (e) {
    $ERROR('#1.1: for(eval("i in arr");1;) {break;}; does not lead to throwing exception');
}
try {
    for (eval('var i = 1 in arr'); 1;) {
        break;
    }
    ;
} catch (e) {
    $ERROR('#2.1: for(eval("var i = 1 in arr");1;) {break;}; does not lead to throwing exception');
}
try {
    for (eval('1 in arr'); 1;) {
        break;
    }
    ;
} catch (e) {
    $ERROR('#3.1: for(eval("1 in arr");1;) {break;}; does not lead to throwing exception');
}