function main() {
    const v0 = [];
    const v3 = [
        -2,
        -2,
        -2,
        -2,
        -2
    ];
    const v4 = [];
    let v5 = v4;
    function v6(v7, v8) {
        for (let v12 = 0; v12 < 8; v12++) {
            const v16 = [
                1337,
                13.37,
                13.37,
                13.37,
                13.37
            ];
            const v17 = [];
            let v18 = v17;
            function v19(v20, v21) {
                let v24 = 0;
                while (v24 < 10) {
                    let v28 = 0;
                    const v32 = [
                        1337,
                        1337
                    ];
                    const v33 = [
                        v32,
                        v32,
                        13.37
                    ];
                    function v34(v35, v36) {
                    }
                    const v38 = v34 | v33;
                    const v39 = Math.expm1(0, v38);
                    const v40 = v28 + 1;
                    v28 = v40;
                    const v43 = v24 + 1;
                    v24 = v43;
                }
            }
            const v44 = [];
            let v45 = v44;
            let v48 = 0;
            let v51 = 0;
            const v52 = v51 + 1;
            v51 = v52;
            const v53 = v48 + 1;
            v48 = v53;
            const v54 = v19(...v45, v18, ...v16, 10, 13.37);
        }
    }
    const v55 = [];
    let v56 = v55;
    const v57 = v6(...v56, v5, ...v3, 10, -2);
}
main();