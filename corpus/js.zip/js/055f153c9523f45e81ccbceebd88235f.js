var ninja = { foo: 'bar' }, value, maxCount = 1000000, n, start, elapsed;
start = new Date().getTime();
for (n = 0; n < maxCount; n++) {
    value = ninja.foo;
}
elapsed = new Date().getTime() - start;
start = new Date().getTime();
with (ninja) {
    for (n = 0; n < maxCount; n++) {
        value = foo;
    }
}
elapsed = new Date().getTime() - start;
start = new Date().getTime();
with (ninja) {
    for (n = 0; n < maxCount; n++) {
        foo = n;
    }
}
elapsed = new Date().getTime() - start;
start = new Date().getTime();
with (ninja) {
    for (n = 0; n < maxCount; n++) {
        value = 'no test';
    }
}
elapsed = new Date().getTime() - start;