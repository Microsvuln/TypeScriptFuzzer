function main() {
    const v5 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v6 = [];
    let v7 = v6;
    function v8(v9, v10) {
        const v13 = 2147483647 >> 7;
        let v15 = 0;
        while (v15 < v13) {
            const v16 = v15 + 1;
            v15 = v16;
        }
        const v17 = v10 & v13;
        return v7;
    }
    const v18 = [];
    let v19 = v18;
    const v20 = v8(...v19, v7, ...v5, 10, 13.37);
    for (let v27 = 0; v27 < 127; v27++) {
        for (let v31 = 2; v31 < 100; v31 = v31 + 10) {
            try {
                let v33 = String;
                const v34 = v33.fromCharCode(9, v27, v31, v31, v27);
                const v35 = eval(v34);
            } catch (v36) {
            }
        }
    }
    const v37 = v8(13.37);
}
main();