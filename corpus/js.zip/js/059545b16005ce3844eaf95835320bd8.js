function main() {
    const v2 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v3 = [];
    let v4 = v3;
    function v5(v6, v7) {
        for (let v11 = 0; v11 < 8; v11++) {
            for (let v15 = 0; v15 < 5; v15++) {
                const v18 = [
                    1337,
                    1337
                ];
                const v21 = [
                    13.37,
                    13.37,
                    13.37,
                    13.37,
                    13.37
                ];
                const v22 = [];
                let v23 = v22;
                function v24(v25, v26) {
                    const v29 = [
                        -441746.4139016614,
                        -441746.4139016614,
                        -441746.4139016614,
                        -441746.4139016614,
                        -441746.4139016614
                    ];
                    const v30 = [];
                    let v31 = v30;
                    function v32(v33, v34) {
                        const v37 = [
                            -441746.4139016614,
                            -441746.4139016614,
                            -441746.4139016614,
                            -441746.4139016614,
                            -441746.4139016614
                        ];
                        const v38 = [];
                        let v39 = v38;
                        function v40(v41, v42) {
                            const v43 = 13.37 - v26;
                            const v45 = [
                                13.37,
                                13.37,
                                13.37,
                                13.37,
                                13.37
                            ];
                            return v43;
                        }
                        const v46 = [];
                        let v47 = v46;
                        const v48 = v40(...v47, ...v39, ...v37, 1337, -441746.4139016614);
                    }
                    const v49 = [];
                    let v50 = v49;
                    const v51 = v32(...v50, ...v31, ...v29, 1337, -441746.4139016614);
                    const v54 = v24.toLocaleString();
                    const v55 = v54.replace(13.37, v23);
                    const v56 = eval(v55);
                    return v24;
                }
                const v57 = [];
                let v58 = v57;
                const v59 = v24(...v58, v23, ...v21, 10, 13.37);
                const v60 = v18.shift(v59, v22);
                const v61 = v59(v22, v60);
            }
            let v64 = 0;
            const v65 = v64 + 1;
            v64 = v65;
        }
    }
    const v152 = [];
    let v153 = v152;
    const v154 = v5(...v153, v4, ...v2, 10, 13.37);
}
main();