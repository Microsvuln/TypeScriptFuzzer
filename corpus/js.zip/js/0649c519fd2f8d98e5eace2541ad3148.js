var intervalID;
function keypress() {
    if (event.keyCode == 13) {
        get_package();
    }
}
function get_package() {
    $('#console').empty();
    $('#download ul').empty();
    var package = $('#package').val();
    console.log(package);
    if (package == '') {
        alert('请输入包名称');
        return;
    } else if (package.indexOf('/') == -1) {
        alert('请输入正确的第三方包名');
        return;
    }
    var sock = null;
    var wsurl = 'ws://www.golangtc.com:8888/get/package';
    try {
        sock = new WebSocket(wsurl);
    } catch (e) {
        alert(e.Message);
    }
    sock.onopen = function () {
        console.log('connected to ' + wsurl);
        $('#console').append('$ go get -u -v ' + package + '\n');
        sock.send(package);
        intervalID = setInterval(displayProcess, 1000);
    };
    sock.onerror = function (e) {
        console.log('err from connect ' + e);
    };
    sock.onclose = function (e) {
        console.log('connection closed (' + e.code + ')');
    };
    sock.onmessage = function (e) {
        console.log('message received: ' + e.data);
        var data = eval('(' + e.data + ')');
        if (data.type == 'output') {
            $('#console').append(data.msg + '\n');
        } else if (data.type == 'command') {
            $('#console').append('$ ' + data.msg + '\n');
        } else if (data.type == 'download') {
            $('#download ul').append('<li><a href="/static/download/packages/' + data.msg.replace(/\//g, '.') + '.tar.gz' + '" target="_blank">' + data.msg + '</li>');
        } else if (data.type == 'completed') {
            $('#console').append('<strong>' + data.msg + '</strong>\n');
            clearInterval(intervalID);
            $('#waiting').empty();
        } else if (data.type == 'error') {
            $('#console').append('<span style="color: red;">' + data.msg + '</span>\n');
            clearInterval(intervalID);
            $('#waiting').empty();
        }
        $('#console-wrap').scrollTop($('#console')[0].scrollHeight);
    };
}
function input_package(name) {
    $('#package').val(name);
}
function displayProcess() {
    $('#waiting').append('.');
}