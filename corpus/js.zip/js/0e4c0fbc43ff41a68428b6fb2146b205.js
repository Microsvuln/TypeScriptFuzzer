function main() {
"function".toString = 8;
const v8 = Float32Array >> "function";
// v8 = .integer
const v9 = !8;
// v9 = .boolean
const v10 = Float32Array["toString"];
// v10 = .unknown
let v11 = 1;
if (v10) {
    const v12 = "toString".padEnd(v8,"function");
    // v12 = .string + .object(ofGroup: String, withProperties: ["constructor", "__proto__", "length"], withMethods: ["concat", "indexOf", "padEnd", "trim", "lastIndexOf", "includes", "charCodeAt", "endsWith", "substring", "repeat", "charAt", "split", "padStart", "startsWith", "replace", "slice", "codePointAt"])
    v11 = Float32Array;
} else {
    "function".constructor = "toString";
    v11 = v10;
}
for (let v13 = 0; v13 != 8; v13++) {
    let v18 = -3479607989;
    function v22(v23,v24,v25,v26) {
        const v29 = [13.37,13.37,13.37,13.37,v26];
        // v29 = .object(ofGroup: Array, withProperties: ["__proto__", "constructor", "length"], withMethods: ["includes", "fill", "reduceRight", "join", "pop", "reduce", "reverse", "copyWithin", "sort", "some", "indexOf", "every", "flatMap", "filter", "map", "splice", "findIndex", "toString", "keys", "flat", "slice", "toLocaleString", "entries", "concat", "push", "unshift", "forEach", "shift", "find", "values", "lastIndexOf"])
        const v30 = [];
        // v30 = .object(ofGroup: Array, withProperties: ["__proto__", "constructor", "length"], withMethods: ["includes", "fill", "reduceRight", "join", "pop", "reduce", "reverse", "copyWithin", "sort", "some", "indexOf", "every", "flatMap", "filter", "map", "splice", "findIndex", "toString", "keys", "flat", "slice", "toLocaleString", "entries", "concat", "push", "unshift", "forEach", "shift", "find", "values", "lastIndexOf"])
        let v31 = v30;
        function v32(v33,v34) {
        }
        let v35 = v31;
        const v36 = v32(...v35,v31,...v29,10,13.37);
        // v36 = .unknown
    }
    for (let v40 = 0; v40 < 100; v40++) {
        const v41 = v22(1337,v18,-1024,0);
        // v41 = .unknown
    }
}
const v42 = [13.37,13.37,13.37,13.37];
// v42 = .object(ofGroup: Array, withProperties: ["__proto__", "constructor", "length"], withMethods: ["includes", "fill", "reduceRight", "join", "pop", "reduce", "reverse", "copyWithin", "sort", "some", "indexOf", "every", "flatMap", "filter", "map", "splice", "findIndex", "toString", "keys", "flat", "slice", "toLocaleString", "entries", "concat", "push", "unshift", "forEach", "shift", "find", "values", "lastIndexOf"])
const v44 = [1337,1337,1337,1337,1337];
// v44 = .object(ofGroup: Array, withProperties: ["__proto__", "constructor", "length"], withMethods: ["includes", "fill", "reduceRight", "join", "pop", "reduce", "reverse", "copyWithin", "sort", "some", "indexOf", "every", "flatMap", "filter", "map", "splice", "findIndex", "toString", "keys", "flat", "slice", "toLocaleString", "entries", "concat", "push", "unshift", "forEach", "shift", "find", "values", "lastIndexOf"])
const v45 = ["function","function",1337,13.37];
// v45 = .object(ofGroup: Array, withProperties: ["__proto__", "constructor", "length"], withMethods: ["includes", "fill", "reduceRight", "join", "pop", "reduce", "reverse", "copyWithin", "sort", "some", "indexOf", "every", "flatMap", "filter", "map", "splice", "findIndex", "toString", "keys", "flat", "slice", "toLocaleString", "entries", "concat", "push", "unshift", "forEach", "shift", "find", "values", "lastIndexOf"])
const v46 = {valueOf:v44,c:v44};
// v46 = .object(ofGroup: Object, withProperties: ["__proto__", "valueOf", "c"])
const v47 = {};
// v47 = .object(ofGroup: Object, withProperties: ["__proto__"])
let v48 = Float32Array;
let v51 = 0;
do {
    const v54 = [13.37,13.37,13.37,13.37,13.37];
    // v54 = .object(ofGroup: Array, withProperties: ["__proto__", "constructor", "length"], withMethods: ["includes", "fill", "reduceRight", "join", "pop", "reduce", "reverse", "copyWithin", "sort", "some", "indexOf", "every", "flatMap", "filter", "map", "splice", "findIndex", "toString", "keys", "flat", "slice", "toLocaleString", "entries", "concat", "push", "unshift", "forEach", "shift", "find", "values", "lastIndexOf"])
    const v55 = [];
    // v55 = .object(ofGroup: Array, withProperties: ["__proto__", "constructor", "length"], withMethods: ["includes", "fill", "reduceRight", "join", "pop", "reduce", "reverse", "copyWithin", "sort", "some", "indexOf", "every", "flatMap", "filter", "map", "splice", "findIndex", "toString", "keys", "flat", "slice", "toLocaleString", "entries", "concat", "push", "unshift", "forEach", "shift", "find", "values", "lastIndexOf"])
    let v56 = v55;
    function v57(v58,v59) {
        function v61(v62,v63) {
            const v64 = "string" + 1;
            // v64 = .primitive
            let v66 = arguments;
            let v69 = 0;
            const v73 = v69 + 1;
            // v73 = .primitive
            v69 = v73;
            return 0;
        }
        const v74 = v61();
        // v74 = .unknown
        for (const v75 of v54) {
            const v76 = {length:v75,c:"toString",...v9};
            // v76 = .object(ofGroup: Object, withProperties: ["length", "c", "__proto__"])
        }
        const v77 = v54.__proto__;
        // v77 = .object()
        const v78 = typeof v56;
        // v78 = .string
        const v82 = new Uint32Array(11105);
        // v82 = .object(ofGroup: Uint32Array, withProperties: ["byteOffset", "buffer", "byteLength", "__proto__", "constructor", "length"], withMethods: ["findIndex", "fill", "includes", "keys", "copyWithin", "set", "lastIndexOf", "filter", "indexOf", "map", "reduce", "every", "some", "find", "entries", "reduceRight", "forEach", "reverse", "subarray", "join", "sort", "values", "slice"])
        for (const v83 of v82) {
        }
    }
    const v84 = [];
    // v84 = .object(ofGroup: Array, withProperties: ["__proto__", "constructor", "length"], withMethods: ["includes", "fill", "reduceRight", "join", "pop", "reduce", "reverse", "copyWithin", "sort", "some", "indexOf", "every", "flatMap", "filter", "map", "splice", "findIndex", "toString", "keys", "flat", "slice", "toLocaleString", "entries", "concat", "push", "unshift", "forEach", "shift", "find", "values", "lastIndexOf"])
    let v85 = v84;
    const v86 = v57(...v85,v56,...v54,10,13.37);
    // v86 = .unknown
    const v87 = v51 + 1;
    // v87 = .primitive
    v51 = v87;
} while (v51 < 10);
}
main();
