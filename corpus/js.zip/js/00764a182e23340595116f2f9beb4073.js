function main() {
    try {
        const v2 = [
            13.37,
            13.37,
            13.37,
            13.37,
            13.37
        ];
        let v3 = v2;
        function v4(v5, v6) {
            let v10 = 13.37;
            const v11 = new String(v10);
            const v12 = v11.slice(4017745480, v11);
            v2.toString = v4;
            const v15 = [
                13.37,
                13.37,
                13.37,
                13.37,
                13.37
            ];
            const v16 = [];
            let v17 = v16;
            function v18(v19, v20) {
                const v22 = 0 - v2;
            }
            const v23 = [];
            let v24 = v23;
            const v25 = v18(...v24, v17, ...v15, 10, 13.37);
        }
        const v26 = [];
        let v27 = v26;
        const v28 = v4(...v27, v3, ...v2, 1337, 13.37);
    } catch (v29) {
    }
}
main();