function main() {
    const v1 = [
        1337,
        1337
    ];
    const v4 = ~1;
    for (let v14 = 0; v14 < 127; v14++) {
        for (let v16 = v4; v16 < 100; v16 = v16 + 13.37) {
            try {
                let v18 = String;
                const v19 = v18.fromCharCode(13.37, v14, v16, v16, v4);
                const v20 = Function(v19, v16);
            } catch (v21) {
            }
        }
    }
}
main();