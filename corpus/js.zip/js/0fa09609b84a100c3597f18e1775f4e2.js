try {
    var obj = {};
    obj.unshift = Array.prototype.unshift;
    obj.length = {
        valueOf: function () {
            return 3;
        }
    };
    var unshift = obj.unshift();
    if (unshift !== 3) {
        testFailed('#1:  obj.length = {valueOf: function() {return 3}}  obj.unshift() === 3. Actual: ' + unshift);
    }
    obj.length = {
        valueOf: function () {
            return 3;
        },
        toString: function () {
            return 1;
        }
    };
    var unshift = obj.unshift();
    if (unshift !== 3) {
        testFailed('#0:  obj.length = {valueOf: function() {return 3}, toString: function() {return 1}}  obj.unshift() === 3. Actual: ' + unshift);
    }
    obj.length = {
        valueOf: function () {
            return 3;
        },
        toString: function () {
            return {};
        }
    };
    var unshift = obj.unshift();
    if (unshift !== 3) {
        testFailed('#1:  obj.length = {valueOf: function() {return 3}, toString: function() {return {}}}  obj.unshift() === 3. Actual: ' + unshift);
    }
    try {
        obj.length = {
            valueOf: function () {
                return 3;
            },
            toString: function () {
                throw 'error';
            }
        };
        var unshift = obj.unshift();
        if (unshift !== 3) {
            testFailed('#4.1:  obj.length = {valueOf: function() {return 3}, toString: function() {throw "error"}}; obj.unshift() === ",". Actual: ' + unshift);
        }
    } catch (e) {
        if (e === 'error') {
            testFailed('#4.2:  obj.length = {valueOf: function() {return 3}, toString: function() {throw "error"}}; obj.unshift() not throw "error"');
        } else {
            testFailed('#4.3:  obj.length = {valueOf: function() {return 3}, toString: function() {throw "error"}}; obj.unshift() not throw Error. Actual: ' + e);
        }
    }
    obj.length = {
        toString: function () {
            return 1;
        }
    };
    var unshift = obj.unshift();
    if (unshift !== 1) {
        testFailed('#5:  obj.length = {toString: function() {return 1}}  obj.unshift() === 1. Actual: ' + unshift);
    }
    obj.length = {
        valueOf: function () {
            return {};
        },
        toString: function () {
            return 1;
        }
    };
    var unshift = obj.unshift();
    if (unshift !== 1) {
        testFailed('#6:  obj.length = {valueOf: function() {return {}}, toString: function() {return 1}}  obj.unshift() === 1. Actual: ' + unshift);
    }
    try {
        obj.length = {
            valueOf: function () {
                throw 'error';
            },
            toString: function () {
                return 1;
            }
        };
        var unshift = obj.unshift();
        testFailed('#7.1:  obj.length = {valueOf: function() {throw "error"}, toString: function() {return 1}}; obj.unshift() throw "error". Actual: ' + unshift);
    } catch (e) {
        if (e !== 'error') {
            testFailed('#7.2:  obj.length = {valueOf: function() {throw "error"}, toString: function() {return 1}}; obj.unshift() throw "error". Actual: ' + e);
        }
    }
    try {
        obj.length = {
            valueOf: function () {
                return {};
            },
            toString: function () {
                return {};
            }
        };
        var unshift = obj.unshift();
        testFailed('#8.1:  obj.length = {valueOf: function() {return {}}, toString: function() {return {}}}  obj.unshift() throw TypeError. Actual: ' + unshift);
    } catch (e) {
        if (e instanceof TypeError !== true) {
            testFailed('#8.2:  obj.length = {valueOf: function() {return {}}, toString: function() {return {}}}  obj.unshift() throw TypeError. Actual: ' + e);
        }
    }
} catch (ex) {
    sputnikException = ex;
}
var successfullyParsed = true;