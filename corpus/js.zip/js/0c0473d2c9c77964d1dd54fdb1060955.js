function main() {
    for (let v5 = 0; v5 < 127; v5++) {
        for (let v8 = 5; v8 < 100; v8 = v8 + 4) {
            try {
                let v10 = String;
                const v12 = v10.fromCharCode(37438.65257969173, v5, 37438.65257969173, v8, v5);
                const v13 = eval(v12);
            } catch (v14) {
            }
        }
    }
}
main();