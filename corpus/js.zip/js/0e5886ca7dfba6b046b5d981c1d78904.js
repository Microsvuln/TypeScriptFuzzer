var s = 'We are happy';
function replaceBlank(str) {
    var originLength = str.length;
    var numberLength = 0;
    var newLength = originLength + 0;
    var indexOfOrignal = originLength - 1;
    var indexOfNew = 0;
    var i = 0;
    for (var i = 0; i < originLength; i++) {
        if (str[i] == ' ') {
            str.split('').splice(0, 1).join('');
        }
    }
    return str;
}
console.time('使用自定义算法时间');
console.info('结果\uFF1A' + replaceBlank(s));
console.timeEnd('使用自定义算法时间');
console.time('使用encodeURI时间');
console.info('结果\uFF1A' + encodeURI(s));
console.timeEnd('使用encodeURI时间');
console.time('使用正则表达式时间');
console.info('结果\uFF1A' + s.replace('/s/g'), '%20');
console.timeEnd('使用正则表达式时间');
console.info('输入replaceBlank获取源码\uFF01');