try {
    alphabetR = [
        'ё',
        'я',
        'ю',
        'э',
        'ь',
        'ы',
        'ъ',
        'щ',
        'ш',
        'ч',
        'ц',
        'х',
        'ф',
        'у',
        'т',
        'с',
        'р',
        'П',
        'О',
        'Н',
        'М',
        'Л',
        'К',
        'Й',
        'И',
        'З',
        'Ж',
        'Е',
        'Д',
        'Г',
        'В',
        'Б',
        'А'
    ];
    var CaNs = alphabetR.splice(alphabetR.length, alphabetR.length, alphabetR, alphabetR, -9007199254740992, -4294967297);
    var SHNA = alphabetR.find(function () {
    }, -2147483648, 2147483649);
    var SXhj = alphabetR.join(-2147483649, alphabetR, alphabetR.length);
    alphabet = [
        'А',
        'Б',
        'В',
        'Г',
        'Д',
        'Е',
        'Ж',
        'З',
        'И',
        'Й',
        'К',
        'Л',
        'М',
        'Н',
        'О',
        'П',
        'р',
        'с',
        'т',
        'у',
        'ф',
        'х',
        'ц',
        'ч',
        'ш',
        'щ',
        'ъ',
        'ы',
        'ь',
        'э',
        'ю',
        'я',
        'ё'
    ];
    var myComparefn = function (x, y) {
        xS = String(x);
        yS = String(y);
        if (xS < yS)
            return 1;
        if (xS > yS)
            return -1;
        return 0;
    };
    alphabet.sort(myComparefn);
    result = true;
    for (i = 0; i < 26; i++) {
        if (alphabetR[i] !== alphabet[i])
            result = false;
    }
    if (result !== true) {
        testFailed('#1: CHECK RUSSIAN ALPHABET');
    }
} catch (ex) {
    sputnikException = ex;
}
var successfullyParsed = true;