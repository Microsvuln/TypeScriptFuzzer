function main() {
    const v5 = [
        1337,
        1337,
        1337,
        1337
    ];
    const v6 = {
        c: 13.37,
        d: 1337,
        valueOf: 'byteLength'
    };
    const v9 = [
        1337,
        1337
    ];
    const v12 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v13 = [];
    let v16 = 0;
    while (v16 < 9) {
        const v17 = v13.push(Infinity, v16);
        const v18 = v16 + 1;
        v16 = v18;
    }
    let v19 = v13;
    function v20(v21, v22) {
        const v26 = [
            13.37,
            13.37,
            13.37,
            13.37,
            13.37
        ];
        let v29 = 0;
        do {
            v29 = 13.37;
        } while (v29 < 10);
        const v30 = v20.toLocaleString();
        const v31 = v30.replace(13.37, v19);
        const v32 = eval(v31);
        return v20;
    }
    const v33 = [];
    let v34 = v33;
    const v35 = v20(...v34, v19, ...v12, 10, 13.37);
    const v36 = v9.reduce(v35, v13);
    const v37 = v36();
    const v39 = v37(Promise, v13, 0, 0, v6);
    let v42 = 0;
    do {
        for (let v46 = 0; v46 < 100; v46++) {
            const v47 = v39(v5, 13.37, 9);
        }
        const v48 = v42 + 1;
        v42 = v48;
    } while (v42 < 2);
}
main();