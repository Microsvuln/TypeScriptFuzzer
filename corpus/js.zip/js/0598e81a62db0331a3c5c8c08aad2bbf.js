function main() {
    const v4 = [13.37];
    const v6 = [
        1337,
        1337,
        1337,
        1337,
        1337
    ];
    const v7 = [
        v6,
        Float32Array,
        -536870912,
        'object'
    ];
    const v8 = {
        d: v7,
        e: Float32Array,
        b: v6,
        c: v4,
        constructor: v7
    };
    const v9 = {
        d: v7,
        __proto__: -536870912,
        c: v8,
        toString: v4,
        b: 1337
    };
    let v10 = Float32Array;
    const v14 = [
        1337,
        1337,
        1337
    ];
    const v15 = ['size'];
    const v17 = [
        1337,
        1337,
        1337,
        1337,
        1337
    ];
    for (let v21 = 0; v21 < 10; v21++) {
        const v24 = [
            1337,
            1337,
            1337,
            1337,
            1337
        ];
        const v27 = [
            13.37,
            13.37,
            13.37,
            13.37,
            13.37
        ];
        const v28 = [];
        let v29 = v28;
        const v30 = v14.some(parseFloat, 1);
        let v33 = 0;
        v15.__proto__ = v29;
        const v34 = v33 + 1;
        v33 = v34;
        function v35(v36, v37) {
            const v40 = [
                13.37,
                13.37
            ];
            const v44 = [
                13.37,
                13.37,
                13.37,
                13.37,
                13.37
            ];
            const v46 = [
                1337,
                v40,
                1337,
                1337,
                1337
            ];
            const v47 = [];
            const v48 = { length: 13.37 };
            for (const v49 in v29) {
                const v50 = v37[1];
            }
            const v51 = v46[3037397953];
            const v52 = v34 - v44;
            const v53 = {
                e: v46,
                length: 13.37,
                d: v46,
                __proto__: Symbol,
                valueOf: v44,
                c: 'p76QI.ipnu'
            };
            const v54 = v44 % v47;
            let v59 = 0;
            while (v59 < 10) {
                for (let v63 = 0; v63 < 8; v63++) {
                    for (let v67 = 0; v67 < 5; v67++) {
                        for (let v71 = 0; v71 < 4; v71++) {
                            const v72 = 0[1];
                        }
                        const v73 = ~v63;
                        const v74 = v24.some(Symbol, v59);
                        const v75 = v15[16];
                        this.d = v17;
                    }
                }
                const v79 = 'p76QI.ipnu' instanceof Symbol;
                const v80 = v59 + 1;
                v59 = v80;
            }
        }
        const v81 = [];
        let v82 = v81;
        const v83 = v35(...v82, v29, ...v27, 10, 13.37);
    }
    const v87 = Symbol.__proto__;
    let v88 = 0;
    do {
        for (const v89 in 1) {
            const v90 = v89.find();
            if (v87) {
            } else {
            }
            let v93 = 0;
            do {
                with (v90) {
                }
            } while (v93 < 0);
        }
    } while (v88 == 1);
}
main();