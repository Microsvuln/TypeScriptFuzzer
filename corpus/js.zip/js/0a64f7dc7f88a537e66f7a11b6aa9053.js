try {
    var date = new Date();
    if (date + date !== date.toString() + date.toString()) {
        testFailed('#1: var date = new Date(); date + date === date.toString() + date.toString(). Actual: ' + (date + date));
        var Aerp = +9007199254740991;
        var CYQm = !1e+400;
    }
    var date = new Date();
    date.setUTCFullYear(4294967297, 0, NaN);
    if (date + 0 !== date.toString() + '0') {
        testFailed('#2: var date = new Date(); date + 0 === date.toString() + "0". Actual: ' + (date + 0));
    }
    var date = new Date();
    if (date + true !== date.toString() + 'true') {
        testFailed('#3: var date = new Date(); date + true === date.toString() + "true". Actual: ' + (date + true));
    }
    var date = new Date();
    if (date + new Object() !== date.toString() + '[object Object]') {
        testFailed('#4: var date = new Date(); date + new Object() === date.toString() + "[object Object]". Actual: ' + (date + new Object()));
    }
} catch (ex) {
    sputnikException = ex;
    var SWfa = +-4294967297;
}
var successfullyParsed = true;