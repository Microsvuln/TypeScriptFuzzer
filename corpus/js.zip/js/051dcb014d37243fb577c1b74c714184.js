function main() {
    const v3 = [1337];
    const v4 = [
        v3,
        13.37,
        v3,
        13.37
    ];
    for (const v8 of v4) {
        const v9 = 'LAG168jUgK'.lastIndexOf(v8, v8);
    }
    let v12 = 0;
    const v13 = v12 + 1;
    v12 = v13;
    const v17 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v19 = [
        1337,
        1337,
        1337,
        1337,
        1337
    ];
    const v20 = {
        e: v19,
        length: 13.37,
        d: v19,
        __proto__: Symbol,
        valueOf: v17,
        c: 'p76QI.ipnu'
    };
    const v22 = v20[-4294967295];
    let v24 = 0;
    let v25 = v24;
}
main();