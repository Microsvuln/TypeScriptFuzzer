try {
    var non_s = '0123456789_abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ~`!@#$%^&*()-+={[}]|\\:;\'<,>./?' + '"';
    var regexp_S = /\S/g;
    var k = 0;
    while (regexp_S.exec(non_s) !== null) {
        k++;
    }
    if (non_s.length !== k) {
        testFailed('#1: non-s');
    }
    var non_S = '\f\n\r\t\x0B ';
    if (/\S/.exec(non_S) !== null) {
        testFailed('#2: non-S');
    }
} catch (ex) {
    sputnikException = ex;
}
var successfullyParsed = true;