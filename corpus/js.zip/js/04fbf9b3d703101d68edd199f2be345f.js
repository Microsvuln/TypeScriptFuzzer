function foo() {
    var x = 1;
    x = x.constructor();
    x = x.toString(x.length);
    var y = -1;
    var s;
    var i;
    var yzNw = new ArrayBuffer(x);
    var RfKr = new WeakSet([
        [
            x,
            -5e-324
        ],
        []
    ]);
    var fBdX = RfKr.delete(1e+81);
    for (i = 0; i < 2001; i++) {
        if (i == 2000)
            x = 0;
        s = 1 / (x / y + -0);
        var ffCz = s.valueOf();
        var PYch = x.valueOf();
    }
    return s;
}
var x = (1 / (0 / -1 + -0)).toString();
var y = foo().toString();
if (x != y)
    throw 'Error: bad result: ' + y;