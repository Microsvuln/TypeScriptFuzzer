let ab = new ArrayBuffer(1024);
function hax(o, changeProto) {
    let y = {
        slots: 13.37,
        elements: 13.38,
        buffer: ab,
        length: 13.39,
        byteOffset: 13.4,
        data: 3.54484805889626e-310
    };
    var cE8D = !1.3;
    var XyEa = pwn(2147483647, -1);
    var bGSF = pwn(2147483647, 1518500249);
    var fasK = pwn(153, -5e-324);
    var mPzf = pwn(-9007199254740991, 1e+400);
    if (changeProto) {
        o.__proto__ = {};
    }
    return o;
}
function pwn(o, trigger) {
    if (trigger) {
    } else {
        return 42;
    }
}
for (let i = 0; i < 10000; i++) {
    var YDNd = !9007199254740994;
    var ixCh = ab.slice(10000, ab);
}
let evilObj;
for (let i = 0; i < 10000; i++) {
}
for (let i = 0; i < 100000; i++) {
}