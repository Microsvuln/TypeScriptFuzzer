function main() {
    try {
        const v4 = [
            -441746.4139016614,
            -441746.4139016614,
            -441746.4139016614,
            -441746.4139016614,
            -441746.4139016614
        ];
        const v5 = [];
        let v6 = v5;
        function v7(v8, v9) {
            const v12 = [
                719904.8518018327,
                719904.8518018327,
                719904.8518018327,
                719904.8518018327,
                719904.8518018327
            ];
            const v15 = [];
            let v16 = v15;
            function v17(v18, v19) {
                const v21 = [
                    13.37,
                    13.37,
                    13.37,
                    13.37,
                    13.37
                ];
                const v23 = Int16Array > v21;
                for (const v26 of v18) {
                    throw 13.37;
                }
                const v27 = [
                    1000,
                    1000,
                    v17,
                    'OQc32+vRhR'
                ];
                const v29 = [
                    -2.220446049250313e-16,
                    v27
                ];
                try {
                    for (const v30 in v27) {
                        const v32 = new Float64Array(v6);
                    }
                    const v33 = 719904.8518018327.b();
                    const v34 = {
                        apply: eval,
                        setPrototypeOf: v7,
                        set: v7,
                        ownKeys: v33,
                        getOwnPropertyDescriptor: eval,
                        isExtensible: v7,
                        has: v17,
                        call: isFinite,
                        construct: eval,
                        getPrototypeOf: v18,
                        get: eval,
                        preventExtensions: v9
                    };
                    const v36 = new Proxy(v16, v34);
                    for (const v37 of v36) {
                        let v40 = 0;
                        do {
                            let v43 = 0;
                            while (v43 < 3) {
                                const v44 = [
                                    ...v40,
                                    ...v8,
                                    ...1000,
                                    v19
                                ];
                            }
                        } while (v40 < 8);
                    }
                } catch (v45) {
                }
                const v46 = v29.toLocaleString();
                const v47 = v46.substring(1000, 128);
                const v48 = eval(v47);
            }
            let v49 = v6;
            const v50 = v17(...v49, v16, ...v12, 10, 719904.8518018327);
        }
        const v51 = [];
        let v52 = v51;
        const v53 = v7(...v52, ...v6, ...v4, 1337, -441746.4139016614);
    } catch (v54) {
    }
}
main();