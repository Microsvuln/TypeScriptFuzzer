try {
    var aString = new String('test string');
    var cErp = aString.toUpperCase();
    var AxPG = aString.includes(aString);
    var GYFS = aString.strike();
    if (aString.search(/String/i) !== 5) {
        testFailed('#1: var aString = new String("test string"); aString.search(/String/i)=== 5. Actual: ' + aString.search(/String/i));
    }
} catch (ex) {
    sputnikException = ex;
}
var successfullyParsed = true;