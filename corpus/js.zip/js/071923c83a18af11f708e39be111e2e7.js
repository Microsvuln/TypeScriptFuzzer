let arr = [];
arr.unshift(42, 9007199254740991, 1e+81, 5e-324);
arr[1000] = 4660;
arr.__defineGetter__(256, function () {
    delete arr[256];
    arr.unshift(1.1);
    arr.length = 0;
});
Object.entries(arr).toString();