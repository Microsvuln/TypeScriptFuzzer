function main() {
    for (const v1 of 'p76QI.ipnu') {
        const v4 = [
            13.37,
            13.37,
            13.37,
            13.37,
            13.37
        ];
        const v5 = [];
        let v6 = v5;
        function v7(v8, v9) {
            let v12 = 0;
            while (v12 < 10) {
                const v15 = [
                    13.37,
                    13.37,
                    13.37,
                    13.37,
                    13.37
                ];
                const v16 = [];
                let v17 = v16;
                function v18(v19, v20) {
                    let v23 = 0;
                    const v29 = [
                        13.37,
                        13.37,
                        13.37
                    ];
                    const v31 = [1337];
                    const v32 = [13.37];
                    const v33 = {
                        c: v29,
                        d: v31,
                        constructor: v32,
                        b: v32,
                        e: v29,
                        toString: Number
                    };
                    const v34 = v33[257];
                    let v36 = undefined;
                    let v39 = 0;
                    while (v39 < 10) {
                        const v42 = Math.round(v33);
                        const v48 = v39 + 1;
                        v39 = v48;
                    }
                    const v49 = v23 + 1;
                    v23 = v49;
                }
                const v50 = [];
                let v51 = v50;
                const v52 = v18(...v51, v17, ...v15, 10, 13.37);
                const v53 = v12 + 1;
                v12 = v53;
            }
        }
        const v54 = [];
        let v55 = v54;
        const v56 = v7(...v55, v6, ...v4, 10, 13.37);
    }
}
main();