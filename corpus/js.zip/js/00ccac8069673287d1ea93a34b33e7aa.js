function main() {
    const v2 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v3 = [];
    let v4 = v3;
    function v5(v6, v7) {
        let v10 = 0;
        while (v10 < 10) {
            for (let v14 = 0; v14 < 8; v14++) {
                let v17 = 0;
                while (v17 < 4) {
                    let v20 = 0;
                    const v24 = [
                        13.37,
                        parseFloat,
                        parseFloat
                    ];
                    const v26 = Math.imul('EPSILON', v24);
                    const v27 = v20 + 1;
                    v20 = v27;
                    const v28 = v17 + 1;
                    v17 = v28;
                }
            }
            const v33 = [1337];
            const v34 = [
                v33,
                13.37,
                v33,
                13.37
            ];
            const v35 = {
                __proto__: 13.37,
                b: -411457152,
                a: parseFloat,
                valueOf: v34
            };
            const v36 = v10 + 1;
            v10 = v36;
        }
    }
    const v37 = [];
    let v38 = v37;
    const v39 = v5(...v38, v4, ...v2, 4096, 13.37);
}
main();