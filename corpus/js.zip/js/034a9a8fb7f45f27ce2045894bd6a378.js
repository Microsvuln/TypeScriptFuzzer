try {
    chars = [
        56320,
        56831,
        57343
    ];
    errorCount = 0;
    count = 0;
    var indexP;
    var indexO = 0;
    for (index = 55296; index <= 56319; index++) {
        res = true;
        for (indexC = 0; indexC < chars.length; indexC++) {
            index1 = (index - 55296) * 1024 + (chars[indexC] - 56320) + 65536;
            hex1 = decimalToHexString(128 + (index1 & 63)).substring(2);
            hex2 = decimalToHexString(128 + (index1 & 4032) / 64).substring(2);
            hex3 = decimalToHexString(128 + (index1 & 258048) / 4096).substring(2);
            hex4 = decimalToHexString(240 + (index1 & 1835008) / 262144).substring(2);
            str = String.fromCharCode(index, chars[indexC]);
            try {
                if (encodeURIComponent(str).toUpperCase() !== '%' + hex4 + '%' + hex3 + '%' + hex2 + '%' + hex1) {
                    res = false;
                }
            } catch (e) {
                res = false;
            }
        }
        if (res !== true) {
            if (indexO === 0) {
                indexO = index;
            } else {
                if (index - indexP !== 1) {
                    if (indexP - indexO !== 0) {
                        var hexP = decimalToHexString(indexP);
                        var hexO = decimalToHexString(indexO);
                        testFailed('#' + hexO + '-' + hexP + ' ');
                    } else {
                        var hexP = decimalToHexString(indexP);
                        testFailed('#' + hexP + ' ');
                    }
                    indexO = index;
                }
            }
            indexP = index;
            errorCount++;
        }
        count++;
    }
    if (errorCount > 0) {
        if (indexP - indexO !== 0) {
            var hexP = decimalToHexString(indexP);
            var hexO = decimalToHexString(indexO);
            testFailed('#' + hexO + '-' + hexP + ' ');
        } else {
            var hexP = decimalToHexString(indexP);
            testFailed('#' + hexP + ' ');
        }
        testFailed('Total error: ' + errorCount + ' bad Unicode character in ' + count + ' ');
    }
    function decimalToHexString(n) {
        n = Number(n);
        var h = '';
        for (var i = 3; i >= 0; i--) {
            if (n >= Math.pow(16, i)) {
                var t = Math.floor(n / Math.pow(16, i));
                n -= t * Math.pow(16, i);
                if (t >= 10) {
                    if (t == 10) {
                        h += 'A';
                    }
                    if (t == 11) {
                        h += 'B';
                    }
                    if (t == 12) {
                        h += 'C';
                    }
                    if (t == 13) {
                        h += 'D';
                    }
                    if (t == 14) {
                        h += 'E';
                    }
                    if (t == 15) {
                        h += 'F';
                    }
                } else {
                    h += String(t);
                }
            } else {
                h += '0';
            }
        }
        return h;
    }
} catch (ex) {
    sputnikException = ex;
}
var successfullyParsed = true;