function main() {
    const v2 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v3 = [
        13.37,
        v2
    ];
    const v4 = {
        d: v3,
        length: Proxy
    };
    let v7 = 0;
    while (v7 < 9) {
        for (let v11 = 0; v11 < 10; v11++) {
            for (const v13 of 'p76QI.ipnu') {
                const v15 = [13.37];
                const v17 = [
                    1337,
                    1337,
                    1337
                ];
                const v18 = v15.__proto__;
                let v19 = v17;
                const v21 = v19.constructor;
                const v22 = {
                    getOwnPropertyDescriptor: Symbol,
                    set: v21,
                    getPrototypeOf: Symbol,
                    has: v21,
                    preventExtensions: Symbol,
                    isExtensible: Symbol,
                    get: Symbol,
                    ownKeys: Symbol,
                    deleteProperty: v21,
                    call: Symbol,
                    defineProperty: v21,
                    construct: v21,
                    setPrototypeOf: Symbol
                };
                const v24 = new WeakSet(v18, v22);
                const v27 = new Int16Array(48267);
                let v33 = 0;
                const v34 = v33 + 1;
                v33 = v34;
                v24[v2] = v4;
                let v37 = 0;
                const v38 = v37 + 1;
                v37 = v38;
            }
        }
        const v39 = v7 + 1;
        v7 = v39;
    }
}
main();