function main() {
    const v1 = ['toString'];
    const v4 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v5 = [];
    let v6 = v5;
    function v7(v8, v9) {
        let v12 = 0;
        while (v12 < 1024) {
            for (let v16 = 0; v16 < 10; v16++) {
            }
            const v19 = Symbol.iterator;
            const v20 = Symbol[v19];
            const v22 = RegExp.apply('asyncIterator', v20);
            const v25 = [
                1337,
                1337,
                1337,
                1337,
                1337
            ];
            const v26 = Math.round(v25);
            const v27 = v12 + 1;
            v12 = v27;
        }
    }
    let v28 = v1;
    const v29 = v7(...v28, v6, ...v4, 10, 13.37);
}
main();