var data = [
    '7',
    '12.4.6',
    '12.4.8',
    '9.2.16',
    '11.4.20',
    '11.3.14',
    '2.1.12',
    '12.4',
    '13.5'
];
function getAvailable(data) {
    var res = [];
    function getEven(n) {
        if (n % 2)
            return false;
        else
            return true;
    }
    function sort(arr) {
        var m = arr[0];
        for (var i = 1; i < arr.length; i++) {
            if (parseInt(arr[i].split('.')[0]) >= parseInt(m.split('.')[0])) {
                m = arr[i];
            }
        }
        return m;
    }
    for (var i = 0; i < data.length; i++) {
        if (getEven(parseInt(data[i].split('.').pop()))) {
            res.push(data[i]);
        }
    }
    if (res.length == 0) {
        return 'no stable available';
    }
    console.info(res);
    if (res.length == 1) {
        return res[0];
    } else {
        return sort(res);
    }
    return res;
}
console.info(getAvailable(data));
var arr1 = [
    1,
    9,
    30,
    2,
    7,
    10,
    94,
    64,
    82,
    13
];
var arr2 = [
    4,
    9,
    5,
    23,
    65,
    34,
    2,
    10,
    21
];
var arr3 = [
    10,
    97,
    47,
    38,
    82,
    91,
    2,
    71,
    2
];
function unique(a) {
    a.sort();
    var res = [a[0]];
    for (var i = 1; i < a.length; i++) {
        if (a[i] !== res[res.length - 1]) {
            res.push(a[i]);
        }
    }
    return res;
}
function getTheSameNum(arr1, arr2, arr3) {
    var temp = [];
    for (var i = 0; i < arr1.length; i++) {
        for (var j = 0; j < arr2.length; j++) {
            if (arr1[i] == arr2[j])
                temp.push(arr1[i]);
        }
    }
    temp = unique(temp);
    var res = [];
    for (var j = 0; j < temp.length; j++) {
        for (var i = 0; i < arr3.length; i++) {
            if (arr3[i] == temp[j]) {
                res.push(temp[j]);
            }
        }
    }
    return unique(res);
}
console.info(getTheSameNum(arr1, arr2, arr3));
var sample = {
    '127': {
        have: [1010],
        need: [1100]
    },
    '123': {
        have: [
            1001,
            1002
        ],
        need: [1003]
    },
    '128': {
        have: [1100],
        need: [1010]
    },
    '129': {
        have: [],
        need: []
    },
    '124': {
        have: [1007],
        need: [1008]
    },
    '125': {
        have: [1003],
        need: [1004]
    },
    '126': {
        have: [1004],
        need: [1002]
    }
};
function getDeadlock(a) {
    var lock = [], r = 0;
    for (k in a) {
        console.info(lock);
        for (var i = 0; i < a[k].have.length; i++) {
            for (p in a) {
                for (var j = 0; j < a[p].need.length; j++) {
                    if (a[k].have[i] == a[p].need[j]) {
                        lock.push(k);
                        if (a[lock[0]].have[i] == a[k].need[j])
                            console.info(a[k].need[j]);
                    }
                }
            }
        }
    }
    return r;
}
console.info(getDeadlock(sample));