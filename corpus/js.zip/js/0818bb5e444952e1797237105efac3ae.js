function runTest(config, qualifier) {
    var testname = testnamePrefix(qualifier, config.keysystem) + ', temporary, keystatuses, multiple sessions';
    var configuration = getSimpleConfigurationForContent(config.content);
    if (config.initDataType && config.initData)
        configuration.initDataTypes = [config.initDataType];
    async_test(function (test) {
        var mediaKeySession1;
        var mediaKeySession2;
        var key1 = new Uint8Array(config.content.keys[0].kid), key2 = new Uint8Array(config.content.keys[1].kid), variant1 = config.content.keys[0].variantId, variant2 = config.content.keys[1].variantId;
        function onFailure(error) {
            forceTestFailureFromPromise(test, error);
        }
        function processMessage1(event) {
            assert_equals(event.target, mediaKeySession1);
            verifyKeyStatuses(mediaKeySession1.keyStatuses, {
                expected: [],
                unexpected: [
                    key1,
                    key2
                ]
            });
            config.messagehandler(event.messageType, event.message, { variantId: variant1 }).then(function (response) {
                return event.target.update(response);
            }).catch(onFailure);
        }
        function processKeyStatusesChange1(event) {
            assert_equals(event.target, mediaKeySession1);
            verifyKeyStatuses(mediaKeySession1.keyStatuses, {
                expected: [key1],
                unexpected: [key2]
            });
            mediaKeySession2.generateRequest(config.initDataType, config.initData[1]).catch(onFailure);
        }
        function processMessage2(event) {
            assert_equals(event.target, mediaKeySession2);
            verifyKeyStatuses(mediaKeySession2.keyStatuses, {
                expected: [],
                unexpected: [
                    key1,
                    key2
                ]
            });
            verifyKeyStatuses(mediaKeySession1.keyStatuses, {
                expected: [key1],
                unexpected: [key2]
            });
            config.messagehandler(event.messageType, event.message, { variantId: variant2 }).then(function (response) {
                return event.target.update(response);
            }).catch(onFailure);
        }
        function processKeyStatusesChange2(event) {
            assert_equals(event.target, mediaKeySession2);
            verifyKeyStatuses(mediaKeySession2.keyStatuses, {
                expected: [key2],
                unexpected: [key1]
            });
            verifyKeyStatuses(mediaKeySession1.keyStatuses, {
                expected: [key1],
                unexpected: [key2]
            });
            test.done();
        }
        navigator.requestMediaKeySystemAccess(config.keysystem, [configuration]).then(function (access) {
            return access.createMediaKeys();
        }).then(function (mediaKeys) {
            mediaKeySession1 = mediaKeys.createSession();
            mediaKeySession2 = mediaKeys.createSession();
            verifyKeyStatuses(mediaKeySession1.keyStatuses, {
                expected: [],
                unexpected: [
                    key1,
                    key2
                ]
            });
            verifyKeyStatuses(mediaKeySession2.keyStatuses, {
                expected: [],
                unexpected: [
                    key1,
                    key2
                ]
            });
            waitForEventAndRunStep('message', mediaKeySession1, processMessage1, test);
            waitForEventAndRunStep('message', mediaKeySession2, processMessage2, test);
            waitForEventAndRunStep('keystatuseschange', mediaKeySession1, processKeyStatusesChange1, test);
            waitForEventAndRunStep('keystatuseschange', mediaKeySession2, processKeyStatusesChange2, test);
            return mediaKeySession1.generateRequest(config.initDataType, config.initData[0]);
        }).catch(onFailure);
    }, testname);
}