function main() {
    const v2 = [
        1337,
        1337
    ];
    const v5 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v6 = [];
    let v9 = 128;
    while (v9 < 4096) {
        const v10 = v6.push(13.37, 13.37);
        const v11 = v9 + 1;
        v9 = v11;
    }
    let v12 = v6;
    function v13(v14, v15) {
        const v18 = [
            1000000000000,
            1000000000000,
            1000000000000,
            1000000000000,
            1000000000000
        ];
        const v19 = [];
        let v20 = v19;
        function v21(v22, v23) {
        }
        const v24 = [];
        let v25 = v24;
        const v26 = v21(...v25, v20, ...v18, -256, 1000000000000);
        try {
            const v27 = [
                v14,
                13.37,
                ...v14,
                v2
            ];
        } catch (v28) {
        }
        const v31 = v13.toLocaleString();
        const v32 = v31.replace(13.37, v12);
        const v33 = eval(v32);
        return v13;
    }
    const v34 = [];
    let v35 = v34;
    const v36 = v13(...v35, v12, ...v5, 2715111674, 13.37);
    const v37 = v2.reduce(v36, v6);
}
main();