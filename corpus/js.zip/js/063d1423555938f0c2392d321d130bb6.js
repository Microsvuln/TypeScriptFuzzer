function main() {
    const v1 = [13.37];
    const v3 = [NaN];
    let v6 = 0;
    do {
        const v7 = v6 + 1;
        v6 = v7;
        let v10 = 0;
        while (v10 < 5) {
            function v11(v12, v13, v14, v15, ...v16) {
                let v18 = 0;
                const v21 = [1337];
                const v22 = [
                    v21,
                    -1.7976931348623157e+308,
                    v21,
                    -1.7976931348623157e+308
                ];
                let v23 = v22;
                let v26 = 0;
                let v29 = 0;
                const v30 = v26 + 1;
                v26 = v30;
                const v31 = v23.slice(0, 0);
                const v32 = v1.slice();
            }
            for (let v51 = 0; v51 < 10; v51++) {
                const v52 = v11();
            }
            const v53 = v10 + 1;
            v10 = v53;
        }
    } while (v6 < 8);
}
main();