function main() {
    const v1 = [
        13.37,
        13.37
    ];
    const v7 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v8 = [];
    let v9 = v8;
    function v10(v11, v12) {
        const v14 = new Float64Array(v12);
        const v15 = new Uint32Array(v14);
        return v15;
    }
    let v16 = 'symbol';
    const v17 = v10(...v16, v9, ...v7, 10, 13.37);
    const v18 = v10(1337, v1);
}
main();