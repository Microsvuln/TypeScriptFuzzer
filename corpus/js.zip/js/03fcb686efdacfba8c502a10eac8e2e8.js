function main() {
    let v2 = 0;
    let v8 = 0;
    let v11 = 0;
    for (const v13 in RegExp) {
        RegExp[v13] = v13;
    }
}
main();