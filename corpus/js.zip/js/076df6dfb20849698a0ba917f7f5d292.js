function main() {
    const v1 = [
        1337,
        1337,
        1337
    ];
    const v2 = [];
    function v3(v4, v5) {
        const v9 = [
            13.37,
            13.37,
            13.37,
            13.37,
            13.37
        ];
        for (const v10 in v9) {
            const v11 = [
                ...v10,
                ...'p76QI.ipnu',
                v10
            ];
        }
        const v13 = new Uint32Array(11105);
    }
    for (let v17 = 0; v17 < 100; v17++) {
        const v18 = v3(v1, v2);
    }
}
main();