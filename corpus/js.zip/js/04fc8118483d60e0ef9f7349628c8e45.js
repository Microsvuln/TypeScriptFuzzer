let ipfs;
let totalQueries = 0;
let seconds = 0;
let queriesPerSecond = 0;
let lastTenSeconds = 0;
let log1, log2;
const queryLoop = () => {
    const add1 = Log.append(ipfs, log1, 'a' + totalQueries);
    const add2 = Log.append(ipfs, log2, 'b' + totalQueries);
    Promise.all([
        add1,
        add2
    ]).then(res => {
        log1 = Log.join(res[0], res[1], 60);
        log2 = Log.join(res[1], res[0], 60);
        totalQueries++;
        lastTenSeconds++;
        queriesPerSecond++;
        setImmediate(queryLoop);
    }).catch(e => console.error(e));
};
let run = (() => {
})();