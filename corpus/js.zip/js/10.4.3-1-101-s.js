var x = 3;
function f() {
    x = this;
    return 'a';
}