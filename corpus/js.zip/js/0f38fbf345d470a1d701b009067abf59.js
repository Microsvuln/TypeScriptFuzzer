function main() {
    for (const v1 of 'p76QI.ipnu') {
        const v4 = [
            13.37,
            13.37,
            13.37,
            13.37,
            13.37
        ];
        const v5 = [];
        let v6 = v5;
        function v7(v8, v9) {
            const v12 = [
                13.37,
                13.37,
                13.37,
                13.37,
                13.37
            ];
            const v13 = [];
            let v14 = v13;
            function v15(v16, v17) {
                let v20 = 0;
                let v26 = 0;
                do {
                    const v29 = [
                        13.37,
                        13.37,
                        13.37,
                        13.37,
                        13.37
                    ];
                    const v30 = [];
                    let v31 = v30;
                    function v32(v33, v34) {
                    }
                    const v35 = [];
                    let v36 = v35;
                    const v37 = v32(...v36, v31, ...v29, 10, 13.37);
                    const v41 = new ArrayBuffer(3);
                    const v42 = new DataView(v41);
                    const v43 = v42.getUint16(v37);
                    const v44 = v26 + 1;
                    v26 = v44;
                } while (v26 < 6);
                for (let v45 = 0; v45 < 256; v45++) {
                    for (let v49 = 0; v49 < 256; v49++) {
                    }
                }
                const v50 = v17 + 1;
                v20 = v50;
            }
            const v51 = [];
            let v52 = v51;
            const v53 = v15(...v52, v14, ...v12, 10, 13.37);
        }
        const v54 = [];
        let v55 = v54;
        const v56 = v7(...v55, v6, ...v4, 10, 13.37);
    }
}
main();