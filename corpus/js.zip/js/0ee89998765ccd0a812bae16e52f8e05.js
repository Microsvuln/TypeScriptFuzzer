function main() {
    const v2 = Function('JxYEB5Cx4O');
    v2.caller = 'JxYEB5Cx4O';
}
main();