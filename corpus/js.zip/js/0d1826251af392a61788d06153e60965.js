function main() {
    const v6 = new Proxy(Boolean, Reflect);
    let v9 = 0;
    const v10 = v9 + 1;
    v9 = v10;
    for (const v11 in v6) {
    }
}
main();