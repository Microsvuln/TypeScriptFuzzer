function getParameterByName(name, url) {
    !url;
    name = name.replace(/[\[\]]/g, '\\$&');
    var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'), results = regex.exec(url);
    if (!results)
        return null;
    if (!results[2])
        return '';
    return decodeURIComponent(results[2].replace(/\+/g, ' '));
}
function clientLog(msg) {
    console.log('webrtc-client.html(log)' + ', [user: ' + username + '] ' + msg);
}
function clientError(msg) {
    console.error('webrtc-client.html(error)' + ', [user: ' + username + '] ' + msg);
}
var useVideo = false;
var username = getParameterByName('username');
if (!username) {
    username = 'bob';
}
var password = getParameterByName('password');
if (!password) {
    password = '1234';
}
var registerWsUrl = getParameterByName('register-ws-url');
if (!registerWsUrl) {
    registerWsUrl = 'ws://127.0.0.1:5082';
}
var registerDomain = getParameterByName('register-domain');
if (!registerDomain) {
    registerDomain = '127.0.0.1';
}
var respawnUrl = getParameterByName('respawn-url');
if (!respawnUrl) {
    respawnUrl = 'http://127.0.0.1:10511/respawn-user';
}
var fakeMedia = getParameterByName('fake-media');
if (!fakeMedia) {
    fakeMedia = false;
} else {
    if (fakeMedia == 'true') {
        fakeMedia = true;
    } else {
        fakeMedia = false;
    }
}
var role = getParameterByName('role');
if (!role) {
    role = 'passive';
}
var closeOnEnd = getParameterByName('close-on-end');
if (!closeOnEnd) {
    closeOnEnd = false;
} else {
    if (closeOnEnd == 'true') {
        closeOnEnd = true;
    } else {
        closeOnEnd = false;
    }
}
var callDestination = getParameterByName('call-destination');
if (!callDestination) {
    callDestination = '+1235@127.0.0.1';
}
var currentConnection;
var parameters = {
    'debug': true,
    'username': username,
    'password': password
};
parameters['registrar'] = registerWsUrl;
parameters['domain'] = registerDomain;
if (role == 'active') {
    parameters['register'] = false;
}
function call(destination) {
    var parameters = {
        'username': destination,
        'video-enabled': useVideo,
        'local-media': localMedia,
        'remote-media': remoteMedia,
        'fake-media': fakeMedia
    };
    clientLog('Connecting with params: ' + JSON.stringify(parameters));
    currentConnection.disconnect(function (connection) {
        clientLog('Connection disconnected: ' + JSON.stringify(connection.parameters));
        $('#log').text('Connection ended');
        if (closeOnEnd) {
        }
    });
    currentConnection.error(function (error) {
        clientError('Connection error: ' + JSON.stringify(error));
        $('#log').text('Connection error: ' + error);
    });
    currentConnection.mute(function (muted, connection) {
        $('#log').text('Connection audio muted: ' + muted);
    });
    currentConnection.muteVideo(function (muted, connection) {
        $('#log').text('Connection video muted: ' + muted);
    });
}
function accept() {
    var parameters = {
        'video-enabled': useVideo,
        'local-media': localMedia,
        'remote-media': remoteMedia,
        'fake-media': fakeMedia
    };
    currentConnection.accept(parameters);
}
function send() {
    var parameters = {
        'username': 'orestis@cloud.restcomm.com',
        'message': 'Hello there!'
    };
}
function sendDigits() {
    currentConnection.sendDigits('1*');
}
function hangup() {
    $('#log').text('Connection ended');
}
function destroy() {
}
function muteIncoming() {
}
function ignoreIncoming() {
}
function rejectIncoming() {
}
function muteAudio() {
}
function unmuteAudio() {
}
function muteVideo() {
}
function unmuteVideo() {
}