function main() {
let v11 = 0;
const v12 = {...v11};
// v12 = .object(ofGroup: Object, withProperties: ["__proto__"])
}
main();
