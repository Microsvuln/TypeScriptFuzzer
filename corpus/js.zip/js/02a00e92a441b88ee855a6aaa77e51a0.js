function opt(arr) {
    if (arr.length <= 15)
        return;
    let j = 0;
    var JXD4 = !1e+400;
    for (let i = 0; i < 2; i++) {
        arr[j] = 4660;
        var GfAQ = !0;
        var xCtY = !1e-15;
        j += 1048576;
        j + 2147483632;
        var aW4Q = !42;
    }
}
function main() {
    for (let i = 0; i < 65536; i++) {
        opt(new Uint32Array(100));
    }
}
main();