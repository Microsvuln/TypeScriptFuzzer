function main() {
    for (let v4 = 0; v4 < 127; v4++) {
        for (let v8 = 2; v8 < 100; v8 = v8 + 9) {
            try {
                let v10 = String;
                const v11 = v10.fromCharCode(v8, 9, v4, v8, v4);
                const v12 = eval(v11);
            } catch (v13) {
            }
        }
    }
}
main();