function main() {
    for (let v5 = 0; v5 < 127; v5++) {
        const v6 = 1[v5];
        const v7 = {
            preventExtensions: v6,
            getPrototypeOf: eval,
            get: eval,
            ownKeys: eval,
            call: eval,
            getOwnPropertyDescriptor: eval,
            construct: eval,
            defineProperty: eval,
            isExtensible: v6,
            has: v6
        };
        const v9 = new Proxy(eval, v7);
        let v15 = 0;
        const v16 = v15 + 1;
        v15 = v16;
        try {
            const v17 = 'number' == v9;
        } catch (v21) {
        }
    }
}
main();