function main() {
    for (let v5 = 0; v5 < 127; v5++) {
        for (let v8 = 0; v8 < 100; v8 = v8 + 9) {
            try {
                let v10 = String;
                const v11 = v10.fromCharCode(100, v5, 100, v8, v8);
                const v12 = eval(v11);
            } catch (v13) {
            }
        }
    }
}
main();