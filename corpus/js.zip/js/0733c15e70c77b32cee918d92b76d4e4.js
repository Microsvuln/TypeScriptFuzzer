function main() {
    for (const v1 of 'p76QI.ipnu') {
        let v4 = 0;
        while (v4 < 4) {
            const v7 = [
                13.37,
                13.37,
                13.37,
                13.37,
                13.37
            ];
            const v8 = [];
            let v9 = v8;
            function v10(v11, v12) {
                let v15 = 0;
                while (v15 < 10) {
                    for (const v17 in RegExp) {
                        RegExp[v17] = RegExp;
                    }
                    const v21 = [
                        1337,
                        1337,
                        1337,
                        1337,
                        1337
                    ];
                    const v22 = v15 + 1;
                    v15 = v22;
                }
            }
            const v23 = [];
            let v24 = v23;
            const v25 = v10(...v24, v9, ...v7, 10, 13.37);
            const v26 = v4 + 1;
            v4 = v26;
        }
    }
}
main();