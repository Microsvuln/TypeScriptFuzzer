function main() {
    try {
        const v2 = [
            -441746.4139016614,
            -441746.4139016614,
            -441746.4139016614,
            -441746.4139016614,
            -441746.4139016614
        ];
        const v3 = [];
        let v4 = v3;
        function v5(v6, v7) {
            try {
                try {
                    const v10 = [
                        -441746.4139016614,
                        -441746.4139016614,
                        -441746.4139016614,
                        -441746.4139016614,
                        -441746.4139016614
                    ];
                    const v11 = [];
                    let v12 = v11;
                    function v13(v14, v15) {
                        const v18 = [
                            13.37,
                            13.37,
                            13.37,
                            13.37,
                            13.37
                        ];
                        const v19 = [];
                        let v20 = v19;
                        function v21(v22, v23) {
                            for (let v27 = 0; v27 < 100; v27++) {
                                try {
                                    const v30 = [
                                        -441746.4139016614,
                                        -441746.4139016614,
                                        -441746.4139016614,
                                        -441746.4139016614,
                                        -441746.4139016614
                                    ];
                                    const v31 = [];
                                    let v32 = v31;
                                    function v33(v34, v35) {
                                        const v38 = [
                                            719904.8518018327,
                                            719904.8518018327,
                                            719904.8518018327,
                                            719904.8518018327,
                                            719904.8518018327
                                        ];
                                        const v40 = [];
                                        let v41 = v40;
                                        function v42(v43, v44) {
                                            function v45(v46, v47) {
                                                const v55 = [
                                                    13.37,
                                                    13.37,
                                                    13.37,
                                                    13.37,
                                                    13.37
                                                ];
                                                v55.length = 1337;
                                                const v56 = [];
                                                let v57 = v56;
                                                function v58(v59, v60) {
                                                    return arguments;
                                                }
                                                const v61 = [];
                                                let v62 = v61;
                                                const v63 = v58(...v62, v57, ...v55, 10, 13.37);
                                                const v65 = [
                                                    13.37,
                                                    13.37,
                                                    13.37,
                                                    13.37,
                                                    v63
                                                ];
                                                const v66 = [];
                                                let v67 = v66;
                                                function v68(v69, v70, v71) {
                                                }
                                            }
                                            const v75 = v42.toLocaleString();
                                            const v76 = v75.substring(1000, 128);
                                            const v77 = eval(v76);
                                        }
                                        const v78 = [];
                                        let v79 = v78;
                                        const v80 = v42(...v79, v41, ...v38, 10, 719904.8518018327);
                                    }
                                    const v81 = [];
                                    let v82 = v81;
                                    const v83 = v33(...v82, ...v32, ...v30, 1337, -441746.4139016614);
                                } catch (v84) {
                                }
                            }
                        }
                        const v85 = [];
                        let v86 = v85;
                        const v87 = v21(...v86, v20, ...v18, 10, 13.37);
                    }
                    const v88 = [];
                    let v89 = v88;
                    const v90 = v13(...v89, v12, v10, 1337, -441746.4139016614);
                } catch (v91) {
                }
                let v94 = 0;
                let v97 = 0;
                let v100 = 0;
                const v102 = [];
                let v103 = v102;
                function v104(v105, v106) {
                    let v108 = 10;
                    const v110 = Object(v103, v108, v106, 0);
                }
            } catch (v111) {
            }
        }
        const v112 = [];
        let v113 = v112;
        const v114 = v5(...v113, v4, ...v2, 1337, -441746.4139016614);
    } catch (v115) {
    }
}
main();