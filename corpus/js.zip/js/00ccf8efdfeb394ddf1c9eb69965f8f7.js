function main() {
    for (let v4 = 0; v4 < 100; v4++) {
        try {
            const v7 = [
                -441746.4139016614,
                -441746.4139016614,
                -441746.4139016614,
                -441746.4139016614,
                -441746.4139016614
            ];
            const v8 = [];
            let v9 = v8;
            function v10(v11, v12) {
                const v15 = [
                    v4,
                    1,
                    -380874.3564998767
                ];
                const v16 = v4.toLocaleString();
                v15[v16] = -65535;
                const v17 = v15.join('**Aw.DWHXu');
                const v18 = v17.replace(v16, v16);
                const v19 = eval(v18);
            }
            const v20 = [];
            let v21 = v20;
            const v22 = v10(...v21, ...v9, v7, -65535, -441746.4139016614);
        } catch (v23) {
        }
    }
}
main();