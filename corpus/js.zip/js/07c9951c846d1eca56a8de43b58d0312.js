var array = [];
var efWd = new Uint8Array([
    array.length,
    array.length,
    4294967296,
    array,
    array,
    4294967296
]);
var cAGh = new Uint8ClampedArray([
    array.length,
    1e-15,
    0.1,
    array.length,
    array.length,
    array,
    42,
    array.length,
    array.length
]);
var Zybt = new Int16Array([1518500249]);
var scCH = new ArrayBuffer(-5e-324);
var izxa = new WeakSet([
    [2147483649],
    [
        1.7976931348623157e+308,
        0,
        1e-15,
        1e+81,
        -9007199254740991,
        1518500249,
        -9007199254740991,
        -9007199254740991,
        -4294967296
    ]
]);
cAGh['7'] = 759250124 < 5;
var hBKd = new ArrayBuffer(array);
cAGh = efWd.slice(cAGh['4'], cAGh['8']);
var BdJe = new Int32Array([-2147483647]);
var NwPJ = new Int8Array([
    cAGh['7'],
    9007199254740992,
    0,
    cAGh['0'],
    1e+400
]);
var fwjA = new Map([
    [
        -5e-324,
        -2147483649,
        9007199254740991,
        5e-324,
        4294967297,
        1.3,
        4,
        42,
        9007199254740991
    ],
    [
        3,
        -9007199254740991
    ]
]);
array = array.lastIndexOf(3.141592653589793, efWd['2']);
var aPNr = new ArrayBuffer(scCH);
var MEAk = new Float64Array([]);
efWd = scCH.slice(efWd['5'], NwPJ['1']);
var HDkf = new Map([
    [
        9007199254740991,
        -9007199254740991,
        153,
        izxa,
        153,
        cAGh['4'],
        NwPJ['3']
    ],
    [
        -4294967295,
        Zybt['0'],
        array,
        NwPJ['1']
    ]
]);
var XjJY = new Int8Array([
    array.length,
    -1,
    array.length,
    1e-15,
    array,
    array,
    array.length,
    -9007199254740991
]);
var JWdd = new Map([
    [
        -2147483648,
        1200,
        -9007199254740991,
        -4294967295,
        -Infinity,
        1e+81
    ],
    [0]
]);
var AHmR = new Array([-2147483649]);
efWd = efWd.slice(cAGh['7'], cAGh['4']);
XjJY['2'] = -cAGh['4'];
var BMWm = new ArrayBuffer(3.141592653589793);
3.141592653589793, -4294967297;
var ZeXp = new Float64Array([
    0,
    2147483649
]);
var ZWse = new WeakSet([
    [array],
    []
]);
hBKd = JWdd.get(JWdd, XjJY['1']);
var kfbM = new WeakSet([
    [
        1e+81,
        4294967295,
        3037000498
    ],
    []
]);
kfbM.length = -XjJY['6'];
var TmPf = new Map([
    [0.1],
    [
        -9007199254740990,
        cAGh['7'],
        cAGh,
        NwPJ['3'],
        XjJY['7'],
        AHmR.length,
        MEAk,
        4294967297
    ]
]);
var BcGK = new Map([
    [],
    [1518500249]
]);
var Qpeb = new Int16Array([
    1e-15,
    -9007199254740994,
    9007199254740991,
    9007199254740991,
    BMWm,
    XjJY['4'],
    XjJY['1'],
    XjJY['3']
]);
var XpNA = new Int16Array([
    BMWm,
    ZWse,
    153,
    XjJY['6'],
    4294967295,
    XjJY['5'],
    BcGK.length,
    4294967297
]);
var ZwmF = new ArrayBuffer(array.length);
BMWm = ZWse.valueOf();
var MrFE = AHmR.forEach(function () {
}, -9007199254740991);
var funky = {
    toJSON: function () {
        array.length = 1;
        return 'funky';
    }
};
var BppA = new Array([]);
var Kkmy = new Float64Array([
    -9007199254740990,
    cAGh['7'],
    -2147483649,
    JWdd,
    BMWm,
    -Infinity,
    ZwmF,
    4294967295,
    1e-81
]);
for (var i = 0; i < 10; i++)
    array[i] = i;
array[0] = funky;
'["funky",null,null,null,null,null,null,null,null,null]' == JSON.stringify(array);
ZWse.length = ~4;
kfbM = ZWse.toString(array.length, array.length, BcGK.length);
funky.value = 3 >= funky.value;
array.length = 4294967295 != ZwmF;
BcGK.length = BcGK <= 3;
var mBrm = kfbM.codePointAt(XjJY['5']);
array.length = -1 <= array;
funky.value = array >= -2147483649;
NaN, 3.141592653589793, Qpeb['5'], Qpeb['3'], BppA;
kfbM.length = BcGK > 759250124;
BcGK = ZwmF.slice(Qpeb['1'], BcGK.length);
JWdd = JWdd.values();
array.length = -Infinity > 3.141592653589793;
BcGK.length = -153;
funky.value = funky < 1.3;
var pNJx = new Float64Array([
    2147483648,
    -2147483647,
    XjJY['5'],
    array,
    ZWse,
    array.length,
    -2147483649
]);
var iPAd = new Map([
    [
        BcGK.length,
        0,
        -2147483648,
        1.7976931348623157e+308,
        0,
        MEAk,
        -2147483647,
        ZwmF,
        XjJY['4']
    ],
    [
        1e+400,
        XjJY['0'],
        funky,
        kfbM.length,
        -Infinity
    ]
]);
BcGK = array.toLocaleString();
array = [];
var xtrE = BMWm.delete(JWdd);
array = ZwmF.slice(kfbM.length, BcGK.length);
XjJY['3'] = +1e+81;
var RZwE = new WeakSet([
    [
        -9007199254740992,
        BMWm,
        BcGK.length,
        array,
        42,
        BcGK,
        2147483647,
        1518500249
    ],
    [
        BcGK.length,
        kfbM
    ]
]);
0.1, -2147483648, 1.7976931348623157e+308, 1e+400, -9007199254740992, -4294967297, -9007199254740990, 9007199254740990;
funky.value = funky == array.length;
array.length = array == 1518500249;
var YMAT = new Map([
    [
        1e+81,
        ZwmF,
        1e+81,
        ZwmF,
        array,
        funky.value,
        array.length,
        funky.value,
        array
    ],
    [
        ZwmF,
        -2147483647
    ]
]);
funky.value = -funky;
funky = {
    get value() {
        array.length = 1;
        var dzSi = new Float32Array([
            -1.7976931348623157e+308,
            -4294967297,
            9007199254740991,
            9007199254740994,
            -2147483649,
            NaN
        ]);
        var jcTt = new Map([
            [
                -9007199254740992,
                -5e-324,
                2147483649
            ],
            [-5e-324]
        ]);
        return 'funky';
    }
};
for (var i = 0; i < 10; i++)
    array[i] = i;
array[3] = funky;
var TNCM = new Array([
    BcGK,
    array,
    4294967296,
    NaN,
    -9007199254740991,
    ZwmF,
    funky,
    0.2,
    array
]);
'[0,1,2,{"value":"funky"},null,null,null,null,null,null]' == JSON.stringify(array);
array.length = - -1;
array.length = -array;
array = [];
funky.value = -1e-15;
funky = {
    get value() {
        array.pop();
        return 'funky';
    }
};
for (var i = 0; i < 10; i++)
    array[i] = i;
array[3] = funky;
'[0,1,2,{"value":"funky"},4,5,6,7,8,null]' == JSON.stringify(array);
var MWXM = array.every(function () {
}, 1e+400);
array = [];
funky = {
    get value() {
        delete array[9];
        return 'funky';
    }
};
for (var i = 0; i < 10; i++)
    array[i] = i;
array[3] = funky;
'[0,1,2,{"value":"funky"},4,5,6,7,8,null]' == JSON.stringify(array);
array = [];
array.length = !array.length;
funky = {
    get value() {
        delete array[6];
        return 'funky';
    }
};
for (var i = 0; i < 10; i++)
    array[i] = i;
array[3] = funky;
'[0,1,2,{"value":"funky"},4,5,null,7,8,9]' == JSON.stringify(array);
funky.value = ~1.7976931348623157e+308;
array = [];
funky = {
    get value() {
        array[12] = 12;
        return 'funky';
    }
};
for (var i = 0; i < 10; i++)
    array[i] = i;
array[3] = funky;
'[0,1,2,{"value":"funky"},4,5,6,7,8,9]' == JSON.stringify(array);
array = [];
funky = {
    get value() {
        array[10000000] = 12;
        return 'funky';
    }
};
for (var i = 0; i < 10; i++)
    array[i] = i;
array[3] = funky;
'[0,1,2,{"value":"funky"},4,5,6,7,8,9]' == JSON.stringify(array);