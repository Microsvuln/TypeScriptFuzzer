var arr = [
    ,
    ,
    ,
];
arr.unshift(3, 1e+400, 2147483648, 3.141592653589793);
var anrf = ~-1;
var WMrr = ~10000;
try {
    Array.prototype[1] = 'prototype';
    arr.reduceRight(function () {
    });
} finally {
    delete Array.prototype[1];
}