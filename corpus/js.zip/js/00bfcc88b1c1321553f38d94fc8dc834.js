try {
    var evalStr = '//CHECK#1\n' + 'for (var x in this) {\n' + '  if ( x === \'Object\' ) {\n' + '    testFailed("#1: \'Object\' have attribute DontEnum");\n' + '  } else if ( x === \'Function\') {\n' + '    testFailed("#1: \'Function\' have attribute DontEnum");\n' + '  } else if ( x === \'String\' ) {\n' + '    testFailed("#1: \'String\' have attribute DontEnum");\n' + '  } else if ( x === \'Number\' ) {\n' + '    testFailed("#1: \'Number\' have attribute DontEnum");\n' + '  } else if ( x === \'Array\' ) {\n' + '    testFailed("#1: \'Array\' have attribute DontEnum");\n' + '  } else if ( x === \'Boolean\' ) {\n' + '    testFailed("#1: \'Boolean\' have attribute DontEnum");\n' + '  } else if ( x === \'Date\' ) {\n' + '    testFailed("#1: \'Date\' have attribute DontEnum");\n' + '  } else if ( x === \'RegExp\' ) {\n' + '    testFailed("#1: \'RegExp\' have attribute DontEnum");\n' + '  } else if ( x === \'Error\' ) {\n' + '    testFailed("#1: \'Error\' have attribute DontEnum");\n' + '  } else if ( x === \'EvalError\' ) {\n' + '    testFailed("#1: \'EvalError\' have attribute DontEnum");\n' + '  } else if ( x === \'RangeError\' ) {\n' + '    testFailed("#1: \'RangeError\' have attribute DontEnum");\n' + '  } else if ( x === \'ReferenceError\' ) {\n' + '    testFailed("#1: \'ReferenceError\' have attribute DontEnum");\n' + '  } else if ( x === \'SyntaxError\' ) {\n' + '    testFailed("#1: \'SyntaxError\' have attribute DontEnum");\n' + '  } else if ( x === \'TypeError\' ) {\n' + '    testFailed("#1: \'TypeError\' have attribute DontEnum");\n' + '  } else if ( x === \'URIError\' ) {\n' + '    testFailed("#1: \'URIError\' have attribute DontEnum");\n' + '  }\n' + '}\n';
    var sjny = evalStr.match(evalStr, evalStr);
    var nPdY = evalStr.strike();
    var sAeK = evalStr.match(-4294967296, evalStr);
    var BSzd = evalStr.blink();
    var aJsH = evalStr.slice(0, evalStr.length);
    eval(evalStr);
    var cjKy = new Map([
        [
            2147483649,
            42
        ],
        []
    ]);
    var pwFX = new Uint8Array([
        1200,
        1e+81,
        1.7976931348623157e+308,
        5e-324
    ]);
    var PdSk = new WeakSet([
        [
            -1,
            -9007199254740992,
            -1
        ],
        [
            1e-81,
            4294967297,
            -1
        ]
    ]);
} catch (ex) {
    sputnikException = ex;
}
var successfullyParsed = true;