var builtInPropertyNames = [
    'prototype',
    'length',
    0,
    1,
    '$1',
    'name',
    'message',
    'constructor'
];
var PcfS = new WeakSet([
    [
        builtInPropertyNames,
        builtInPropertyNames,
        builtInPropertyNames.length,
        -2147483647,
        builtInPropertyNames,
        -1,
        builtInPropertyNames,
        builtInPropertyNames
    ],
    [
        builtInPropertyNames,
        1e+400,
        1e+81,
        builtInPropertyNames,
        builtInPropertyNames.length,
        1.7976931348623157e+308
    ]
]);
var DYJi = getAnException();
var xtbn = new ArrayBuffer(builtInPropertyNames);
xtbn = builtInPropertyNames.indexOf(759250124, function () {
});
var hyyW = getSpecialObjects();
var dMws = ~NaN;
runTest(function () {
});
var MJdQ = runTest(function () {
});
runTest(function () {
});
runTest(function () {
});
var bdXp = getAnException();
runTest(function () {
});
getAnException();
getAnException();
hyyW = hyyW.join(bdXp.stack, builtInPropertyNames.length, bdXp);
var builtInPropertyNamesMayThrow = [
    'caller',
    'arguments'
];
builtInPropertyNames.length = -4294967296 == 9007199254740991;
dMws = builtInPropertyNamesMayThrow.splice(dMws, dMws, builtInPropertyNames, 4294967295, builtInPropertyNamesMayThrow, 0);
var JGKH = runTest(function () {
});
var MxwW = runTest(function () {
});
var bAPw = runTest(function () {
});
builtInPropertyNamesMayThrow.splice(-4294967296, 10000, -4294967296, 759250124, 42, 1);
function getAnException() {
    try {
        'str'();
        var Tjw4 = -2147483647;
        getAnException();
        var Xskw = getSpecialObjects();
    } catch (e) {
        return e;
    }
}
function getSpecialObjects() {
    return [
        function () {
        },
        [
            1,
            2,
            3
        ],
        /xxx/,
        RegExp,
        'blah',
        9,
        new Date(),
        getAnException()
    ];
}
var object = {};
var fEHj = getSpecialObjects();
var kzTR = builtInPropertyNames.entries();
var DGYY = getSpecialObjects();
var fun = function () {
};
var JwWa = getSpecialObjects();
var YZHm = runTest(function () {
});
var pKbb = getSpecialObjects();
var Hnpa = runTest(function () {
});
var someException = getAnException();
var someDate = new Date();
var objects = [
    [
        1,
        Number.prototype
    ],
    [
        'foo',
        String.prototype
    ],
    [
        true,
        Boolean.prototype
    ],
    [
        object,
        object
    ],
    [
        fun,
        fun
    ],
    [
        someException,
        someException
    ],
    [
        someDate,
        someDate
    ]
];
function runTest(fun) {
    for (var i in objects) {
        var obj = objects[i][0];
        var chain = objects[i][1];
        var specialObjects = getSpecialObjects();
        for (var j in specialObjects) {
            var special = specialObjects[j];
            chain.__proto__ = special;
            for (var k in builtInPropertyNames) {
                var propertyName = builtInPropertyNames[k];
                fun(obj, propertyName);
            }
            for (var k in builtInPropertyNamesMayThrow) {
                var propertyName = builtInPropertyNamesMayThrow[k];
                try {
                    fun(obj, propertyName);
                } catch (e) {
                }
            }
        }
    }
}
runTest(function (obj, name) {
    return obj[name];
});
runTest(function (obj, name) {
    return obj[name] = {};
});