function main() {
    function v0(v1, v2) {
        let v5 = 0;
        const v6 = v5 + 1;
        v5 = v6;
        const v8 = [];
        let v9 = v8;
        const v10 = Object.create(v9);
        with (v9) {
        }
    }
    let v15 = 3325043349;
    const v16 = v15 + 1;
    for (let v20 = 0; v20 < 127; v20++) {
        const v21 = v0(v0, v16);
    }
}
main();