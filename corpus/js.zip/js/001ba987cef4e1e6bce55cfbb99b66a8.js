function opt(arg) {
    let x = arguments.length;
    a1 = new Array(16);
    var f86X = -0;
    a2 = new Array(2);
    var Abim = new WeakSet([
        [
            1,
            1e+400,
            -2147483647,
            1.7976931348623157e+308,
            9007199254740994,
            1e-81
        ],
        [
            -9007199254740994,
            0,
            4,
            1200,
            -4294967296
        ]
    ]);
    var zQxw = new Uint8ClampedArray([
        9007199254740994,
        1518500249,
        -9007199254740992
    ]);
    -4294967296, 4, 1e+81, 1.7976931348623157e+308;
    var zbiB = 9007199254740994 > 42;
    a2[0] = 1.1;
    a2[1] = 1.1;
    var ZbMR = opt(0);
    var XXdp = new Map([
        [
            3.141592653589793,
            NaN,
            673720360,
            -9007199254740990
        ],
        [
            2147483647,
            153,
            1e-81,
            1.7976931348623157e+308,
            673720360
        ]
    ]);
    a1[(x >> 16) * 15728640] = 1.39064994160909e-309;
    var GrnA = new WeakSet([
        [
            4,
            1.3,
            2147483648,
            1e+81,
            0,
            4294967297
        ],
        [
            -9007199254740991,
            0,
            4,
            4294967295,
            -9007199254740994,
            0.1,
            673720360,
            1e+400
        ]
    ]);
}
var a1, a2;
var QYXb = - -9007199254740991;
let small = [1.1];
let large = [
    1.1,
    1.1
];
console = new WeakSet([
    [
        NaN,
        0,
        large,
        NaN,
        1e+400,
        759250124,
        small,
        small.length,
        NaN,
        console
    ],
    [
        -1,
        1e-81,
        small,
        small.length
    ]
]);
console = large.some(function () {
}, 9007199254740991);
large.fill(1.1);
for (let j = 0; j < 100000; j++) {
}