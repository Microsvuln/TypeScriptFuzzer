function main() {
    for (let v3 = 0; v3 < 100; v3++) {
        try {
            let v6 = 0;
            const v10 = [];
            let v12 = v3;
            const v15 = [
                13.37,
                13.37,
                13.37,
                v12,
                13.37
            ];
            let v16 = v3;
            function v17(v18, v19) {
                let v23 = String;
                const v24 = v23.fromCharCode(1792147552, 255, 1792147552, v3, v18);
                const v25 = Function(v24);
                const v27 = [
                    1337,
                    1337,
                    1337
                ];
                const v30 = [
                    v27,
                    Set,
                    'buffer'
                ];
                for (let v34 = 0; v34 < 100; v34++) {
                    const v35 = [];
                    let v36 = v34;
                    const v39 = [
                        13.37,
                        13.37,
                        13.37,
                        v36,
                        13.37
                    ];
                    let v40 = v30;
                    function v41(v42, v43) {
                        for (let v47 = 0; v47 < 1000; v47++) {
                        }
                        const v48 = v35.match;
                        const v49 = v30.indexOf(v48);
                        v40.constructor = v42;
                        for (let v52 = v36; v52 < 127; v52++) {
                            for (let v56 = 10; v56 < 100; v56 = v56 + 9) {
                                let v58 = String;
                            }
                        }
                    }
                    const v59 = v41(...v35, v40, ...v39, 65537, 13.37);
                }
            }
            let v63 = v10;
            const v64 = v17(...v63, v16, ...v15, 65537, 13.37);
        } catch (v65) {
        }
    }
}
main();