function main() {
    const v2 = [
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v4 = [
        1337,
        1337,
        1337
    ];
    const v6 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v8 = {
        construct: Symbol,
        getOwnPropertyDescriptor: Symbol,
        getPrototypeOf: Symbol,
        preventExtensions: Symbol,
        defineProperty: Symbol
    };
    const v10 = new Proxy(v4, v8);
    const v11 = v2 != v4;
    let v14 = 0;
    const v16 = [
        1337,
        1337
    ];
    const v19 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v20 = [];
    let v21 = v20;
    function v22(v23, v24) {
        try {
            const v26 = [
                v22,
                1337,
                1337,
                1337
            ];
            const v29 = [
                '__proto__',
                -1.7976931348623157e+308,
                v26,
                -1.7976931348623157e+308
            ];
            const v33 = v29.toLocaleString();
            const v34 = v33 < v16;
            const v35 = v24(...v23, v34, v34, v6, 13.37);
            return 13.37;
        } catch (v36) {
        }
        const v39 = v22.toLocaleString();
        const v40 = v39.replace(13.37, v21);
        const v41 = eval(v40);
        return v22;
    }
    const v42 = [];
    let v43 = v42;
    const v44 = v22(...v43, v21, ...v19, 10, 13.37);
    const v45 = v16.reduce(v44, v20);
}
main();