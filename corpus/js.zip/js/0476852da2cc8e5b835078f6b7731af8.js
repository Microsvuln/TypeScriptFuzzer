function main() {
    const v3 = [13.37];
    const v5 = [
        1337,
        v3
    ];
    const v6 = [
        String,
        'aJ+k7Gt0yR',
        v3
    ];
    const v7 = {
        valueOf: 'aJ+k7Gt0yR',
        b: 'aJ+k7Gt0yR',
        d: v5,
        toString: 1337
    };
    let v8 = v3;
    const v15 = [
        13.37,
        13.37,
        13.37
    ];
    const v16 = {
        a: 'MAX_VALUE',
        valueOf: v15
    };
    const v21 = [
        1337,
        13.37,
        13.37,
        13.37,
        'arguments'
    ];
    let v22 = v16;
    function v23(v24, v25) {
        let v28 = 0;
        const v31 = [
            1000000000000,
            1000000000000,
            1000000000000,
            1000000000000,
            1000000000000
        ];
        const v32 = [];
        let v33 = v32;
        function v34(v35, v36) {
            const v38 = 'p76QI.ipnu'.charAt(v25);
            const v40 = arguments.search;
        }
        const v41 = [];
        let v42 = v41;
        const v43 = v34(...v42, v33, ...v31, 10, 1000000000000);
        let v46 = 0;
        let v49 = 0;
        const v50 = v49 + 1;
        v49 = v50;
        const v54 = v28 + 1;
        v28 = v54;
    }
    const v55 = [];
    let v56 = v55;
    const v57 = v23(...v56, v22, ...v21, 10, 13.37);
    const v63 = [
        13.37,
        13.37,
        13.37
    ];
    const v65 = [
        1337,
        1337,
        1337
    ];
    const v66 = [13.37];
    const v67 = { b: 1337 };
    const v68 = {};
    let v69 = 1337;
    const v74 = [
        13.37,
        13.37
    ];
    const v76 = 'PI'.padStart(1337, 'PI');
    const v77 = [
        1337,
        1337
    ];
    const v78 = [
        13.37,
        v77,
        v77,
        Boolean
    ];
    const v79 = {
        valueOf: 536870912,
        c: 13.37,
        length: v78,
        a: 1337,
        toString: 536870912
    };
    const v80 = {
        toString: v78,
        valueOf: Boolean,
        b: v79,
        c: v79,
        length: 13.37,
        a: 536870912
    };
    let v81 = 13.37;
    const v87 = new Uint32Array(11105);
    const v88 = v87.includes(592813305, -268435456);
    v79.a = 1337;
    for (let v94 = 0; v94 < 0; v94++) {
        let v97 = 0;
        delete v94[5];
        const v98 = v97 + 1;
        v97 = v98;
    }
    const v99 = {
        __proto__: v74,
        length: 0,
        b: v77,
        c: 'byteLength',
        valueOf: 0,
        d: 'byteLength'
    };
    v99.a = v77;
    v74.__proto__ = 'byteLength';
    let v105 = 4127287131;
    const v108 = [
        1337,
        1337,
        1337
    ];
    let v111 = 0;
    while (v111 < 10) {
        for (let v116 = 0; v116 < 100; v116++) {
            const v117 = Array(11105);
        }
        const v120 = 'split'.replace('split', 'split');
        const v121 = v120[v120];
        const v124 = [
            13.37,
            13.37,
            13.37
        ];
        const v126 = [
            1337,
            1337,
            1337
        ];
        const v127 = [
            13.37,
            v124
        ];
        const v128 = {};
        const v129 = {
            constructor: v126,
            valueOf: 'split',
            c: v128,
            a: 1337,
            e: v127
        };
        let v130 = v129;
        let v136 = 0;
        while (v136 == 7) {
        }
        for (let v141 = 0; v141 < 10; v141++) {
        }
        const v143 = { a: v121 };
        function v144(v145, v146, v147, v148) {
        }
        const v149 = 'p76QI.ipnu'.codePointAt(-65535);
        const v150 = v111 + 1;
        v111 = v150;
    }
    const v152 = RegExp('p76QI.ipnu');
    const v153 = [
        1337,
        1337,
        1337,
        1337,
        1337
    ];
    const v154 = [];
    const v155 = {
        b: 1337,
        a: v153,
        valueOf: 1337,
        e: 1337,
        d: Uint32Array
    };
    const v156 = typeof v6;
    const v158 = v156 === 'boolean';
    let v161 = 0;
    const v162 = v153 <= v152;
}
main();