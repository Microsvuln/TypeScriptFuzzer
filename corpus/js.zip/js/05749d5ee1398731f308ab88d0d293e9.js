function main() {
    const v4 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v6 = [
        1337,
        1337,
        1337,
        1337
    ];
    const v11 = [
        13.37,
        13.37,
        13.37
    ];
    const v13 = [
        1337,
        1337,
        1337,
        1337
    ];
    const v14 = [
        v13,
        v11
    ];
    const v15 = {
        constructor: WeakMap,
        b: v11,
        __proto__: v13,
        toString: '3RRchelia0',
        e: WeakMap,
        length: -3695107751
    };
    const v16 = {
        b: '3RRchelia0',
        c: v11,
        a: 13.37,
        e: v11
    };
    let v17 = v15;
    const v23 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v25 = [
        1337,
        1337,
        1337,
        1337,
        1337
    ];
    const v26 = [];
    const v27 = {
        e: v25,
        length: 13.37,
        d: v25,
        __proto__: Symbol,
        valueOf: v23,
        c: 'p76QI.ipnu'
    };
    const v28 = {
        b: 1337,
        a: v25,
        valueOf: 1337,
        e: 1337,
        d: Symbol
    };
    let v29 = v26;
    const v34 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v36 = [
        1337,
        1337,
        1337,
        1337,
        1337
    ];
    const v37 = [];
    const v38 = {
        e: v36,
        length: 13.37,
        d: v36,
        __proto__: Symbol,
        valueOf: v34,
        c: 'p76QI.ipnu'
    };
    const v39 = {
        b: 1337,
        a: v36,
        valueOf: 1337,
        e: 1337,
        d: Symbol
    };
    let v40 = v37;
    10 .toString = 10;
    const v42 = 10[-1109617344];
    const v45 = 'p76QI.ipnu'.padEnd(v42, 'p76QI.ipnu');
    v45.c = Symbol;
    const v46 = 'p76QI.ipnu'.substring(v42, v42);
    const v48 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v50 = [
        1337,
        1337,
        1337,
        1337,
        1337
    ];
    const v51 = [];
    const v52 = {
        e: v50,
        length: 1337,
        d: v50,
        __proto__: Symbol,
        valueOf: v48,
        c: 'p76QI.ipnu'
    };
    const v53 = {
        b: 1337,
        a: v50,
        valueOf: 1337,
        e: 1337,
        d: Symbol
    };
    let v54 = v48;
    let v60 = 0;
    while (v60 < 5) {
        const v61 = v60 + 1;
        v60 = v61;
    }
    const v62 = v54.find(Symbol, v53);
    const v63 = typeof v51;
    const v65 = v63 === 'boolean';
    let v66 = v65;
    if (v62) {
        v66 = v52;
    } else {
        const v67 = v50 << v66;
        v66 = Symbol;
    }
    let v68 = v65;
    if (v65) {
        const v69 = v46.__proto__;
        v68 = v65;
    } else {
        const v71 = {
            get: v42,
            set: Symbol
        };
        const v73 = Object.defineProperty(v53, 4104864933, v71);
        v68 = v52;
    }
    const v89 = [];
    'p76QI.ipnu'.length = v89;
    for (let v98 = 0; v98 < 10; v98++) {
        continue;
    }
    v23.constructor = v29;
    const v99 = 'p76QI.ipnu'.slice(10, 0);
    const v100 = Symbol('hasInstance');
    const v104 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v106 = [
        1337,
        1337,
        1337,
        1337,
        1337
    ];
    const v107 = [];
    const v108 = {
        e: v106,
        length: 13.37,
        d: v106,
        __proto__: Symbol,
        valueOf: v104,
        c: 'p76QI.ipnu'
    };
    const v109 = {
        b: 1337,
        a: v106,
        valueOf: 1337,
        e: 1337,
        d: Symbol
    };
    let v110 = v107;
    const v115 = [
        Set,
        Set,
        1337,
        '0MS*nEwLSL'
    ];
    const v116 = {};
    function v117(v118, v119, v120) {
        'use strict';
        return v119;
    }
    const v123 = new Int32Array(64070);
    for (let v128 = 0; v128 < 100; v128++) {
        const v130 = v37[65536];
        v54 = v130;
        const v131 = typeof 10;
        const v133 = v131 === 'boolean';
        let v134 = v50;
        if (v65) {
            const v135 = Symbol & 1337;
            v134 = v135;
        } else {
            continue;
            v134 = 1;
        }
        const v136 = gc();
    }
    with (1630) {
    }
    const v139 = [
        Symbol,
        1337,
        Symbol
    ];
    const v140 = {};
    const v141 = {
        toString: 13.37,
        valueOf: v6,
        b: v4,
        c: 'string'
    };
    let v142 = 13.37;
    const v147 = [13.37];
    const v149 = [1337];
    const v150 = [
        1337,
        v149
    ];
    const v151 = {};
    const v152 = {
        toString: 'NEGATIVE_INFINITY',
        __proto__: 'NEGATIVE_INFINITY',
        constructor: 1337,
        c: v147
    };
    let v153 = 287121007;
    function v154(v155, v156, v157, v158, v159) {
        let v164 = 0;
        while (v164 < 4) {
            while (1337 < 'POSITIVE_INFINITY') {
            }
            const v174 = [
                13.37,
                13.37,
                13.37,
                13.37,
                13.37
            ];
            const v176 = [
                1337,
                1337,
                1337,
                1337,
                1337
            ];
            const v177 = [];
            const v178 = {
                e: v176,
                length: 13.37,
                d: v176,
                __proto__: Symbol,
                valueOf: v174,
                c: 'p76QI.ipnu'
            };
            const v179 = {
                b: 1337,
                a: v176,
                valueOf: 1337,
                e: 1337,
                d: Symbol
            };
            let v180 = v177;
            const v185 = [
                13.37,
                13.37,
                13.37,
                'p76QI.ipnu',
                13.37
            ];
            const v187 = [];
            const v188 = [
                1337,
                1337,
                1337,
                1337,
                1337
            ];
            const v189 = [];
            for (let v193 = 0; v193 < 6; v193++) {
            }
            let v196 = 0;
            while (v196 < 10) {
                const v197 = v174.findIndex(Symbol, v180);
                const v198 = v196 + 1;
                v196 = v198;
            }
            const v199 = v164 + 1;
            v164 = v199;
        }
        const v204 = [
            13.37,
            13.37,
            13.37,
            13.37,
            13.37
        ];
        const v206 = [
            4026405314,
            4026405314,
            4026405314,
            4026405314,
            4026405314
        ];
        const v207 = {
            e: v206,
            length: 1337,
            d: v206,
            __proto__: Map,
            valueOf: v204,
            c: 'p76QI.ipnu'
        };
        for (let v209 = 0; v209 < 1; v209++) {
            const v210 = v209 / v154;
        }
        return Uint16Array;
    }
    for (let v214 = 0; v214 < 100; v214++) {
        const v215 = v154(v154);
        const v217 = Number.isInteger(Number);
        let v220 = 0;
    }
}
main();