function main() {
    const v4 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v6 = [
        1337,
        1337,
        1337
    ];
    const v7 = [
        13.37,
        Float64Array,
        13.37
    ];
    const v8 = {
        a: Float64Array,
        c: 13.37,
        c: v6
    };
    const v9 = { d: v8 };
    let v10 = v9;
    for (const v12 of 'hasInstance') {
        const v16 = [
            2.220446049250313e-16,
            2.220446049250313e-16,
            2.220446049250313e-16,
            2.220446049250313e-16,
            2.220446049250313e-16
        ];
        const v20 = [
            1337,
            1337
        ];
        const v23 = 'p76QI.ipnu'.endsWith(v20, 100);
        const v27 = [13.37];
        const v29 = [
            1337,
            1337,
            1337
        ];
        const v30 = [
            128,
            v29,
            1337
        ];
        const v31 = {
            b: v27,
            valueOf: 13.37,
            e: v30,
            __proto__: 1337
        };
        const v32 = { valueOf: v29 };
        let v33 = v29;
        const v38 = [
            13.37,
            13.37
        ];
        const v40 = [1337];
        const v41 = isFinite();
        v29.length = 1337;
        with (v27) {
            const v44 = new Uint16Array(255);
        }
        'p76QI.ipnu'[v32] = 13.37;
        const v45 = [
            '1NteYVtKCs',
            '1NteYVtKCs',
            v40
        ];
        const v46 = {
            b: v45,
            constructor: 255,
            a: v45
        };
        const v47 = { toString: isFinite };
        let v48 = 13.37;
        let v52 = 255;
        let v55 = 0;
        do {
            const v56 = v55 + 1;
            v55 = v56;
        } while (v55 < 9);
        const v57 = v29[536870912];
        do {
            for (const v58 in 1) {
                const v59 = v58.find();
            }
        } while (10 == 1);
        const v73 = v46 && 10;
        const v74 = v33 << 0;
        const v75 = '1NteYVtKCs'.startsWith('toString');
        const v76 = Symbol('p76QI.ipnu');
        const v78 = v48 + 1;
        const v79 = Object[11877];
        v76.length = 2;
        const v82 = [
            13.37,
            13.37
        ];
        const v83 = Symbol('p76QI.ipnu');
        const v84 = [
            1337,
            1337,
            1337,
            1337,
            1337
        ];
        const v85 = {
            e: v84,
            length: 2.220446049250313e-16,
            d: v84,
            __proto__: Symbol,
            valueOf: v16,
            c: '6oMBmaoCif'
        };
        const v88 = [];
        let v89 = Symbol;
        Symbol.__proto__ = v88;
        for (const v90 of 'p76QI.ipnu') {
            for (const v91 of v89) {
            }
        }
        for (const v92 of v85) {
        }
    }
}
main();