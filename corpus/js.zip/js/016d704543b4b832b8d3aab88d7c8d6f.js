function main() {
    const v3 = [-3179590583];
    for (let v7 = 0; v7 < 1000; v7++) {
        try {
            let v9 = v7;
            const v11 = [
                13.37,
                13.37,
                13.37,
                v9,
                13.37
            ];
            let v12 = v7;
            function v13(v14, v15) {
                let v17 = String;
                const v18 = v17.fromCharCode(v14, v7, v9, v7, 1902352450);
                const v19 = eval(v18);
            }
            let v20 = v3;
            const v21 = v13(...v20, v12, ...v11, 1337, 13.37);
        } catch (v22) {
        }
    }
}
main();