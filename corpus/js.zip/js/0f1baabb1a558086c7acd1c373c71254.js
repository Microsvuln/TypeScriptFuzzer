function main() {
    const v2 = { get: RegExp };
    const v4 = Object.freeze(RegExp, 'constructor', v2);
}
main();