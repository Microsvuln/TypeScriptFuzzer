  onconnect = function(e) {
    e.ports[0].postMessage('3');
  }