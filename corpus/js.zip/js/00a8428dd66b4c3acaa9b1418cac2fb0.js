function main() {
    let v2 = 0;
    while (v2 < 4) {
        let v5 = 0;
        do {
            const v6 = v5 + 1;
            const v9 = [
                13.37,
                13.37,
                13.37,
                13.37,
                13.37
            ];
            let v10 = 10;
            function v11(v12, v13) {
                let v16 = 0;
                while (v16 < 10) {
                    const v21 = [
                        1337,
                        13.37,
                        13.37,
                        13.37,
                        13.37
                    ];
                    let v22 = 13.37;
                    function v23(v24, v25) {
                        const v27 = Math.fround(v22);
                        const v29 = [
                            13.37,
                            13.37,
                            13.37,
                            13.37,
                            13.37
                        ];
                        let v33 = 0;
                    }
                    const v34 = [];
                    let v35 = v34;
                    const v36 = v23(...v35, v22, ...v21, 10, 13.37);
                    const v37 = v16 + 1;
                    v16 = v37;
                }
            }
            const v38 = [];
            let v39 = v38;
            const v40 = v11(...v39, v10, ...v9, v39, 13.37);
            v5 = v6;
        } while (v5 < 8);
        const v41 = v2 + 1;
        v2 = v41;
    }
}
main();