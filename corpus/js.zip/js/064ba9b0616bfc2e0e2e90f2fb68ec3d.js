function main() {
    for (let v3 = 0; v3 < 100; v3++) {
        const v6 = [
            13.37,
            13.37,
            13.37,
            13.37,
            13.37
        ];
        const v7 = [];
        let v8 = v7;
        function v9(v10, v11) {
            const v14 = new Int8Array(39929);
            function v15(v16, v17, v18, v19, v20) {
            }
            const v22 = v15.toLocaleString();
            const v23 = eval(v22);
            const v26 = [
                13.37,
                13.37,
                13.37,
                13.37,
                13.37
            ];
            const v27 = [];
            let v28 = v27;
            function v29(v30, v31) {
                const v32 = -Infinity;
                let v35 = 0;
                while (v35 < 10) {
                    const v36 = v35 + 1;
                    v35 = v36;
                    with ('Trm+02uWKk') {
                    }
                }
            }
            const v41 = [];
            let v42 = v41;
            const v43 = v29(...v42, v28, ...v26, 10, 13.37);
            const v44 = v14.buffer;
        }
        const v48 = [];
        let v49 = v48;
        const v50 = v9(...v49, v8, ...v6, 10, 13.37);
    }
}
main();