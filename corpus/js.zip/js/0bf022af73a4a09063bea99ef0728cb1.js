function main() {
    const v2 = [
        -441746.4139016614,
        -441746.4139016614,
        -441746.4139016614,
        -441746.4139016614,
        -441746.4139016614
    ];
    const v3 = [];
    let v4 = v3;
    function v5(v6, v7) {
        const v9 = [String];
        const v10 = [v9];
        const v11 = [v10];
        const v13 = JSON.stringify(v11, String, v10);
        const v16 = [
            -441746.4139016614,
            -441746.4139016614,
            -441746.4139016614,
            -441746.4139016614,
            -441746.4139016614
        ];
        const v17 = [];
        let v18 = v17;
        function v19(v20, v21) {
            const v23 = [
                1337,
                1337
            ];
            const v26 = [
                13.37,
                13.37,
                13.37,
                13.37,
                13.37
            ];
            let v27 = v13;
            function v28(v29, v30) {
                const v32 = [
                    1337,
                    1337,
                    1337,
                    1337,
                    1337
                ];
                for (let v38 = 0; v38 < 255; v38++) {
                    try {
                        const v39 = [];
                        let v41 = v38;
                        const v44 = [
                            v38,
                            13.37,
                            13.37,
                            v41,
                            13.37
                        ];
                        let v45 = v38;
                        function v46(v47, v48) {
                            let v52 = String;
                            const v53 = v52.fromCharCode(2339146182, 255, v38, 5, v32);
                            const v54 = RegExp(v53);
                            return v54;
                        }
                        let v55 = v39;
                        const v56 = v46(...v55, v45, ...v44, 65537, 13.37);
                        const v57 = 'NEGATIVE_INFINITY'.replace(v56, v56);
                    } catch (v58) {
                    }
                }
            }
            let v59 = v23;
            const v60 = v28(...v59, v27, ...v26, 10, 13.37);
        }
        const v61 = [];
        let v62 = v61;
        const v63 = v19(...v62, ...v18, ...v16, -2418880158, -441746.4139016614);
    }
    const v64 = [];
    let v65 = v64;
    const v66 = v5(v65, ...v4, ...v2, 1337, -441746.4139016614);
}
main();