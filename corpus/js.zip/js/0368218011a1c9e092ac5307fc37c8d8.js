function main() {
    const v37 = [];
    const v64 = [
        13.37,
        13.37,
        13.37
    ];
    const v65 = {
        a: 'MAX_VALUE',
        valueOf: v64
    };
    const v70 = [
        1337,
        13.37,
        13.37,
        13.37,
        'arguments'
    ];
    let v71 = v65;
    function v72(v73, v74) {
        let v77 = 0;
        while (v77 < 10) {
            for (let v167 = 0; v167 < 10; v167++) {
                const v170 = [
                    13.37,
                    13.37,
                    13.37,
                    13.37,
                    13.37
                ];
                const v171 = [];
                let v172 = v171;
                function v173(v174, v175) {
                    const v182 = Array[8];
                    const v186 = {
                        e: v182,
                        set: Symbol
                    };
                    const v188 = Object.defineProperty(Symbol, -4294967297, v186);
                    for (let v193 = 0; v193 < 8; v193++) {
                    }
                    const v197 = Symbol instanceof Symbol;
                }
                const v198 = [];
                let v199 = v198;
                const v200 = v173(...v199, v172, ...v170, 10, 13.37);
            }
            let v324 = 0;
            const v353 = { set: Symbol };
            const v355 = Object.defineProperty(Symbol, 2365454094, v353);
            const v419 = v77 + 1;
            v77 = v419;
        }
    }
    const v420 = [];
    let v421 = v420;
    const v422 = v72(...v421, v71, ...v70, 10, 13.37);
    const v425 = v72(10, 0);
}
main();