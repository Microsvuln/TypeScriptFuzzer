function main() {
    const v3 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v5 = [
        1337,
        1337,
        1337,
        1337,
        1337
    ];
    const v6 = [];
    const v7 = {
        e: v5,
        length: 13.37,
        d: v5,
        __proto__: Symbol,
        valueOf: v3,
        c: 'p76QI.ipnu'
    };
    const v8 = {
        b: 1337,
        a: v5,
        valueOf: 1337,
        e: 1337,
        d: Symbol
    };
    const v12 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v14 = [
        1337,
        1337,
        1337,
        1337,
        1337
    ];
    const v15 = [];
    const v16 = {
        e: v14,
        length: 13.37,
        d: v14,
        __proto__: Symbol,
        valueOf: v12,
        c: 'p76QI.ipnu'
    };
    'p76QI.ipnu'.length = 255;
    const v22 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v24 = [
        1337,
        1337,
        1337,
        1337,
        1337
    ];
    const v25 = [];
    const v26 = {
        e: v24,
        length: 13.37,
        d: v24,
        __proto__: Symbol,
        valueOf: v22,
        c: 'p76QI.ipnu'
    };
    const v27 = {
        b: 1337,
        a: v24,
        valueOf: 1337,
        e: 1337,
        d: Symbol
    };
    let v28 = v25;
    const v30 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v32 = [
        1337,
        1337,
        1337,
        1337,
        1337
    ];
    const v33 = [];
    let v34 = v33;
    const v37 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v39 = [
        1337,
        1337,
        1337,
        1337,
        1337
    ];
    const v40 = [];
    const v41 = {
        b: 1337,
        a: v39,
        valueOf: 1337,
        length: 1337,
        d: Symbol
    };
    let v42 = v40;
    const v46 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v48 = [
        1337,
        1337,
        1337,
        1337,
        1337
    ];
    const v49 = [];
    const v50 = {
        b: 1337,
        a: v48,
        valueOf: 1337,
        e: 1337,
        d: Symbol
    };
    let v51 = v49;
    const v55 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v56 = v51.__proto__;
    const v59 = new Float32Array(10152);
    const v60 = v48.every(Symbol, 'p76QI.ipnu');
    const v62 = [
        1337,
        1337,
        1337,
        1337,
        'p76QI.ipnu'
    ];
    const v63 = [];
    const v64 = {
        e: v62,
        length: 13.37,
        d: v62,
        __proto__: Symbol,
        valueOf: v55,
        c: 'p76QI.ipnu'
    };
    let v65 = v63;
    const v70 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v72 = [
        1337,
        1337,
        1337,
        1337,
        1337
    ];
    const v73 = [];
    const v74 = Symbol >= v46;
    let v75 = 13.37;
    const v82 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v84 = [
        1337,
        1337,
        1337,
        1337,
        1337
    ];
    const v85 = [];
    let v86 = v85;
    const v91 = [
        1000000000000,
        1000000000000,
        1000000000000,
        1000000000000,
        1000000000000
    ];
    const v93 = [
        1337,
        1337,
        1337,
        1337,
        1337
    ];
    const v95 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v97 = Symbol >= v95;
    const v98 = {
        e: v93,
        length: 1000000000000,
        d: v93,
        __proto__: Promise,
        valueOf: v91,
        c: 'p76QI.ipnu'
    };
    const v100 = Object();
    const v102 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v104 = [
        13.37,
        1337,
        1337,
        1337,
        1337
    ];
    const v105 = {
        b: 1337,
        a: v104,
        valueOf: 1337,
        e: 1337,
        d: Symbol
    };
    const v108 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    let v110 = 0;
    const v111 = v110 + 1;
    const v113 = 10[-1109617344];
    const v115 = 'p76QI.ipnu'.padEnd(v113, 'p76QI.ipnu');
    const v117 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v119 = v117 in Symbol;
    for (let v123 = 0; v123 < 100; v123++) {
        const v124 = Symbol('p76QI.ipnu');
    }
    const v125 = Object();
    const v126 = Symbol[-777222784];
    const v127 = 'p76QI.ipnu' * v119;
    v91.constructor = v126;
    const v128 = Symbol > v108;
    let v129 = v84;
    if (Promise) {
        const v132 = new Uint8Array(21817);
        v129 = 21817;
    } else {
        v102[v127] = Symbol;
        v129 = 10;
    }
    const v133 = Symbol('p76QI.ipnu');
    let v134 = 0;
    do {
        delete v65[-451555333];
        const v135 = v134 + 1;
        v134 = v135;
    } while (v134 < 8);
    v75 = v74;
    v75 = 13.37;
    const v136 = ~v51;
    const v137 = v64[-9007199254740992];
    const v138 = {
        e: v72,
        length: 13.37,
        d: v72,
        __proto__: Symbol,
        valueOf: v70,
        c: 'p76QI.ipnu'
    };
    const v139 = {
        b: v40,
        a: v72,
        valueOf: 1337,
        e: 1337,
        d: Symbol
    };
    const v143 = [
        1000000000000,
        1000000000000,
        1000000000000,
        1000000000000,
        1000000000000
    ];
    const v145 = [
        1337,
        1337,
        1337,
        1337,
        1337
    ];
    const v146 = [];
    const v147 = {
        b: 1337,
        a: v145,
        valueOf: 1337,
        e: 1337,
        d: Promise
    };
    let v148 = v146;
    v146.constructor = v136;
    let v150 = v55;
    const v152 = [
        1337,
        1337,
        1337,
        1337,
        1337
    ];
    const v153 = [];
    const v156 = new Uint8Array(45433);
    v150.__proto__ = v138;
    const v157 = {
        d: Object,
        a: v62,
        length: v136,
        e: v48,
        b: v146
    };
    const v158 = Symbol('p76QI.ipnu');
    const v161 = new Float64Array(56507);
    const v162 = Symbol(Promise);
}
main();