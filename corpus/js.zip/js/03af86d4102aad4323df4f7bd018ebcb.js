function main() {
    const v4 = [
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v6 = [
        1337,
        1337,
        1337,
        1337,
        4
    ];
    const v7 = [];
    const v8 = { b: v4 };
    const v9 = {
        a: 'o+AOGG01y9',
        __proto__: v8
    };
    let v10 = v4;
    function v15(v16, v17, v18, v19, v20) {
        const v21 = !Symbol;
        return 10;
    }
    const v22 = 10[Symbol];
    const v23 = 'p76QI.ipnu'.__proto__;
    const v24 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    let v28 = 0;
    do {
        const v29 = v28 + 1;
        v28 = v29;
        let v32 = 0;
        while (v32 < 5) {
            function v33(v34, v35, v36, v37, ...v38) {
                let v40 = 0;
                function v44(v45, v46, v47, v48) {
                    const v51 = [
                        13.37,
                        13.37,
                        13.37,
                        13.37,
                        13.37
                    ];
                    let v52 = 0;
                    function v53(v54, v55) {
                    }
                    const v56 = [];
                    let v57 = v56;
                    const v58 = v53(...v57, v52, ...v51, 10, 13.37);
                }
                const v62 = v44(0, v40, 0, 0);
                let v65 = 0;
                const v66 = v65 + 1;
                let v69 = 0;
                do {
                    const v70 = v38.find(v33, v22);
                    const v71 = v69 + 1;
                    v69 = v71;
                } while (v69 < 8);
            }
            for (let v75 = 0; v75 < 10; v75++) {
                const v76 = v33();
            }
            const v77 = v32 + 1;
            v32 = v77;
        }
    } while (v28 < 8);
    let v80 = 0;
    const v81 = [
        1337,
        1337,
        1337,
        1337,
        1337
    ];
    const v82 = [];
    const v83 = {
        e: v81,
        length: 13.37,
        d: v81,
        __proto__: Symbol,
        valueOf: v24,
        c: 'p76QI.ipnu'
    };
    const v84 = {
        b: 1337,
        a: v81,
        valueOf: 1337,
        e: 1337,
        d: Symbol
    };
    let v85 = v82;
    const v90 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v91 = v7.length;
    let v92 = v83;
    v23.valueOf = 1337;
    let v95 = 0;
    do {
        const v96 = v95 + 1;
        v95 = v96;
    } while (v95 < 10);
    const v98 = [
        1337,
        1337,
        1337,
        1337,
        1337
    ];
    const v99 = [];
    const v100 = {
        e: v98,
        length: 13.37,
        d: v98,
        __proto__: Symbol,
        valueOf: v90,
        c: 'p76QI.ipnu'
    };
    const v101 = {
        b: 1337,
        a: v98,
        valueOf: 1337,
        e: 1337,
        d: Symbol
    };
    let v102 = v99;
    const v106 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v108 = [
        1337,
        1337,
        1337,
        1337,
        1337
    ];
    let v109 = Symbol;
    let v110 = v83;
    try {
        let v113 = 0;
        do {
            const v114 = v113 + 1;
            v113 = v114;
        } while (v113 < 7);
        const v115 = 0[v98];
        const v116 = v115.d(0, Symbol, v115, v83);
        for (const v117 of v98) {
            const v118 = v117[v109];
        }
        v110 = 10;
    } catch (v119) {
        const v120 = new ArrayBuffer(v119);
    }
    const v121 = 13.37[1000];
    v109 = 1337;
    const v122 = Symbol('p76QI.ipnu');
}
main();