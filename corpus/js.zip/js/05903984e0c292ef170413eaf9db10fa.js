try {
    __string = '1234567890';
    if (__string.match(3)[0] !== '3') {
        testFailed('#1: __string = "1234567890"; __string.match(3)[0]=== "3". Actual: ' + __string.match(3)[0]);
    }
    if (__string.match(3).length !== 1) {
        testFailed('#2: __string = "1234567890"; __string.match(3).length ===1. Actual: ' + __string.match(3).length);
    }
    if (__string.match(3).index !== 2) {
        testFailed('#3: __string = "1234567890"; __string.match(3).index ===2. Actual: ' + __string.match(3).index);
    }
    if (__string.match(3).input !== __string) {
        testFailed('#4: __string = "1234567890"; __string.match(3).input ===__string. Actual: ' + __string.match(3).input);
    }
} catch (ex) {
    sputnikException = ex;
}
var successfullyParsed = true;