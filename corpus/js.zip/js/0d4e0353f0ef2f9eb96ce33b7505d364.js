var players = [
    [
        'flash',
        'html5',
        'download'
    ],
    [
        'flash',
        'download'
    ],
    [
        'html5',
        'download'
    ]
];
var tests = [
    {
        name: 'No file extension',
        config: {
            levels: [
                { file: 'http://playertest.longtailvideo.com/bunnym' },
                { file: 'http://playertest.longtailvideo.com/bunnyo' }
            ],
            image: 'http://content.bitsontherun.com/thumbs/gSzpo2wh-480.jpg'
        }
    },
    {
        name: 'No file extension + type = video',
        config: {
            levels: [
                { file: 'http://playertest.longtailvideo.com/bunnym' },
                { file: 'http://playertest.longtailvideo.com/bunnyo' }
            ],
            image: 'http://content.bitsontherun.com/thumbs/gSzpo2wh-480.jpg',
            type: 'video'
        }
    },
    {
        name: 'Unknown file extension',
        config: {
            levels: [
                { file: 'http://playertest.longtailvideo.com/bunnymp4.jsp' },
                { file: 'http://playertest.longtailvideo.com/bunnyogv.jsp' }
            ],
            image: 'http://content.bitsontherun.com/thumbs/gSzpo2wh-480.jpg'
        }
    },
    {
        name: 'Unknown file extension (mp4) + type = video',
        config: {
            levels: [{ file: 'http://playertest.longtailvideo.com/bunnymp4.jsp' }],
            image: 'http://content.bitsontherun.com/thumbs/gSzpo2wh-480.jpg',
            type: 'video'
        }
    },
    {
        name: 'Unknown file extension (ogv) + type = video',
        config: {
            levels: [{ file: 'http://playertest.longtailvideo.com/bunnyogv.jsp' }],
            image: 'http://content.bitsontherun.com/thumbs/gSzpo2wh-480.jpg',
            type: 'video'
        }
    }
];
for (var test in tests) {
    if (isNaN(test)) {
        break;
    }
    for (var player in players) {
        if (isNaN(player)) {
            break;
        }
        var playerName = ('player-' + tests[test].name + '-' + players[player].join('-')).replace(/[^A-Za-z0-9\-\_]/g, '').toLowerCase();
    }
}