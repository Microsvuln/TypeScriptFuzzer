function main() {
    const v2 = [
        13.37,
        13.37,
        536870912,
        13.37
    ];
    const v5 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    let v8 = 0;
    let v11 = 0;
    const v12 = v11 + 1;
    v11 = v12;
    const v13 = [];
    let v14 = v13;
    function v15(v16, v17) {
        let v20 = 0;
        while (v20 < 10) {
            const v21 = v20 + 1;
            v20 = v21;
            let v27 = 1337;
            const v28 = v27 % 3357878976;
            let v31 = 0;
            const v32 = v31 + 1;
            v31 = v32;
            for (let v33 = 0; v33 < 100; v33++) {
                const v36 = [
                    1337,
                    1337
                ];
                const v37 = [1337];
                const v38 = {
                    e: 1337,
                    __proto__: v36,
                    valueOf: Proxy,
                    d: v37
                };
            }
        }
    }
    const v39 = [];
    let v40 = v39;
    const v41 = v15(...v40, v14, ...v5, 10, 13.37);
}
main();