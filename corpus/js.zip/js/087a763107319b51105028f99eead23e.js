function main() {
    const v1 = [
        1337,
        1337,
        1337,
        1337
    ];
    const v2 = [v1];
    for (let v8 = 0; v8 < 1000; v8++) {
        const v9 = [];
        let v10 = -92041.2220135358;
        const v12 = [
            13.37,
            13.37,
            13.37,
            v10,
            13.37
        ];
        let v13 = v8;
        function v14(v15, v16) {
            let v19 = 0;
            let v22 = 0;
            const v23 = v22 + 1;
            v22 = v23;
            const v24 = v19 + 1;
            v19 = v24;
            const v25 = v2.slice(1337, v15);
            const v26 = v2.push(v25);
        }
        let v27 = v9;
        const v28 = v14(...v27, v13, ...v12, 1337, 13.37);
    }
}
main();