function main() {
    const v2 = ~1;
    for (let v7 = 0; v7 < 127; v7++) {
        for (let v9 = v2; v9 < 100; v9 = v9 + 13.37) {
            try {
                let v11 = String;
                const v12 = v11.fromCharCode(v9, v7, v9, v9, v9);
                const v13 = Function(v12, v9);
            } catch (v14) {
            }
        }
    }
}
main();