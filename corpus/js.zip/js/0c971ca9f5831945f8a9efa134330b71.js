function main() {
    for (const v2 of 'p76QI.ipnu') {
        const v5 = [
            13.37,
            13.37
        ];
        let v8 = 0;
        do {
            const v10 = [
                1337,
                1337,
                1337,
                1337,
                1337
            ];
            const v11 = { get: Array };
            let v14 = 13.37;
            const v15 = new Int8Array(v14);
            const v16 = v15.byteLength;
            const v17 = v8 + 1;
            v8 = v17;
        } while (v8 < 10);
    }
}
main();