var YrnQ = +5e-324;
var xrWs = new Uint16Array([1.7976931348623157e+308]);
var APYA = new Uint8ClampedArray([
    NaN,
    -4294967296,
    YrnQ,
    -1,
    YrnQ,
    YrnQ,
    4294967296,
    YrnQ,
    -9007199254740992
]);
var NsjF = new WeakSet([
    [
        9007199254740990,
        -2147483649,
        -1.7976931348623157e+308,
        -9007199254740990,
        1518500249,
        -9007199254740991,
        1e+400
    ],
    [
        1.3,
        3,
        1.7976931348623157e+308
    ]
]);
var KHmD = opt();
var tNKy = new Int32Array([4]);
var GejR = new Map([
    [
        -2147483648,
        1518500249,
        2147483649
    ],
    [-2147483648]
]);
opt();
opt();
var XGDp = new Float64Array([
    2147483647,
    2147483648,
    -Infinity,
    42,
    1518500249
]);
var rTxk = opt();
opt();
var ZhPi = opt();
opt();
opt();
opt();
opt();
var yQRf = new Map([
    [
        -1.7976931348623157e+308,
        -9007199254740991,
        4
    ],
    [
        1e+400,
        3.141592653589793,
        -5e-324,
        -1,
        2147483647,
        1.3,
        9007199254740990,
        1e+81
    ]
]);
opt();
var jaRK = new ArrayBuffer(YrnQ);
opt();
opt();
var xyYd = opt();
opt();
opt();
opt();
var wReX = new Float64Array([
    -9007199254740991,
    0,
    -1.7976931348623157e+308
]);
var fzaK = opt();
opt();
var WNZH = opt();
opt();
var Rpcj = opt();
opt();
var YYDa = opt();
var dMzR = opt();
opt();
opt();
opt();
opt();
opt();
var Qecw = opt();
var xptf = opt();
var zhrS = opt();
var raEW = opt();
var cbQf = opt();
opt();
var BQDZ = opt();
opt();
var zPXp = new Uint32Array([
    YrnQ,
    YrnQ,
    3,
    -1,
    0.2,
    153
]);
opt();
var SKYK = new Int16Array([
    tNKy['0'],
    GejR,
    -9007199254740991
]);
opt();
var CAtr = opt();
opt();
var rkWf = new Array([
    9007199254740994,
    XGDp['1']
]);
var HeKa = opt();
rkWf.length = zPXp == 42;
opt();
opt();
var ixEm = opt();
var XDXW = opt();
var EecN = opt();
APYA['8'] = -4294967296 >= -5e-324;
opt();
var aTbw = opt();
var zjDp = opt();
var ydwr = new WeakSet([
    [
        XGDp,
        tNKy['0'],
        XGDp,
        1.3
    ],
    [
        tNKy,
        rkWf,
        1e+400,
        YrnQ,
        0,
        9007199254740991,
        APYA['0']
    ]
]);
var yRfw = opt();
var xRwH = opt();
var CWSQ = opt();
var WCCp = opt();
var iGRN = opt();
rkWf.length = GejR >= zPXp;
var rWsR = opt();
var cMzb = opt();
var QQGs = opt();
var tmiJ = new Map([
    [
        YrnQ,
        YrnQ,
        YrnQ,
        YrnQ,
        -Infinity,
        YrnQ,
        1e+81,
        YrnQ,
        2147483649
    ],
    [
        9007199254740991,
        YrnQ,
        1,
        YrnQ
    ]
]);
opt();
opt();
var kFxK = new Set([
    -5e-324,
    -5e-324
]);
opt();
var rnWM = new Map([
    [],
    [
        1e-81,
        zPXp['3'],
        kFxK,
        XGDp['4'],
        zPXp['2'],
        XGDp['2']
    ]
]);
var NRNc = opt();
var XnAe = opt();
var AhcJ = opt();
var wPYw = opt();
XGDp['1'] = 0.2 < zPXp['2'];
opt();
var fmGe = opt();
opt();
opt();
var bDyp = opt();
var WeZz = opt();
var jTFG = opt();
zPXp['0'] = 0 > 9007199254740992;
var xpAR = opt();
var xtmH = opt();
var XFik = opt();
opt();
opt();
var shGT = opt();
var EZHj = opt();
var yhZp = opt();
var sisW = opt();
opt();
var WfwB = opt();
opt();
opt();
opt();
opt();
opt();
var sFZT = opt();
var mSfN = opt();
var YtaF = opt();
opt();
var xJRm = opt();
var QkyM = opt();
var nbjp = opt();
var JKHH = opt();
opt();
opt();
var feQb = opt();
var jFet = opt();
var JktQ = opt();
var ePiA = opt();
var CPeH = opt();
var CDFR = opt();
XGDp['2'] = -1 == XGDp['2'];
var QYXK = opt();
opt();
opt();
opt();
var hZZd = opt();
var NQPk = opt();
var KJBJ = opt();
var PYsW = opt();
var CbpS = opt();
zPXp['4'] = YrnQ > 4294967295;
var rMz7 = ~0.2;
tmiJ.length = zPXp['1'] <= GejR;
XGDp['4'] = 0 >= XGDp['0'];
opt();
var Ddbz = opt();
opt();
opt();
var wihK = opt();
var tGPJ = opt();
opt();
var GcJx = opt();
var DbEZ = opt();
var mhfK = opt();
var BYpy = opt();
opt();
var ZQNH = opt();
zPXp['0'] = -9007199254740992 <= -9007199254740991;
opt();
opt();
var rCCM = opt();
opt();
var YpND = opt();
var BSCy = opt();
var pWyN = new ArrayBuffer(1.3);
opt();
opt();
var RfeA = opt();
opt();
var HCPh = opt();
opt();
var BphC = opt();
var BMmR = opt();
var mZaz = -2147483649;
XGDp = yQRf.set(jaRK, rMz7);
opt();
opt();
var AwdM = new Set([
    1.7976931348623157e+308,
    0.1,
    1e+400,
    5,
    zPXp['5'],
    GejR,
    rMz7,
    zPXp['5']
]);
var fsmT = opt();
opt();
opt();
var jrac = opt();
var PXih = opt();
var Kfbe = opt();
opt();
var CWjf = opt();
opt();
mZaz = tmiJ.forEach(function () {
}, -4294967295);
var Jxji = opt();
var fwck = opt();
var QySt = opt();
opt();
opt();
opt();
opt();
opt();
opt();
var ytAw = opt();
var zcew = opt();
var nymF = opt();
var KtdA = opt();
opt();
opt();
var RZTw = opt();
XGDp['4'] = XGDp['4'] != 1.7976931348623157e+308;
rMz7 = tmiJ.toLocaleString(-1.7976931348623157e+308, 759250124);
AwdM = jaRK.slice(zPXp['3'], rMz7);
var kRei = opt();
var QzZJ = opt();
XGDp['3'] = 0 > XGDp['3'];
tmiJ = rMz7.valueOf();
var xaZE = opt();
var cSPJ = opt();
XGDp['0'] = zPXp['5'] != NaN;
opt();
var sEEj = opt();
var rFEb = opt();
var Gkhx = opt();
var zKnC = opt();
var SctN = opt();
var CRJr = opt();
opt();
var iGwb = opt();
var kAff = opt();
opt();
opt();
var fmzR = opt();
var TSjw = opt();
opt();
opt();
var AJha = opt();
var NYHp = opt();
opt();
opt();
var Bybe = opt();
var mECh = opt();
var kezk = opt();
var wpKk = opt();
rkWf.length = -2147483648 < APYA['2'];
var fWNm = opt();
opt();
var wsGJ = !3.141592653589793;
var NyrW = new WeakSet([
    [
        GejR,
        -1.7976931348623157e+308,
        9007199254740994,
        AwdM,
        pWyN
    ],
    [
        4294967295,
        APYA['2'],
        tNKy['0'],
        AwdM,
        pWyN,
        3.141592653589793,
        kFxK,
        -4294967295
    ]
]);
opt();
opt();
var SsXY = opt();
var DPRF = opt();
opt();
opt();
opt();
var PnGs = new WeakSet([
    [0],
    [
        2147483648,
        -Infinity,
        -2147483648,
        -9007199254740990,
        9007199254740994,
        153,
        1e+400
    ]
]);
opt();
opt();
var Gkwy = new Uint16Array([
    1.7976931348623157e+308,
    NaN,
    -4294967297,
    10000
]);
pWyN.length = tmiJ > -Infinity;
var ypHa = opt();
var TNQw = opt();
var Sfsw = opt();
var RKdH = opt();
opt();
opt();
var xkMT = opt();
opt();
opt();
opt();
var NrjH = opt();
opt();
opt();
var XbhX = opt();
opt();
opt();
var nzXA = opt();
var mbpm = opt();
var kaZS = opt();
var JCeN = opt();
opt();
var zRjM = opt();
var MTnJ = opt();
opt();
opt();
var SjDk = opt();
var XsMS = opt();
opt();
var fhzZ = opt();
var dkJd = opt();
opt();
opt();
opt();
opt();
opt();
var FWSR = opt();
var Wwhp = opt();
var TkRx = opt();
var FtRA = opt();
opt();
opt();
var zwKp = new WeakSet([
    [
        5,
        -9007199254740991,
        153,
        0.1,
        2147483648,
        -9007199254740991,
        9007199254740994,
        -2147483647,
        0
    ],
    [
        -9007199254740990,
        9007199254740991,
        3,
        673720360,
        -4294967297
    ]
]);
var MNSG = opt();
opt();
var zaFj = opt();
var fTnP = opt();
var eFHT = opt();
var bKpf = opt();
var AiPY = opt();
opt();
XGDp['0'] = zPXp['3'] > zPXp['2'];
opt();
zPXp['4'] = -2147483647 != wsGJ;
var ayDa = opt();
opt();
opt();
opt();
var tmFY = opt();
XGDp['3'] = jaRK < 1.7976931348623157e+308;
opt();
var eKjC = opt();
kFxK = AwdM.slice(tNKy['0'], zPXp['2']);
opt();
opt();
opt();
var ypBw = opt();
opt();
var YZcs = opt();
opt();
opt();
opt();
var EMtJ = opt();
opt();
var fkNd = opt();
opt();
var pwFw = opt();
opt();
var eTDC = opt();
opt();
var HArM = opt();
opt();
var bTDR = opt();
var SeSE = opt();
var mNmb = opt();
zPXp['5'] = 1.3 > mZaz;
opt();
opt();
XGDp['3'] = XGDp < 3.141592653589793;
opt();
opt();
var Pdwj = opt();
opt();
opt();
var BDXe = opt();
var PHiQ = opt();
opt();
opt();
var NPyn = opt();
opt();
var wZjP = opt();
opt();
opt();
var asrJ = opt();
opt();
var RYcG = opt();
var MawY = opt();
pWyN = pWyN.slice(zPXp['3'], zPXp['4']);
opt();
opt();
var BayT = opt();
var Myxf = opt();
var RMac = opt();
var SFmH = opt();
var WYBE = opt();
var FiFj = opt();
var xHww = opt();
var NKkf = opt();
opt();
opt();
var rMNa = opt();
opt();
opt();
opt();
opt();
var spRE = opt();
opt();
var yBPa = +console;
var Rbzc = opt();
opt();
var rQRp = opt();
opt();
var MzzQ = opt();
var cAiS = opt();
opt();
var MBsz = opt();
var PTzN = opt();
opt();
var ZdKP = -1e+400;
opt();
opt();
var FWtw = opt();
var phdt = opt();
var FxcP = opt();
var enbJ = opt();
opt();
var nGfS = +1.3;
var nReW = opt();
var rEcJ = opt();
opt();
opt();
opt();
opt();
var KawZ = opt();
var Jbai = opt();
var DNmf = opt();
opt();
var mCJn = new ArrayBuffer(153);
var pzNc = opt();
var YjTM = -759250124;
function opt() {
}
for (let i = 0; i < 10000; i++) {
    opt();
}