function bar(a, idx) {
    'use strict';
    if (idx > 0)
        throw 'Hello';
    return a;
}
boundBar = bar.bind(null, 42);
boundBar.length = new Map([
    [
        -9007199254740990,
        1200,
        42,
        3.141592653589793
    ],
    [
        console,
        2147483647,
        boundBar.length,
        boundBar.name,
        boundBar.name,
        boundBar.length,
        4294967297,
        9007199254740991,
        console,
        1.7976931348623157e+308,
        1e+81,
        boundBar.name,
        boundBar.name,
        1.7976931348623157e+308,
        42,
        0.2,
        boundBar.name,
        -9007199254740991
    ]
]);
function foo(a, idx) {
    var TnwM = -1e+400;
    return boundBar(idx);
}
boundFoo = foo.bind(null, 41);
try {
    boundFoo(1);
    var itEx = -4294967297;
} catch (e) {
}