function main() {
const v2 = [3254540372];
// v2 = .object(ofGroup: Array, withProperties: ["__proto__", "constructor", "length"], withMethods: ["includes", "fill", "reduceRight", "join", "pop", "reduce", "reverse", "copyWithin", "sort", "some", "indexOf", "every", "flatMap", "filter", "map", "splice", "findIndex", "toString", "keys", "flat", "slice", "toLocaleString", "entries", "concat", "push", "unshift", "forEach", "shift", "find", "values", "lastIndexOf"])
const v5 = [13.37,13.37,13.37,13.37,13.37];
// v5 = .object(ofGroup: Array, withProperties: ["__proto__", "constructor", "length"], withMethods: ["includes", "fill", "reduceRight", "join", "pop", "reduce", "reverse", "copyWithin", "sort", "some", "indexOf", "every", "flatMap", "filter", "map", "splice", "findIndex", "toString", "keys", "flat", "slice", "toLocaleString", "entries", "concat", "push", "unshift", "forEach", "shift", "find", "values", "lastIndexOf"])
const v6 = typeof isNaN;
// v6 = .string
const v8 = v6 === "number";
// v8 = .boolean
const v14 = [13.37,13.37,13.37,13.37,13.37];
// v14 = .object(ofGroup: Array, withProperties: ["__proto__", "constructor", "length"], withMethods: ["includes", "fill", "reduceRight", "join", "pop", "reduce", "reverse", "copyWithin", "sort", "some", "indexOf", "every", "flatMap", "filter", "map", "splice", "findIndex", "toString", "keys", "flat", "slice", "toLocaleString", "entries", "concat", "push", "unshift", "forEach", "shift", "find", "values", "lastIndexOf"])
const v16 = [1337,1337,1337,1337,1337];
// v16 = .object(ofGroup: Array, withProperties: ["__proto__", "constructor", "length"], withMethods: ["includes", "fill", "reduceRight", "join", "pop", "reduce", "reverse", "copyWithin", "sort", "some", "indexOf", "every", "flatMap", "filter", "map", "splice", "findIndex", "toString", "keys", "flat", "slice", "toLocaleString", "entries", "concat", "push", "unshift", "forEach", "shift", "find", "values", "lastIndexOf"])
const v17 = {b:1337,a:v16,valueOf:1337,e:1337,d:Symbol};
// v17 = .object(ofGroup: Object, withProperties: ["a", "b", "valueOf", "__proto__", "e"], withMethods: ["d"])
const v21 = [-2.0,-2.0,-2.0,-2.0,-2.0];
// v21 = .object(ofGroup: Array, withProperties: ["__proto__", "constructor", "length"], withMethods: ["includes", "fill", "reduceRight", "join", "pop", "reduce", "reverse", "copyWithin", "sort", "some", "indexOf", "every", "flatMap", "filter", "map", "splice", "findIndex", "toString", "keys", "flat", "slice", "toLocaleString", "entries", "concat", "push", "unshift", "forEach", "shift", "find", "values", "lastIndexOf"])
const v23 = [1337,1337,1337,1337,1337];
// v23 = .object(ofGroup: Array, withProperties: ["__proto__", "constructor", "length"], withMethods: ["includes", "fill", "reduceRight", "join", "pop", "reduce", "reverse", "copyWithin", "sort", "some", "indexOf", "every", "flatMap", "filter", "map", "splice", "findIndex", "toString", "keys", "flat", "slice", "toLocaleString", "entries", "concat", "push", "unshift", "forEach", "shift", "find", "values", "lastIndexOf"])
const v24 = {e:v23,length:-2.0,d:v23,__proto__:Symbol,valueOf:v21,c:"p76QI.ipnu"};
// v24 = .object(ofGroup: Object, withProperties: ["c", "e", "__proto__", "length", "valueOf", "d"], withMethods: ["__proto__"])
const v26 = [13.37,13.37,13.37,13.37,13.37];
// v26 = .object(ofGroup: Array, withProperties: ["__proto__", "constructor", "length"], withMethods: ["includes", "fill", "reduceRight", "join", "pop", "reduce", "reverse", "copyWithin", "sort", "some", "indexOf", "every", "flatMap", "filter", "map", "splice", "findIndex", "toString", "keys", "flat", "slice", "toLocaleString", "entries", "concat", "push", "unshift", "forEach", "shift", "find", "values", "lastIndexOf"])
const v28 = v14 + v17;
// v28 = .primitive
let v29 = v23;
const v31 = v29 + v26;
// v31 = .primitive
const v32 = {c:v28,__proto__:13.37,length:5,e:1337,...v2,..."string",...v31,...v5,...v24};
// v32 = .object(ofGroup: Object, withProperties: ["d", "e", "length", "valueOf", "__proto__", "c", "constructor"], withMethods: ["entries", "every", "fill", "find", "includes", "reverse", "forEach", "sort", "padEnd", "slice", "repeat", "keys", "splice", "unshift", "findIndex", "endsWith", "shift", "startsWith", "indexOf", "trim", "flatMap", "substring", "pop", "toLocaleString", "map", "reduce", "some", "split", "reduceRight", "__proto__", "copyWithin", "filter", "charCodeAt", "lastIndexOf", "codePointAt", "flat", "replace", "push", "charAt", "concat", "values", "join", "toString", "padStart"])
let v35 = 0;
const v36 = v35 + 1;
// v36 = .primitive
v35 = v36;
}
main();
