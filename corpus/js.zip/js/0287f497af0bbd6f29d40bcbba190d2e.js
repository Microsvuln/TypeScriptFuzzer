function main() {
    const v4 = [
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v6 = [
        1337,
        1337,
        1337,
        1337
    ];
    const v7 = [1337];
    const v8 = { b: v4 };
    const v9 = { c: 'prototype' };
    let v10 = Infinity;
    const v15 = [
        13.37,
        13.37,
        13.37
    ];
    const v17 = [
        1337,
        1337,
        1337,
        1337
    ];
    const v18 = [
        Set,
        Set,
        1337,
        '0MS*nEwLSL'
    ];
    const v19 = {
        e: '0MS*nEwLSL',
        valueOf: v17
    };
    const v20 = {};
    let v21 = 1337;
    const v26 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v28 = [
        1337,
        1337,
        1337,
        1337,
        1337
    ];
    const v29 = [];
    const v30 = {
        e: v28,
        length: 13.37,
        d: v28,
        __proto__: Symbol,
        valueOf: v26,
        c: 'p76QI.ipnu'
    };
    const v31 = {
        b: 1337,
        a: v28,
        valueOf: 1337,
        e: 1337,
        d: Symbol
    };
    let v32 = v29;
    const v33 = v26 % v29;
    const v37 = [];
    let v38 = v37;
    function v39(v40, v41, v42, v43) {
        return v43;
    }
    const v91 = Symbol != 1337;
    const v92 = !10;
    const v93 = typeof v39;
    let v96 = 0;
    while (v96 < 4) {
        const v98 = 'p76QI.ipnu'.constructor;
        for (let v102 = 0; v102 < 10; v102++) {
            for (let v106 = 0; v106 < 5; v106++) {
                const v107 = v28.concat(v106, 0, 'p76QI.ipnu', v102);
            }
        }
        const v109 = Symbol.split;
        const v110 = Symbol[v109];
        const v111 = v96 + 1;
        v96 = v111;
        let v113 = 0;
        const v114 = v15 + 1;
    }
}
main();