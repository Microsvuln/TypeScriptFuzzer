function main() {
    for (let v8 = 0; v8 < 10; v8++) {
        for (let v13 = 0; v13 < 5; v13++) {
        }
        const v14 = Function('p76QI.ipnu');
        const v15 = v14.arguments;
        let v21 = 0;
    }
}
main();