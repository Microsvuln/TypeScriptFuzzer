function main() {
    for (let v7 = 0; v7 < 100; v7++) {
        const v11 = [
            String,
            2241179979
        ];
        let v12 = String;
        let v13 = v7;
        const v14 = v12.fromCharCode(v13, -780083261, String, v7, v11);
        const v15 = [v14];
        const v16 = [v15];
        const v17 = [v16];
        const v20 = new Int8Array('boolean');
        const v23 = {
            __proto__: -1024,
            d: v20
        };
        const v26 = [
            v23,
            v17,
            10000
        ];
        const v27 = {
            toString: v26,
            c: 'constructor'
        };
        const v28 = [v27];
        const v29 = [v28];
        const v30 = [v29];
        const v32 = JSON.stringify(v30, JSON, Int8Array);
        const v33 = RegExp(v32);
        const v34 = String(v33);
        const v35 = eval(v34);
    }
    let v37 = 10;
}
main();