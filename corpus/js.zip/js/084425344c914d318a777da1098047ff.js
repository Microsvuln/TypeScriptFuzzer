function main() {
    const v4 = [
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v6 = [1337];
    const v7 = [
        WeakMap,
        -271918342,
        1337
    ];
    const v8 = {
        c: 'function',
        toString: 'function',
        d: v6,
        constructor: -271918342,
        a: 1337
    };
    const v9 = {
        e: 13.37,
        c: WeakMap,
        __proto__: 1337,
        a: v4,
        b: -271918342,
        d: WeakMap,
        constructor: v8
    };
    let v10 = -271918342;
    const v14 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v15 = [];
    let v16 = v15;
    function v17(v18, v19) {
        for (let v24 = 0; v24 < 1000; v24++) {
            try {
                let v26 = v16;
                v18.b = v24;
                const v27 = 1[v24];
                const v28 = v24[v16];
                const v30 = [
                    524987.369375993,
                    524987.369375993,
                    524987.369375993,
                    v26,
                    524987.369375993
                ];
                let v31 = v24;
                function v32(v33, v34) {
                    let v36 = String;
                    const v37 = v36.fromCharCode(v33, v33, v26, v16, v24);
                    const v38 = Function(v37);
                    return 1000;
                }
                let v39 = v30;
                const v40 = v32(...v39, v31, ...v30, 1337, 524987.369375993);
            } catch (v41) {
                v16 = v24;
            }
        }
        return 1;
    }
    const v42 = [];
    let v43 = v42;
    const v44 = v17(...v43, Uint32Array, ...v14, 10, 13.37);
    const v45 = v4.pop();
    const v46 = v17(WeakMap, 13.37);
}
main();