var __instance = new String('one');
__instance.concat('two');
if (__instance != 'one') {
    $ERROR('#1: __instance = new String("one"); __instance.concat("two");  __instance = new String("one"); __instance.concat("two"); __instance == "one". Actual: ' + __instance);
}