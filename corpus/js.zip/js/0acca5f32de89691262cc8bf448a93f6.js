function main() {
    const v2 = 'OQc32+vRhR'['function'];
    const v7 = [
        String,
        2241179979
    ];
    let v8 = String;
    const v11 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    let v13 = undefined;
    const v14 = v8.fromCharCode(v13, v11, String, 1.7976931348623157e+308, v7);
    const v15 = [v14];
    const v16 = [v15];
    const v17 = [v16];
    const v19 = JSON.stringify(v17, JSON, v16);
    const v20 = [1337];
    function v21(v22, v23) {
    }
    let v25 = v21;
    v25 = v19;
    const v28 = new Int8Array('boolean');
    const v29 = v25 + 1;
    v28[Uint16Array] = v29;
    const v31 = {
        __proto__: -1024,
        d: v28
    };
    const v34 = [
        v31,
        v20,
        1337
    ];
    const v35 = {
        toString: v34,
        c: 'constructor'
    };
    const v36 = [v35];
    const v37 = [v36];
    const v38 = [v37];
    const v40 = JSON.stringify(v38, JSON, v37);
    const v41 = JSON.parse(v40, String);
}
main();