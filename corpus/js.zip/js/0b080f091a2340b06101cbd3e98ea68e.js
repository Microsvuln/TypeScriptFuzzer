function main() {
    let arr = [
        1.1,
        1.1,
        1.1,
        1.1,
        1.1
    ];
    var YTFz = new Map([
        [
            -1,
            -4294967297,
            arr,
            arr
        ],
        [arr]
    ]);
    var WBGG = arr.toString(YTFz, 4, 9007199254740992);
    var HPQz = new WeakSet([
        [],
        []
    ]);
    var yKHD = arr.toString(-Infinity, 1e+81, YTFz);
    var KWQt = new Set([
        arr.length,
        arr,
        arr.length,
        arr.length,
        arr.length,
        5e-324
    ]);
    var twQF = new WeakSet([
        [
            arr.length,
            -4294967297,
            1200,
            arr.length,
            arr,
            0,
            1e+81,
            3037000498,
            1.7976931348623157e+308
        ],
        [
            arr.length,
            153
        ]
    ]);
    arr = twQF.delete(1518500249);
    var xsmy = twQF < arr.length;
    opt(function () {
    });
    var wMzH = new Map([
        [],
        [
            9007199254740990,
            arr,
            arr.length,
            arr
        ]
    ]);
    var mQJa = new Float64Array([
        -5e-324,
        -1.7976931348623157e+308,
        4294967295,
        arr,
        1e+400,
        1.3,
        0,
        arr.length
    ]);
    var YTwN = new Int8Array([
        1e+400,
        0,
        0,
        1.7976931348623157e+308,
        2147483649,
        arr.length
    ]);
    var kBAh = new Map([
        [
            arr.length,
            10000,
            -Infinity
        ],
        [
            -1,
            arr.length,
            9007199254740990,
            1e+81,
            1e-81
        ]
    ]);
    var nHCK = new Uint8Array([
        arr.length,
        673720360,
        0.2
    ]);
    var XTJk = new WeakSet([
        [
            arr.length,
            3,
            1.7976931348623157e+308
        ],
        []
    ]);
    function opt(f) {
        arr[0] = 1.1;
        var K2sQ = ~-9007199254740991;
        var CbWF = !0;
        arr[2] = 1.1;
        var bHeM = !2147483648;
        arr[3] = 1.1;
    }
    let r0 = () => '0';
    for (var i = 0; i < 4096; i++)
        opt(r0);
    opt(() => {
        arr[0] = {};
        return '0';
    });
}
main();