function main() {
    try {
        const v2 = [
            13.37,
            13.37,
            13.37,
            13.37,
            13.37
        ];
        const v3 = [];
        let v4 = v3;
        function v5(v6, v7) {
            const v10 = new Int8Array(39929);
            v2.toString = v5;
            const v13 = [
                -2.2250738585072014e-308,
                -2.2250738585072014e-308,
                -2.2250738585072014e-308,
                -2.2250738585072014e-308,
                -2.2250738585072014e-308
            ];
            const v14 = [];
            let v15 = v14;
            function v16(v17, v18) {
                const v20 = 0 - v2;
            }
            const v21 = [];
            let v22 = v21;
            const v23 = v16(...v22, v15, ...v13, 10, -2.2250738585072014e-308);
        }
        const v24 = [];
        let v25 = v24;
        const v26 = v5(...v25, v4, ...v2, 13.37, 13.37);
    } catch (v27) {
    }
    const v31 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v33 = [
        1337,
        1337,
        1337,
        1337,
        1337
    ];
    const v34 = {
        e: v33,
        length: 13.37,
        d: v33,
        __proto__: Symbol,
        valueOf: v31,
        c: 'p76QI.ipnu'
    };
    const v42 = [
        1337,
        WeakMap
    ];
    let v43 = v42;
    const v45 = arguments[4096];
    try {
        const v48 = [
            13.37,
            13.37,
            13.37,
            13.37,
            13.37
        ];
        const v49 = [];
        let v50 = v49;
        function v51(v52, v53) {
            const v54 = {
                getOwnPropertyDescriptor: v45,
                defineProperty: v52,
                getPrototypeOf: v52,
                construct: v51,
                set: v51,
                call: v45
            };
            const v56 = new Proxy(arguments, v54);
            let v60 = 1337;
            const v61 = JSON.stringify(v60, Object, v60);
            v56[1624031861] = v45;
        }
        const v62 = [];
        let v63 = v62;
        const v64 = v51(...v63, v50, ...v48, 1337, 13.37);
    } catch (v65) {
    }
}
main();