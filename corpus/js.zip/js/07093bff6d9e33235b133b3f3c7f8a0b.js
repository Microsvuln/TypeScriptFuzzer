var sContent = '';
for (var i = 1; i <= 1200; i++) {
    sContent += '<div style="display: inline-block; text-align: center; color: white; width: 50px; height: 30px; background-color:rgb(' + Math.round(Math.random() * 100) + ',' + Math.round(Math.random() * 100) + ',' + Math.round(Math.random() * 100) + ');" id="div-' + i + '">' + i + '</div>';
    if (i % 20 == 0) {
        sContent += '<br>';
    }
}