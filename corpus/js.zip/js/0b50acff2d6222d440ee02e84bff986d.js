function main() {
    try {
        const v6 = [
            13.37,
            13.37,
            13.37,
            13.37,
            13.37
        ];
        const v7 = [];
        let v9 = 0;
        let v10 = v7;
        function v11(v12, v13) {
            const v15 = [
                13.37,
                13.37,
                13.37,
                13.37,
                13.37
            ];
            const v18 = [
                1337,
                1337,
                1337,
                1337,
                1337
            ];
            const v19 = {
                b: 1337,
                a: v18,
                valueOf: 1337,
                e: 1337,
                d: Symbol
            };
            const v20 = [
                v13,
                v13
            ];
            function v21(v22, v23, v24, v25) {
            }
            v6.toString = v11;
            const v29 = [
                13.37,
                -3364666357,
                1337,
                13.37
            ];
            let v32 = 0;
            function v33(v34, v35) {
                let v40 = 0;
            }
            const v42 = v32 + 1;
            v32 = v42;
            const v45 = [
                13.37,
                13.37,
                13.37,
                13.37,
                13.37
            ];
            const v46 = [];
            let v47 = v46;
            let v49 = 0;
            const v53 = [
                13.37,
                13.37,
                13.37,
                13.37,
                13.37
            ];
            const v54 = v53.constructor;
            const v56 = [
                13.37,
                13.37,
                13.37,
                13.37,
                13.37
            ];
            const v59 = [
                1337,
                1337,
                1337,
                1337,
                1337
            ];
            const v60 = {
                b: 1337,
                a: v59,
                valueOf: 1337,
                e: 1337,
                d: Symbol
            };
            const v61 = v54.bind(v60, Symbol, v56);
            let v62 = 1;
            const v63 = new v61(13.37, v62);
            const v64 = v19 | v9;
            const v65 = v49 + 1;
            let v66 = v10;
            function v67(v68, v69) {
                const v71 = 0 - v6;
                let v74 = 0;
                do {
                } while (v74 < Symbol);
                let v76 = 0;
            }
            const v77 = [];
            let v78 = v77;
            const v79 = v67(...v78, v47, ...v45, 10, 13.37);
        }
        const v80 = [];
        let v81 = v80;
        const v82 = v11(...v81, v10, ...v6, 1337, 13.37);
    } catch (v83) {
    }
}
main();