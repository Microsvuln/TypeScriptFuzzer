function main() {
    const v4 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v5 = [];
    let v6 = v5;
    function v7(v8, v9) {
        for (let v13 = 0; v13 <= 65535; v13 = v13 + 4292765331) {
            try {
                Symbol.toString = Symbol;
                let v15 = Float64Array;
                v15 = Symbol;
                const v16 = v15 + 1;
            } catch (v17) {
            }
            const v21 = [
                2322280097,
                v9
            ];
            const v22 = {
                length: 'undefined',
                c: v21,
                __proto__: v21
            };
            const v24 = [
                1553479343,
                1553479343,
                1553479343,
                1553479343
            ];
            let v25 = v24;
            const v29 = [
                Infinity,
                Infinity,
                Infinity,
                Infinity,
                Infinity
            ];
            const v31 = [
                1337,
                v22
            ];
            const v32 = [1337];
            const v33 = {
                e: 1337,
                __proto__: v31,
                valueOf: Proxy,
                d: -441746.4139016614
            };
            const v35 = v29.toLocaleString(128, 128, v33, v31, v32);
            const v36 = v25.join(v35);
            function v37(v38, v39) {
                for (const v42 of v38) {
                    const v43 = 13.37.isFrozen(v42, v36, 128, 1000);
                }
            }
            const v44 = 0 - v13;
            for (let v48 = -65537; v48 < 8; v48++) {
            }
        }
    }
    const v49 = [];
    let v50 = v49;
    const v51 = v7(...v50, v6, ...v4, 2670544995, 13.37);
    const v52 = v7(13.37);
}
main();