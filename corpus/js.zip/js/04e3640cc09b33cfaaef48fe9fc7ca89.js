(function (exports) {
    'use strict';
    function async(func, self) {
        return function asyncFunction() {
            const functionArgs = Array.from(arguments);
            return new Promise(function (resolve, reject) {
                var gen;
                if (typeof func !== 'function') {
                    reject(new TypeError('Expected a Function.'));
                }
                if (func.constructor.name !== 'GeneratorFunction') {
                    gen = function* () {
                        return func.apply(self, functionArgs);
                    }();
                } else {
                    gen = func.apply(self, functionArgs);
                }
                try {
                    step(gen.next(undefined));
                } catch (err) {
                    reject(err);
                }
                function step({value, done}) {
                    if (done) {
                        return resolve(value);
                    }
                    if (value instanceof Promise) {
                        return value.then(result => step(gen.next(result)), error => {
                            try {
                                step(gen.throw(error));
                            } catch (err) {
                                throw err;
                            }
                        }).catch(err => reject(err));
                    }
                    return step(gen.next(value));
                }
            });
        };
    }
    exports.async = async;
}(this || self));