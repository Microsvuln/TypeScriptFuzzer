function main() {
    const v3 = [
        String,
        2241179979
    ];
    let v4 = String;
    const v7 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    let v8 = 13.37;
    const v9 = v4.fromCharCode(v8, v7, String, -478219.26062490314, v3);
    const v10 = [v9];
    const v11 = [v10];
    const v12 = [v11];
    const v15 = new Int8Array('boolean');
    const v17 = {
        __proto__: -1024,
        d: v15
    };
    const v20 = [
        v17,
        v12,
        1337
    ];
    const v21 = {
        toString: v20,
        c: 'constructor'
    };
    v21[v15] = v3;
    const v22 = [v21];
    const v23 = [v22];
    const v24 = [v23];
    const v26 = JSON.stringify(v24, JSON, v23);
    const v27 = JSON.parse(v26, String);
}
main();