function main() {
    const v2 = [13.37];
    const v4 = new Int8Array(Symbol);
    delete v4[v2];
}
main();