function main() {
    let v2 = 0;
    while (v2 < 10) {
        function v3(v4, v5, v6, v7, ...v8) {
            for (const v11 in 'caller') {
            }
            const v12 = Math.ceil(v8);
        }
        const v13 = v3();
        const v14 = v2 + 1;
        v2 = v14;
    }
}
main();