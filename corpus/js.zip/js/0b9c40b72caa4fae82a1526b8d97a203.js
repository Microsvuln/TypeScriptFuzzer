function main() {
    const v2 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v3 = [];
    let v4 = v3;
    function v5(v6, v7) {
        let v10 = 0;
        while (v10 < 10) {
            for (let v14 = 0; v14 < 8; v14++) {
                for (let v18 = 0; v18 < 5; v18++) {
                    const v22 = new Uint8Array(33350);
                    const v24 = new Uint8Array('p76QI.ipnu');
                    const v25 = v24 << 13.37;
                }
            }
            const v26 = v10 + 1;
            v10 = v26;
        }
    }
    const v27 = [];
    let v28 = v27;
    const v29 = v5(...v28, v4, ...v2, 10, 13.37);
}
main();