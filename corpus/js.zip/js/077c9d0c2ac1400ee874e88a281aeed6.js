var PI = 3.141592653589793;
var SOLAR_MASS = 4 * PI * PI;
var DAYS_PER_YEAR = 365.24;
function Body(x, y, z, vx, vy, vz, mass, buffer, bodyIndex) {
    this.storage_ = new Float64Array(buffer, bodyIndex * Body.BYTES_SIZE, Body.NUM_FIELDS);
    this.storage_[Body.X] = x;
    this.storage_[Body.Y] = y;
    this.storage_[Body.Z] = z;
    this.storage_[Body.VX] = vx;
    this.storage_[Body.VY] = vy;
    this.storage_[Body.VZ] = vz;
    this.storage_[Body.MASS] = mass;
}
Body.NUM_FIELDS = 7;
Body.BYTES_SIZE = Body.NUM_FIELDS * 8;
Body.X = 0;
Body.Y = 1;
Body.Z = 2;
Body.VX = 3;
Body.VY = 4;
Body.VZ = 5;
Body.MASS = 6;
Body.prototype.offsetMomentum = function (px, py, pz) {
    this.storage_[Body.VX] = -px / SOLAR_MASS;
    this.storage_[Body.VY] = -py / SOLAR_MASS;
    this.storage_[Body.VZ] = -pz / SOLAR_MASS;
};
function Jupiter(buffer, bodyIndex) {
    return new Body(4.841431442464721, -1.1603200440274284, -0.10362204447112311, 0.001660076642744037 * DAYS_PER_YEAR, 0.007699011184197404 * DAYS_PER_YEAR, -0.0000690460016972063 * DAYS_PER_YEAR, 0.0009547919384243266 * SOLAR_MASS, buffer, bodyIndex);
}
function Saturn(buffer, bodyIndex) {
    return new Body(8.34336671824458, 4.124798564124305, -0.4035234171143214, -0.002767425107268624 * DAYS_PER_YEAR, 0.004998528012349172 * DAYS_PER_YEAR, 0.000023041729757376393 * DAYS_PER_YEAR, 0.0002858859806661308 * SOLAR_MASS, buffer, bodyIndex);
}
function Uranus(buffer, bodyIndex) {
    return new Body(12.894369562139131, -15.111151401698631, -0.22330757889265573, 0.002964601375647616 * DAYS_PER_YEAR, 0.0023784717395948095 * DAYS_PER_YEAR, -0.000029658956854023756 * DAYS_PER_YEAR, 0.00004366244043351563 * SOLAR_MASS, buffer, bodyIndex);
}
function Neptune(buffer, bodyIndex) {
    return new Body(15.379697114850917, -25.919314609987964, 0.17925877295037118, 0.0026806777249038932 * DAYS_PER_YEAR, 0.001628241700382423 * DAYS_PER_YEAR, -0.00009515922545197159 * DAYS_PER_YEAR, 0.000051513890204661145 * SOLAR_MASS, buffer, bodyIndex);
}
function Sun(buffer, bodyIndex) {
    return new Body(0, 0, 0, 0, 0, 0, SOLAR_MASS, buffer, bodyIndex);
}
function NBodySystem(bodies) {
    this.bodies = bodies;
    var px = 0;
    var py = 0;
    var pz = 0;
    var size = this.bodies.length;
    for (var i = 0; i < size; i++) {
        var b = this.bodies[i];
        var m = b.storage_[Body.MASS];
        px += b.storage_[Body.VX] * m;
        py += b.storage_[Body.VY] * m;
        pz += b.storage_[Body.VZ] * m;
    }
    this.bodies[0].offsetMomentum(px, py, pz);
}
NBodySystem.prototype.advance = function (dt) {
    var dx, dy, dz, distance, mag;
    var size = this.bodies.length;
    for (var i = 0; i < size; i++) {
        var bodyi = this.bodies[i];
        var imass = bodyi.storage_[Body.MASS];
        for (var j = i + 1; j < size; j++) {
            var bodyj = this.bodies[j];
            var jmass = bodyj.storage_[Body.MASS];
            dx = bodyi.storage_[Body.X] - bodyj.storage_[Body.X];
            dy = bodyi.storage_[Body.Y] - bodyj.storage_[Body.Y];
            dz = bodyi.storage_[Body.Z] - bodyj.storage_[Body.Z];
            distance = Math.sqrt(dx * dx + dy * dy + dz * dz);
            mag = dt / (distance * distance * distance);
            bodyi.storage_[Body.VX] -= dx * jmass * mag;
            bodyi.storage_[Body.VY] -= dy * jmass * mag;
            bodyi.storage_[Body.VZ] -= dz * jmass * mag;
            bodyj.storage_[Body.VX] += dx * imass * mag;
            bodyj.storage_[Body.VY] += dy * imass * mag;
            bodyj.storage_[Body.VZ] += dz * imass * mag;
        }
        bodyi.storage_[Body.X] += dt * bodyi.storage_[Body.VX];
        bodyi.storage_[Body.Y] += dt * bodyi.storage_[Body.VY];
        bodyi.storage_[Body.Z] += dt * bodyi.storage_[Body.VZ];
    }
};
NBodySystem.prototype.energy = function () {
    var dx, dy, dz, distance;
    var e = 0;
    var size = this.bodies.length;
    for (var i = 0; i < size; i++) {
        var bodyi = this.bodies[i];
        e += 0.5 * bodyi.storage_[Body.MASS] * (bodyi.storage_[Body.VX] * bodyi.storage_[Body.VX] + bodyi.storage_[Body.VY] * bodyi.storage_[Body.VY] + bodyi.storage_[Body.VZ] * bodyi.storage_[Body.VZ]);
        for (var j = i + 1; j < size; j++) {
            var bodyj = this.bodies[j];
            dx = bodyi.storage_[Body.X] - bodyj.storage_[Body.X];
            dy = bodyi.storage_[Body.Y] - bodyj.storage_[Body.Y];
            dz = bodyi.storage_[Body.Z] - bodyj.storage_[Body.Z];
            distance = Math.sqrt(dx * dx + dy * dy + dz * dz);
            e -= bodyi.storage_[Body.MASS] * bodyj.storage_[Body.MASS] / distance;
        }
    }
    return e;
};
n = 500;
runTest = function (n) {
    var bodyBuffer = new ArrayBuffer(Body.BYTES_SIZE * 5);
    var bodies = new NBodySystem(Array(Sun(bodyBuffer, 0), Jupiter(bodyBuffer, 1), Saturn(bodyBuffer, 2), Uranus(bodyBuffer, 3), Neptune(bodyBuffer, 4)));
    console.log(bodies.energy().toFixed(9));
    for (var i = 0; i < n; i++) {
        bodies.advance(0.01);
    }
    console.log(bodies.energy().toFixed(9));
};
var time = +new Date();
runTest(n);
console.log(+new Date() - time + 'ms');