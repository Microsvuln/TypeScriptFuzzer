function main() {
    for (const v3 of 'split') {
        for (const v4 in v3) {
        }
    }
}
main();