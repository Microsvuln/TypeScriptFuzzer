function main() {
    const v4 = [
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v6 = [
        1337,
        1337,
        1337,
        1337,
        1337
    ];
    const v7 = [v6];
    const v8 = {
        d: v7,
        e: v7,
        toString: 'i3t8wlzQgT',
        __proto__: Reflect,
        c: 'i3t8wlzQgT'
    };
    const v9 = {
        c: v4,
        e: -4294967295
    };
    let v10 = 1337;
    const v13 = 'symbol'.charCodeAt(v10);
    const v14 = [
        v9,
        v7
    ];
    const v17 = [
        13.37,
        13.37
    ];
    const v19 = [1337];
    const v20 = [
        13.37,
        v19,
        1337,
        'symbol'
    ];
    const v21 = { __proto__: 1337 };
    const v22 = {
        e: v20,
        length: v19
    };
    let v23 = Object;
    const v28 = [
        0,
        0
    ];
    const v30 = [
        1337,
        1337
    ];
    const v31 = [
        0,
        NaN,
        1
    ];
    const v32 = {
        length: 'number',
        constructor: 0,
        e: v28,
        b: v30,
        valueOf: v30,
        a: 'number'
    };
    const v33 = {
        toString: 1,
        constructor: 'number'
    };
    let v34 = NaN;
    for (let v41 = 0; v41 < 127; v41++) {
        for (let v43 = -2; v43 < 100; v43 = v43 + 9) {
            try {
                let v45 = String;
                const v46 = v45.fromCharCode(100, v41, 100, v43, v43);
                const v47 = Function(v46);
                let v51 = 0;
                while (v51 < 5) {
                    const v52 = v51 + 1;
                    v51 = v52;
                }
                const v53 = v45(String);
                v47[v22] = v45;
                const v54 = Symbol.toStringTag;
                const v55 = 100 - v28;
                const v56 = v47(v30, v14, v47, v41, Function);
                const v57 = Symbol.keyFor(v8);
                v7[Symbol] = 100;
                const v58 = 'i3t8wlzQgT'[v54];
                v34 = v43;
                for (let v62 = 0; v62 < 100; v62++) {
                    const v63 = Object(String, v41, -4294967295);
                }
            } catch (v64) {
            }
        }
    }
    const v65 = {
        __proto__: v33,
        d: v34,
        a: Function,
        valueOf: v7
    };
    v23 = v19;
    const v66 = Object(Object, 'i3t8wlzQgT', Reflect, 'i3t8wlzQgT');
}
main();