try {
    __instance = Math;
    __instance.test = RegExp.prototype.test;
    try {
        with (__instance)
            test('message to investigate');
        testFailed('#1.1: __instance = Math; __instance.test = RegExp.prototype.test;  with(__instance) test("message to investigate")');
    } catch (e) {
        if (e instanceof TypeError !== true) {
            testFailed('#1.2: __instance = Math; __instance.test = RegExp.prototype.test;  with(__instance) test("message to investigate"). Actual: ' + e);
        }
    }
} catch (ex) {
    sputnikException = ex;
}
var successfullyParsed = true;