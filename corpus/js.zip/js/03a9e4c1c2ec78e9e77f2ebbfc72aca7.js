var string = '';
for (i = 0; i < 1000; ++i)
    string += '[[**]]';
while (string.length < 8192) {
    string += '[[**]]';
    new RegExp(string);
}