function main() {
    const v1 = [
        13.37,
        13.37,
        13.37
    ];
    const v4 = [
        -441746.4139016614,
        -441746.4139016614,
        -441746.4139016614,
        -441746.4139016614,
        -441746.4139016614
    ];
    const v5 = [];
    let v6 = v5;
    function v7(v8, v9) {
        const v12 = [
            13.37,
            13.37,
            13.37,
            13.37,
            13.37
        ];
        const v13 = [];
        let v14 = v13;
        function v15(v16, v17) {
            const v19 = [
                -441746.4139016614,
                -441746.4139016614,
                -441746.4139016614,
                -441746.4139016614,
                -441746.4139016614
            ];
            const v20 = [];
            let v21 = v20;
            function v22(v23, v24) {
                const v26 = [
                    1337,
                    1337
                ];
                const v29 = [
                    13.37,
                    13.37,
                    13.37,
                    13.37,
                    13.37
                ];
                const v30 = [];
                let v31 = v4;
                function v32(v33, v34) {
                    const v37 = [
                        -441746.4139016614,
                        -441746.4139016614,
                        -441746.4139016614,
                        -441746.4139016614,
                        -441746.4139016614
                    ];
                    const v38 = [];
                    let v39 = v38;
                    function v40(v41, v42) {
                        const v44 = [
                            13.37,
                            13.37
                        ];
                        const v47 = [arguments];
                        const v48 = [v47];
                        const v49 = [13.37];
                        const v51 = JSON.stringify(v49, JSON, v48);
                        const v53 = [
                            -441746.4139016614,
                            -441746.4139016614,
                            -441746.4139016614,
                            -441746.4139016614,
                            -441746.4139016614
                        ];
                        let v54 = v49;
                        function v55(v56, v57) {
                            for (let v62 = 0; v62 < 100; v62++) {
                                try {
                                    const v65 = [
                                        -441746.4139016614,
                                        -441746.4139016614,
                                        v49,
                                        -441746.4139016614,
                                        -441746.4139016614
                                    ];
                                    const v66 = [];
                                    let v67 = v66;
                                    function v68(v69, v70) {
                                        for (const v72 in v44) {
                                        }
                                        const v74 = [
                                            v51,
                                            129,
                                            981509.8915850616
                                        ];
                                        const v75 = v62.toLocaleString();
                                        const v76 = v74.join('b');
                                        const v77 = v76.padStart(v75, v68);
                                        const v78 = eval(v77);
                                    }
                                    const v79 = [];
                                    let v80 = v79;
                                    const v81 = v68(...v80, ...v67, v65, 129, -441746.4139016614);
                                } catch (v82) {
                                }
                            }
                        }
                        const v83 = [];
                        let v84 = v83;
                        const v85 = v55(...v84, ...v54, ...v53, 13.37, -441746.4139016614);
                    }
                    const v88 = [
                        String,
                        6
                    ];
                    let v89 = String;
                    const v92 = [
                        13.37,
                        13.37,
                        13.37,
                        13.37,
                        13.37
                    ];
                    let v93 = String;
                    const v94 = v89.fromCharCode(v93, v92, String, -927003.0619944772, v88);
                    const v98 = JSON.stringify(v94, JSON, 'boolean');
                    const v99 = Array(v98);
                    const v100 = String(v99);
                    const v101 = [];
                    let v102 = v101;
                    const v103 = v40(...v102, ...v39, ...v37, 1337, -441746.4139016614);
                    const v106 = v32.toLocaleString();
                    const v107 = v106.replace(13.37, v100);
                    const v108 = eval(v107);
                    return v32;
                }
                let v109 = v26;
                const v110 = v32(...v109, v31, ...v29, 10, 13.37);
                const v111 = v26.reduce(v110, v30);
            }
            const v112 = [];
            let v113 = v112;
            const v114 = v22(...v113, ...v21, ...v19, v1, -441746.4139016614);
        }
        const v115 = [];
        let v116 = v115;
        const v117 = v15(...v116, v14, ...v12, 10, 13.37);
    }
    const v118 = [];
    let v119 = v118;
    const v120 = v7(...v119, v6, ...v4, 1337, -441746.4139016614);
}
main();