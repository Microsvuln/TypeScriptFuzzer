try {
    function __func() {
        is_undef = true;
        for (i = 0; i < arguments.length; i++) {
            delete arguments[i];
            __func(1e+81, -1.7976931348623157e+308, 1518500249, 1518500249);
            __func(-9007199254740994, 4294967297, 1.7976931348623157e+308, 1518500249);
            is_undef = is_undef && typeof arguments[i] === 'undefined';
            __func(1e-81, -Infinity, 9007199254740994, 1e-81);
            __func(4, -2147483649, -1, 1.7976931348623157e+308);
        }
        ;
        return is_undef;
    }
    ;
    if (!__func('A', 'B', 1, 2)) {
        __func(759250124, 2147483648, 5, 4294967295);
    }
} catch (ex) {
    sputnikException = ex;
}
var successfullyParsed = true;