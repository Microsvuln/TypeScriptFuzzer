function main() {
    let v2 = 0;
    while (v2 < 10) {
        const v3 = [];
        let v4 = v3;
        const v7 = new WeakSet(v4);
        const v9 = [
            13.37,
            13.37,
            13.37,
            13.37,
            13.37
        ];
        const v10 = [];
        let v11 = v10;
        function v12(v13, v14) {
            let v17 = 0;
            while (v17 < 10) {
                const v20 = [
                    13.37,
                    13.37,
                    13.37,
                    13.37,
                    13.37
                ];
                let v21 = 0;
                const v22 = v21 + 1;
                const v23 = v7.add(v20);
                v21 = v22;
                const v24 = v17 + 1;
                v17 = v24;
                for (let v28 = 0; v28 < 100; v28++) {
                    const v32 = 1337[eval];
                    let v34 = 0;
                }
            }
        }
        const v35 = [];
        let v36 = v35;
        const v37 = v12(...v36, v11, ...v9, 10, 13.37);
        const v38 = v2 + 1;
        v2 = v38;
    }
}
main();