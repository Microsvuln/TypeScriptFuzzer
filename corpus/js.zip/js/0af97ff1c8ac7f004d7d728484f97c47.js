function main() {
    const v8 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v9 = [];
    let v10 = v9;
    function v11(v12, v13) {
        let v16 = 0;
        while (v16 < 10) {
            const v23 = [];
            const v26 = new Int8Array(1630);
            const v28 = v26.filter(Array, v23);
            const v29 = v16 + 1;
            v16 = v29;
        }
    }
    const v30 = [];
    let v31 = v30;
    const v32 = v11(...v31, v10, ...v8, 10, 13.37);
}
main();