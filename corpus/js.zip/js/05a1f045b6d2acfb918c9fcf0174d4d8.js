function main() {
    const v4 = parseInt(10, parseInt);
    const v5 = { isExtensible: parseInt };
    const v7 = parseInt(13.37, -907032862, v5, 'object', 13.37);
}
main();