function main() {
    for (let v3 = 0; v3 < 100; v3++) {
        const v7 = { __proto__: 3245932418 };
        const v8 = {
            valueOf: 'size',
            b: eval,
            constructor: v7,
            toString: 3245932418,
            d: eval
        };
        let v9 = v8;
        const v12 = [
            13.37,
            13.37,
            13.37,
            v9,
            13.37
        ];
        let v13 = eval;
        function v14(v15, v16) {
            try {
                const v21 = [
                    9,
                    9
                ];
                let v22 = String;
                const v24 = v22.fromCharCode(100, v3, 13.37, 10, v21);
                const v25 = eval(v24);
            } catch (v26) {
            }
        }
        const v27 = [];
        let v28 = v27;
        const v29 = v14(...v28, v13, ...v12, 65537, 13.37);
    }
}
main();