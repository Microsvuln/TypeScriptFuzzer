function main() {
    try {
        const v2 = [
            13.37,
            13.37,
            13.37,
            13.37,
            13.37
        ];
        const v3 = [];
        let v4 = v3;
        function v5(v6, v7) {
            const v10 = RegExp(10152);
            const v11 = v10.__proto__;
            const v12 = new RegExp(v11);
            v2.toString = v5;
            const v15 = [
                633479.8443053172,
                633479.8443053172,
                633479.8443053172,
                633479.8443053172,
                633479.8443053172
            ];
            const v16 = [];
            let v17 = v16;
            function v18(v19, v20) {
                const v23 = [13.37];
                const v24 = -9007199254740991 << v2;
                return v3;
            }
            const v25 = [];
            const v29 = [
                13.37,
                13.37,
                13.37,
                13.37,
                13.37
            ];
            const v30 = {
                has: Symbol,
                deleteProperty: Symbol,
                apply: Symbol,
                setPrototypeOf: Symbol,
                defineProperty: Symbol,
                getOwnPropertyDescriptor: Symbol,
                ownKeys: Symbol
            };
            const v35 = {
                get: Object,
                construct: Array,
                call: Object
            };
            const v37 = new Proxy(gc, v35);
            const v38 = Object.seal(v37);
            const v40 = new Proxy(v29, v30);
            const v41 = isFinite(...v40);
            let v42 = v25;
            const v43 = v18(...v42, v17, ...v15, 10, 633479.8443053172);
        }
        const v44 = [];
        let v45 = v44;
        const v46 = v5(...v45, v4, ...v2, -2147483649, 13.37);
    } catch (v47) {
    }
}
main();