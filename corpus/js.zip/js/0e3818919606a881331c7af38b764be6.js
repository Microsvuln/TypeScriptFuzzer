function main() {
    function v0(v1, v2) {
    }
    let v4 = v0;
    const v7 = new Int8Array('boolean');
    const v9 = v4 + 1;
    v7[Uint16Array] = v9;
    const v11 = {
        __proto__: -1225146152,
        d: v7
    };
    const v14 = [
        v11,
        65536,
        65536
    ];
    const v15 = {
        toString: v14,
        c: 'symbol'
    };
    const v16 = [v15];
    const v17 = [v16];
    const v18 = [v17];
    v17.length = 65536;
    const v20 = JSON.stringify(v18, JSON, v17);
    const v21 = eval(v20);
}
main();