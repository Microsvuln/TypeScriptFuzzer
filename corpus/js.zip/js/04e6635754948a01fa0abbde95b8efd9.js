function getData() {
    return {
        '1st Floor': {
            color: 'blue',
            points: [
                366,
                298,
                500,
                284,
                499,
                204,
                352,
                183,
                72,
                228,
                74,
                274
            ]
        },
        '2nd Floor': {
            color: 'red',
            points: [
                72,
                228,
                73,
                193,
                340,
                96,
                498,
                154,
                498,
                191,
                341,
                171
            ]
        },
        '3rd Floor': {
            color: 'yellow',
            points: [
                73,
                192,
                73,
                160,
                340,
                23,
                500,
                109,
                499,
                139,
                342,
                93
            ]
        },
        'Gym': {
            color: 'green',
            points: [
                498,
                283,
                503,
                146,
                560,
                136,
                576,
                144,
                576,
                278,
                500,
                283
            ]
        }
    };
}
function updateTooltip(tooltip, x, y, text) {
    tooltip.getText().setText(text);
    tooltip.setPosition({
        x: x,
        y: y
    });
    tooltip.show();
}
var areas = getData();
for (var key in areas) {
    var area = areas[key];
    var points = area.points;
}