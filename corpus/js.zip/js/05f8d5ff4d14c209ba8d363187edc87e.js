function main() {
    const v2 = [];
    const v3 = {
        __proto__: 4,
        d: 13.37,
        constructor: v2
    };
    for (let v7 = 0; v7 < 100; v7++) {
        const v11 = new Float64Array(30420);
        const v12 = v11.subarray(-1668538728);
        const v15 = [
            13.37,
            13.37,
            13.37,
            13.37,
            13.37
        ];
        const v16 = [];
        let v17 = v16;
        function v18(v19, v20) {
            let v23 = 0;
            while (v23 < 10) {
                const v26 = [
                    1337,
                    1337
                ];
                const v27 = {
                    __proto__: v26,
                    c: 1337,
                    e: 5,
                    valueOf: 5,
                    b: 5
                };
                const v29 = [];
                const v30 = new Map(v29);
                const v31 = v23 + 1;
                v23 = v31;
            }
        }
        const v32 = [];
        let v33 = v32;
        const v34 = v18(...v33, v17, ...v15, 10, 13.37);
    }
}
main();