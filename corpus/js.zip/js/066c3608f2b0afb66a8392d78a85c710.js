function main() {
    for (let v5 = 0; v5 < 100; v5++) {
        const v8 = [
            -441746.4139016614,
            100,
            -441746.4139016614,
            -441746.4139016614,
            -441746.4139016614
        ];
        const v9 = [];
        let v10 = v9;
        function v11(v12, v13) {
            const v16 = [
                981509.8915850616,
                1,
                981509.8915850616
            ];
            const v17 = v5.toLocaleString();
            const v18 = v16.join(1799239593);
            const v19 = v18.lastIndexOf(v17, v18);
        }
        const v20 = [];
        let v21 = v20;
        const v22 = v11(...v21, v10, ...v8, 1337, -441746.4139016614);
    }
    const v25 = [
        13.37,
        13.37,
        13.37
    ];
    const v27 = [
        1337,
        1337,
        1337,
        1337,
        1337
    ];
    const v28 = [];
    const v29 = {
        a: v28,
        c: -4096
    };
    const v30 = {
        c: v27,
    };
    let v31 = 1337;
    for (let v36 = 0; v36 < 1000; v36++) {
        try {
            const v37 = [];
            let v39 = v36;
            const v42 = [
                13.37,
                13.37,
                13.37,
                v39,
                13.37
            ];
            let v43 = v36;
            function v44(v45, v46) {
                let v49 = String;
                const v50 = v49.fromCharCode(1792147552, v36, 1792147552, v36, 255);
                const v51 = Function(v50);
                const v52 = v28 % v36;
                const v53 = v36 === v31;
                let v54 = v52;
                if (v46) {
                    const v55 = v37 - v45;
                    v54 = v55;
                } else {
                    for (const v56 of v25) {
                        const v57 = v29 >> String;
                    }
                    v54 = v45;
                }
                const v58 = ~v36;
                const v59 = v51(v53, 1000, v53);
                return 1792147552;
            }
            let v60 = v37;
            const v61 = v44(...v60, v43, ...v42, 65537, 13.37);
        } catch (v62) {
        }
    }
}
main();