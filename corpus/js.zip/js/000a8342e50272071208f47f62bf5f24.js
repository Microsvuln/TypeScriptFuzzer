var mediaElement = null;
var source_playlist = 'test-mediaopened.asx';
var source_normal = 'timecode-long.wmv';
var steps_left = [
    4,
    3,
    2,
    2,
    2,
    2,
    2,
    2,
    2
];
var failed = [
    false,
    false,
    false,
    false,
    false,
    false,
    false,
    false,
    false
];
var media_opened_count = [
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0
];
var downloaded = [
    false,
    false,
    false,
    false,
    false,
    false,
    false,
    false,
    false
];
var start_time = [
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0
];
var valid_states = [
    'PW',
    'P',
    'P',
    'W',
    'P',
    'P',
    'PW',
    'W',
    'P'
];
var interval = null;
var current_test = -1;
function NextTest() {
    current_test++;
    TestLogger.LogDebug('  ** NextTest (), Current Test = ' + current_test + ' current test\'s steps left: ' + steps_left[current_test]);
    switch (current_test) {
    case 0:
        interval = setInterval('Tick ();', 450);
        mediaElement.AutoPlay = false;
        mediaElement.Source = source_playlist;
        break;
    case 1:
        mediaElement.AutoPlay = true;
        mediaElement.Source = source_normal;
        break;
    case 2:
        mediaElement.AutoPlay = true;
        mediaElement.Source = source_normal;
        break;
    case 3:
        mediaElement.AutoPlay = false;
        mediaElement.Source = source_normal;
        break;
    case 4:
        mediaElement.AutoPlay = true;
        mediaElement.Source = source_normal;
        break;
    case 5:
        mediaElement.AutoPlay = true;
        mediaElement.Source = source_normal;
        mediaElement.Pause();
        break;
    case 6:
        mediaElement.AutoPlay = true;
        mediaElement.Source = source_normal;
        break;
    case 7:
        mediaElement.AutoPlay = false;
        mediaElement.Source = source_normal;
        break;
    case 8:
        mediaElement.AutoPlay = true;
        mediaElement.Source = source_normal;
        break;
    default:
        var success = true;
        for (var i = 0; i < failed.length; i++) {
            if (failed[i]) {
                success = false;
                TestLogger.LogError('Test #' + i + ' failed.');
            }
        }
        TestLogger.LogResult(success ? 1 : -1);
        SignalShutdown();
    }
}
function Tick() {
    var now = new Date().getTime();
    TestLogger.LogDebug('Tick, now: ' + now + ' current_test: ' + current_test + ', steps left: ' + steps_left[current_test]);
    switch (current_test) {
    case 0:
        if (!downloaded[current_test])
            break;
        switch (steps_left[current_test]) {
        case 4:
            TestLogger.LogDebug('Tick: Starting to play video 1 at ' + now);
            mediaElement.Play();
            steps_left[current_test]--;
            break;
        case 3:
            if (media_opened_count[current_test] == 2) {
                start_time[current_test] = now;
                steps_left[current_test]--;
            }
            break;
        case 2:
            if (now - start_time[current_test] > 2000) {
                TestLogger.LogDebug('Tick: Stopping video 0, we\'ve played for ' + (now - start_time[current_test]) + ' ms');
                mediaElement.Stop();
                steps_left[current_test]--;
            }
            break;
        case 1:
            steps_left[current_test]--;
            NextTest();
            break;
        }
        break;
    case 1:
        if (!downloaded[current_test])
            break;
        switch (steps_left[current_test]) {
        case 3:
            start_time[current_test] == now;
            steps_left[current_test]--;
            break;
        case 2:
            if (now - start_time[current_test] > 2000) {
                TestLogger.LogDebug('Tick: Stopping video 1, we\'ve played for ' + (now - start_time[current_test]) + ' ms');
                mediaElement.Stop();
                steps_left[current_test]--;
            }
            break;
        case 1:
            steps_left[current_test]--;
            NextTest();
            break;
        }
        break;
    case 2:
    case 3:
    case 4:
    case 5:
    case 6:
    case 7:
    case 8:
        switch (steps_left[current_test]) {
        case 1:
            steps_left[current_test]--;
            NextTest();
            break;
        }
        break;
    }
}
function OnMediaOpened(obj, args) {
    TestLogger.LogDebug('OnMediaOpened: ' + obj.Source + ' current_test: ' + current_test + ', CurrentState: ' + obj.CurrentState);
    media_opened_count[current_test]++;
    if (!IsStateValid(obj.CurrentState, valid_states[current_test])) {
        TestLogger.LogError('In the MediaOpened event expected CurrentState to be ' + GetStateList(valid_states[current_test]) + ', but it is \'' + obj.CurrentState + '\' (Test #' + current_test + ')');
        failed[current_test] = true;
    }
    switch (current_test) {
    case 2:
    case 6:
    case 7:
    case 8:
        switch (steps_left[current_test]) {
        case current_test:
            TestLogger.LogWarning('Test #' + current_test + ' was inconclusive, didn\'t succeed in stopping/pausing the video before MediaOpened was raised');
            steps_left[current_test]--;
            break;
        }
        break;
    case 3:
    case 4:
    case 5:
        switch (steps_left[current_test]) {
        case 2:
            steps_left[current_test]--;
            break;
        }
        break;
    }
}
function OnBufferingProgressChanged(sender, args) {
    TestLogger.LogDebug('OnBufferingProgressChanged: ' + sender.Source + ' ' + sender.BufferingProgress);
    switch (current_test) {
    case 2:
        switch (steps_left[current_test]) {
        case 2:
            mediaElement.Stop();
            steps_left[current_test]--;
            break;
        }
        break;
    case 6:
    case 7:
        switch (steps_left[current_test]) {
        case 2:
            mediaElement.Pause();
            steps_left[current_test]--;
            break;
        }
        break;
    }
}
function OnDownloadProgressChanged(sender, args) {
    TestLogger.LogDebug('OnDownloadProgressChanged: ' + sender.Source + ' ' + sender.DownloadProgress);
    downloaded[current_test] = sender.DownloadProgress == 1;
    switch (current_test) {
    case 2:
        switch (steps_left[current_test]) {
        case 2:
            mediaElement.Stop();
            steps_left[current_test]--;
            break;
        }
        break;
    case 6:
    case 7:
        switch (steps_left[current_test]) {
        case 2:
            mediaElement.Pause();
            steps_left[current_test]--;
            break;
        }
        break;
    }
}
function OnCurrentStateChanged(sender, args) {
    TestLogger.LogDebug('OnCurrentStateChanged: ' + sender.Source + ' ' + current_test + ' ' + sender.CurrentState);
    switch (current_test) {
    case 6:
    case 7:
        switch (steps_left[current_test]) {
        case 2:
            mediaElement.Pause();
            steps_left[current_test]--;
            break;
        }
        break;
    case 8:
        switch (steps_left[current_test]) {
        case 2:
            if (sender.CurrentState == 'Playing') {
                mediaElement.Pause();
                steps_left[current_test]--;
            }
            break;
        }
        break;
    }
}
function IsStateValid(state, valid) {
    TestLogger.LogDebug('IsStateValid (' + state + ', ' + valid + ')');
    if (state == 'Paused') {
        return valid.indexOf('W') >= 0;
    } else {
        return valid.indexOf(state.substring(0, 1)) >= 0;
    }
}
function GetStateList(valid) {
    var result = '';
    var state = '';
    var comma = '';
    TestLogger.LogDebug('GetStateList (' + valid + ')');
    for (var i = 0; i < valid.length; i++) {
        var letter = valid.substring(i, i + 1);
        switch (letter) {
        case 'P':
            state = 'Playing';
            break;
        case 'S':
            state = 'Stopped';
            break;
        case 'B':
            state = 'Buffering';
            break;
        case 'W':
            state = 'Paused';
            break;
        case 'C':
            state = 'Closed';
            break;
        case 'E':
            state = 'Error';
            break;
        case 'O':
            state = 'Opening';
            break;
        default:
            state = 'Unknown (' + letter + ')';
            break;
        }
        result += comma + '\'' + state + '\'';
        comma = ' or ';
    }
    return result;
}
function OnMediaEnded(obj, args) {
    TestLogger.LogDebug('OnMediaEnded: ' + obj.Source);
}
function OnMediaFailed(obj, args) {
    Fail('OnMediaFailed: ' + obj.Source + ' ' + ErrorEventArgsToOneLineString(args));
}
function OnPluginLoaded(o, e) {
    TestLogger.LogDebug('OnPluginLoaded');
    mediaElement = o.getHost().content.findName('TestVideo');
    NextTest();
}
function OnPluginError(o, e) {
    Fail('OnPluginError: ' + ErrorEventArgsToOneLineString(args));
}
function Fail(msg) {
    TestLogger.LogError(msg);
    TestLogger.LogResult(-1);
    SignalShutdown();
}