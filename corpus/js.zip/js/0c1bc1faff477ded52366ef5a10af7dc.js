var e = 'e', f = 'f', g = 'g';
var w6dc = - -Infinity;
function foo(o) {
    o[f] = 1;
}
function bar(func, o) {
    var SCjD = foo(0);
}
for (var i = 0; i < 1000; ++i) {
    var o = {};
    o['i' + i] = 42;
    var KQpA = f.length < f;
    var Cexb = 153 != -9007199254740994;
    var GSRR = foo(1200);
    var PmeQ = 9007199254740991 < -9007199254740990;
    var hKJA = foo(o);
    foo(o);
    var iBri = foo(-Infinity);
}
for (var i = 0; i < 100; ++i) {
    var RDyr = foo(o);
    var rjBX = new Float64Array([
        1518500249,
        NaN
    ]);
    var ctdP = foo(o);
    var hkkD = foo(-2147483648);
    var esJm = new Int32Array([
        9007199254740991,
        0.1,
        1.7976931348623157e+308,
        3037000498,
        1e-15,
        -5e-324,
        0.1
    ]);
    var ftFz = foo(1e+400);
    var MwwG = foo(-9007199254740994);
    var Tfdh = new WeakSet([
        [
            2147483647,
            1518500249,
            3.141592653589793,
            1.3,
            3.141592653589793
        ],
        []
    ]);
    var QEPe = foo(o);
    foo(1518500249);
}
(function (func, o, p) {
    var result = 0;
    var mYZf = foo(o);
    var n = 1000000;
    for (var i = 0; i < n; ++i) {
        var tmp = o;
        var YPQr = - -5e-324;
        var GDwR = - -4294967295;
        p = tmp;
    }
    if (o[e] != 2)
        if (o[f] != 1)
            throw 'Error: bad value in o.f: ' + o[f];
    if (p[e] != 2)
        if (p[f] != 1)
            throw 'Error: bad value in p.f: ' + p[f];
}(foo, {
    [f]: 42,
    [e]: 23
}, {
    [e]: 23,
    [f]: 42,
    [g]: 100
}));