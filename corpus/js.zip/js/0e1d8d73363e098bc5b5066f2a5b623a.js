'use strict';
var Logerr = function () {
    var setConfig;
    function init(userConfig = {}) {
        var config = {
            detailedErrors: true,
            remoteLogging: false,
            remoteSettings: {
                url: null,
                additionalParams: null,
                successCallback: null,
                errorCallback: null
            }
        };
        setConfig = Object.assign(config, userConfig);
    }
    function _listener(e) {
        if (setConfig.detailedErrors) {
            _detailedErrors(e);
        }
        if (setConfig.remoteLogging) {
            _remoteLogging(e, setConfig.remoteSettings);
        }
    }
    function _detailedErrors(e) {
        var i = _errorData(e);
    }
    function _remoteLogging(e, remoteSettings) {
        if (!remoteSettings.url) {
            throw 'Provide remote URL to log errors remotely';
            return false;
        } else if (remoteSettings.additionalParams && typeof remoteSettings.additionalParams !== 'object') {
            throw 'Invalid data type, additionalParams should be a valid object';
            return false;
        }
        var http = new XMLHttpRequest();
        var url = remoteSettings.url;
        var data = _errorData(e);
        var setData = Object.assign(data, remoteSettings.additionalParams);
        var params = _serializeData(setData);
        http.open('POST', url, true);
        http.send(params);
        http.onreadystatechange = function () {
            if (http.readyState == 4 && http.status == 200) {
                if (http.readyState == XMLHttpRequest.DONE) {
                    if (remoteSettings.successCallback) {
                        remoteSettings.successCallback();
                    }
                } else {
                    if (remoteSettings.errorCallback) {
                        remoteSettings.errorCallback();
                    } else {
                        throw 'Remote error logging failed!';
                    }
                }
            }
        };
    }
    function _serializeData(params) {
        return Object.keys(params).map(function (k) {
            return encodeURIComponent(k) + '=' + encodeURIComponent(params[k]);
        }).join('&');
    }
    function _errorData(e) {
        var filename = e.filename.lastIndexOf('/');
        var datetime = new Date().toString();
        return {
            type: e.type,
            path: e.filename,
            filename: e.filename.substring(++filename),
            line: e.lineno,
            column: e.colno,
            error: e.message,
            stackTrace: e.error.stack.toString().replace(/(\r\n|\n|\r)/gm, ''),
            datetime: datetime
        };
    }
    return { init: init };
}();
Logerr.init();