function main() {
    let v1 = 13.37;
    const v6 = [
        13.37,
        13.37,
        13.37,
        'p76QI.ipnu',
        13.37
    ];
    const v7 = v1 <= 1337;
    const v12 = [
        1337,
        1337,
        1337,
        1337,
        1337
    ];
    const v13 = {
        e: v12,
        length: 13.37,
        d: v12,
        __proto__: Symbol,
        valueOf: v6,
        c: 'p76QI.ipnu'
    };
    for (const v18 of 'p76QI.ipnu') {
        const v26 = [13.37];
        const v28 = [
            1337,
            1337
        ];
        const v32 = { set: Symbol };
        const v34 = Object.defineProperty(Symbol, 2365454094, v32);
        const v35 = [
            v28,
            v26,
            1337
        ];
        const v38 = [
            13.37,
            13.37,
            13.37,
            13.37,
            13.37
        ];
        const v39 = [];
        let v40 = v39;
        function v41(v42, v43) {
            let v46 = 0;
            while (v46 < 10) {
                for (let v50 = 0; v50 < 8; v50++) {
                    const v56 = [
                        13.37,
                        13.37,
                        13.37,
                        13.37,
                        13.37
                    ];
                    const v57 = Object.keys(v56);
                    for (let v58 = 0; v58 < 5; v58++) {
                    }
                }
                const v59 = v46 + 1;
                v46 = v59;
            }
        }
        const v60 = [];
        let v61 = v60;
        const v62 = v41(...v61, v40, ...v38, 10, 13.37);
        let v65 = 0;
        const v75 = v65 + 1;
        v65 = v75;
    }
    let v78 = 0;
}
main();