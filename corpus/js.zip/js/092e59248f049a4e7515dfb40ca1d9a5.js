var val = '';
for (i = 0; i < 200000; ++i)
    val += Math.random();