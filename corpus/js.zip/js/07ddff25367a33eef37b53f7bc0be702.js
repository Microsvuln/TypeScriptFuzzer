function main() {
    const v1 = [
        1337,
        1337,
        1337,
        1337,
        1337
    ];
    for (let v6 = 0; v6 < 1000; v6++) {
        try {
            const v7 = [];
            let v9 = v6;
            const v12 = [
                v6,
                'isConcatSpreadable',
                13.37,
                v9,
                13.37
            ];
            let v13 = v6;
            function v14(v15, v16) {
                let v20 = String;
                const v21 = v20.fromCharCode(-1, 4061361086, v6, v6, v1);
                const v22 = RegExp(v21);
            }
            let v23 = v7;
            const v24 = v14(...v23, v13, ...v12, 65537, 13.37);
        } catch (v25) {
            let v27 = 0;
            for (let v31 = 0; v31 < 1337; v31++) {
                try {
                    const v33 = v6 + 1;
                    let v36 = String;
                    const v37 = v36.fromCharCode(v6, v33, v31, 512, v27);
                    const v38 = RegExp(v37);
                } catch (v39) {
                }
            }
        }
    }
}
main();