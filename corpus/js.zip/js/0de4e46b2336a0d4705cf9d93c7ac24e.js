function main() {
    let v1 = 0;
    const v4 = [
        v1,
        0,
        -459203.1875774263,
        -459203.1875774263,
        -459203.1875774263
    ];
    let v5 = v4;
    function v6(v7, v8) {
        try {
            const v11 = [
                13.37,
                13.37,
                13.37,
                13.37,
                13.37
            ];
            let v12 = v7;
            function v13(v14, v15) {
                let v19 = 13.37;
                const v20 = new String(v19);
                const v21 = v20.endsWith(4017745480, v20);
                v11.toString = v13;
                const v24 = [
                    13.37,
                    13.37,
                    13.37,
                    13.37,
                    13.37
                ];
                const v25 = [];
                let v26 = v25;
                function v27(v28, v29) {
                    const v31 = 0 - v11;
                }
                const v32 = [];
                let v33 = v32;
                const v34 = v27(...v33, v26, ...v24, 10, 13.37);
            }
            const v35 = [];
            let v36 = v35;
            const v37 = v13(...v36, v12, ...v11, 1337, 13.37);
        } catch (v38) {
        }
    }
    const v39 = [];
    let v40 = v39;
    const v41 = v6(...v40, ...v5, ...v4, -2928327788, -459203.1875774263);
}
main();