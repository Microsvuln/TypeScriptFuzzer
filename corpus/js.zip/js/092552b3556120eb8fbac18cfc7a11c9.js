var ProcessingRoot;
var i18nTemplate = function () {
    var handlers = {
        'i18n-content': function (element, key, data, visited) {
            element.textContent = data.getString(key);
        },
        'i18n-options': function (select, key, data, visited) {
            var options = data.getValue(key);
            options.forEach(function (optionData) {
                var option = typeof optionData == 'string' ? new Option(optionData) : new Option(optionData[1], optionData[0]);
                select.appendChild(option);
            });
        },
        'i18n-values': function (element, attributeAndKeys, data, visited) {
            var parts = attributeAndKeys.replace(/\s/g, '').split(/;/);
            parts.forEach(function (part) {
                if (!part)
                    return;
                var attributeAndKeyPair = part.match(/^([^:]+):(.+)$/);
                if (!attributeAndKeyPair)
                    throw new Error('malformed i18n-values: ' + attributeAndKeys);
                var propName = attributeAndKeyPair[1];
                var propExpr = attributeAndKeyPair[2];
                var value = data.getValue(propExpr);
                if (propName[0] == '.') {
                    var path = propName.slice(1).split('.');
                    var targetObject = element;
                    while (targetObject && path.length > 1) {
                        targetObject = targetObject[path.shift()];
                    }
                    if (targetObject) {
                        targetObject[path] = value;
                        if (path == 'innerHTML') {
                            for (var i = 0; i < element.children.length; ++i) {
                                processWithoutCycles(element.children[i], data, visited, false);
                            }
                        }
                    }
                } else {
                    element.setAttribute(propName, value);
                }
            });
        }
    };
    var prefixes = [''];
    prefixes.push('* /deep/ ');
    var attributeNames = Object.keys(handlers);
    var selector = prefixes.map(function (prefix) {
        return prefix + '[' + attributeNames.join('], ' + prefix + '[') + ']';
    }).join(', ');
    function process(root, data) {
        processWithoutCycles(root, data, [], true);
    }
    function processWithoutCycles(root, data, visited, mark) {
        if (visited.indexOf(root) >= 0) {
            return;
        }
        visited.push(root);
        var importLinks = root.querySelectorAll('link[rel=import]');
        for (var i = 0; i < importLinks.length; ++i) {
            var importLink = importLinks[i];
            if (!importLink.import) {
                continue;
            }
            processWithoutCycles(importLink.import, data, visited, mark);
        }
        var templates = root.querySelectorAll('template');
        for (var i = 0; i < templates.length; ++i) {
            var template = templates[i];
            processWithoutCycles(template.content, data, visited, mark);
        }
        var isElement = root instanceof Element;
        if (isElement && root.matches(selector))
            processElement(root, data, visited);
        var elements = root.querySelectorAll(selector);
        for (var i = 0; i < elements.length; ++i) {
            processElement(elements[i], data, visited);
        }
        if (mark) {
            var processed = isElement ? [root] : root.children;
            if (processed) {
                for (var i = 0; i < processed.length; ++i) {
                    processed[i].setAttribute('i18n-processed', '');
                }
            }
        }
    }
    function processElement(element, data, visited) {
        for (var i = 0; i < attributeNames.length; i++) {
            var name = attributeNames[i];
            var attribute = element.getAttribute(name);
            if (attribute != null)
                handlers[name](element, attribute, data, visited);
        }
    }
    return { process: process };
}();
function dragOver(evt) {
    console.log(arguments.callee.name);
    evt.dataTransfer.dropEffect = 'copy';
    evt.preventDefault();
    return false;
}
function dragLeave(evt) {
    console.log(arguments.callee.name);
    evt.dataTransfer.dropEffect = 'copy';
    evt.preventDefault();
    return false;
}
function dragEnter(evt) {
    console.log(arguments.callee.name);
    evt.dataTransfer.dropEffect = 'copy';
    evt.preventDefault();
    return false;
}
function drop(evt) {
    console.log(arguments.callee.name);
    evt.dataTransfer.dropEffect = 'copy';
    evt.preventDefault();
    handleDrop(evt);
    return false;
}
function handleDrop(evt) {
    var items = evt.dataTransfer.items;
    if (items) {
        for (var i = 0; i < items.length; i++) {
            item = items[i];
            if (item.kind == 'file') {
                var entry = item.webkitGetAsEntry();
                handleEntry(entry);
            }
        }
    }
}
function handleEntry(entry) {
    console.log('handle entry', entry);
    function onread(evt) {
        doupload(entry, evt.target.result);
    }
    var fr = new FileReader();
    fr.onload = fr.onerror = onread;
    entry.file(function (f) {
        fr.readAsArrayBuffer(f);
    });
}
function doupload(entry, data) {
    console.log('doupload', entry, data);
    fetch(window.location.pathname + encodeURIComponent(entry.name), {
        method: 'PUT',
        body: data
    }).then(function (r) {
        console.log('upload resp', r);
        window.location.reload();
    }).catch(function (e) {
        console.log('upload err', e);
    });
}