function main() {
    const v1 = [-3179590583];
    let v2 = v1;
    const v5 = [
        1,
        1,
        1,
        1,
        1
    ];
    const v6 = [];
    let v7 = v6;
    function v8(v9, v10) {
        let v12 = Reflect;
        const v14 = new Proxy(v12, Reflect);
        function v25(v26, v27) {
            const v28 = isFinite && v25;
        }
        let v31 = 0;
        let v34 = 0;
        const v35 = v34 + 1;
        v34 = v35;
        v14.__proto__ = v2;
        const v38 = { set: Symbol };
        const v40 = Object.freeze(v14, 3, v38);
    }
    let v41 = v7;
    const v42 = v8(v41, v7, ...v5, -258611160, 1);
    const v43 = v8(v6);
}
main();