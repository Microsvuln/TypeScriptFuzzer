function Module() {
    'use asm';
    function f() {
    }
    return f;
}
function recur() {
    try {
        recur();
        var jdGW = Module(-9007199254740994);
    } catch (e) {
        var Znyy = ~-4294967295;
        var rNzw = Module(0);
        var GMdm = Module(-9007199254740992);
    }
}
recur();
var xxAQ = recur();
var AjZm = recur();
var MnnW = Module(-1);
var baYc = recur();