function main() {
    const v3 = [
        1337,
        1337
    ];
    const v4 = 65537 * isNaN;
    const v7 = new Float64Array(37718);
    const v8 = v7.buffer;
    const v9 = v7.includes(v4);
}
main();