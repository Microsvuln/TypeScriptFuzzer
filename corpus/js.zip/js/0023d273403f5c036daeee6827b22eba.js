function main() {
    let v2 = -1024;
    const v5 = [];
    let v6 = v5;
    const v11 = { get: Symbol };
    const v13 = Object.defineProperty(v6, '__proto__', v11);
    const v17 = new Uint32Array(11105);
    const v22 = [
        13.37,
        13.37,
        13.37,
        'p76QI.ipnu',
        13.37
    ];
    const v24 = [];
    const v25 = [
        1337,
        1337,
        1337,
        1337,
        1337
    ];
    const v26 = {
        e: v25,
        length: 13.37,
        d: v25,
        __proto__: Symbol,
        valueOf: v22,
        c: 'p76QI.ipnu'
    };
    for (let v30 = 0; v30 < 6; v30++) {
        v26[v30] = v24;
    }
    const v32 = v17 <= Uint32Array;
    for (const v35 of 'p76QI.ipnu') {
        const v38 = [1337];
        const v41 = [
            1337,
            1337,
            1337,
            1337,
            1337
        ];
        let v45 = 0;
        while (v45 < 4) {
            for (let v49 = 0; v49 < 8; v49++) {
                for (let v53 = 0; v53 < 5; v53++) {
                    const v54 = v41.concat(v53, 0, 'p76QI.ipnu', Symbol);
                }
            }
            const v55 = v45 + 1;
            v45 = v55;
        }
        Array.__proto__ = v38;
    }
    let v58 = 0;
    do {
    } while (v58 < Symbol);
}
main();