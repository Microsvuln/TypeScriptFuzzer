try {
    alphabetR = [
        'ё',
        'я',
        'ю',
        'э',
        'ь',
        'ы',
        'ъ',
        'щ',
        'ш',
        'ч',
        'ц',
        'х',
        'ф',
        'у',
        'т',
        'с',
        'р',
        'П',
        'О',
        'Н',
        'М',
        'Л',
        'К',
        'Й',
        'И',
        'З',
        'Ж',
        'Е',
        'Д',
        'Г',
        'В',
        'Б',
        'А'
    ];
    var GirP = alphabetR.sort(function () {
    }, -5e-324);
    var tsMs = alphabetR.find(function () {
    }, 9007199254740990, alphabetR.length);
    var PmcX = alphabetR.slice(alphabetR.length, alphabetR.length);
    var kYBs = alphabetR.forEach(function () {
    }, -9007199254740991);
    var xNxT = alphabetR.shift(alphabetR.length);
    var KSaT = alphabetR.indexOf(alphabetR, function () {
    });
    var skAY = alphabetR.filter(function () {
    }, -Infinity);
    var dwNG = alphabetR.findIndex(function () {
    }, alphabetR);
    var hJdB = alphabetR.sort(function () {
    }, alphabetR);
    var TYyG = alphabetR.pop(alphabetR.length);
    var dsGA = alphabetR.indexOf(alphabetR.length, function () {
    });
    var jfxy = alphabetR.reverse();
    var eMWs = alphabetR.some(function () {
    }, -5e-324);
    var nAPF = alphabetR.shift(alphabetR);
    var SXMM = alphabetR.sort(function () {
    }, -4294967295);
    alphabet = [
        'А',
        'Б',
        'В',
        'Г',
        'Д',
        'Е',
        'Ж',
        'З',
        'И',
        'Й',
        'К',
        'Л',
        'М',
        'Н',
        'О',
        'П',
        'р',
        'с',
        'т',
        'у',
        'ф',
        'х',
        'ц',
        'ч',
        'ш',
        'щ',
        'ъ',
        'ы',
        'ь',
        'э',
        'ю',
        'я',
        'ё'
    ];
    var myComparefn = function (x, y) {
        xS = String(x);
        yS = String(y);
        if (xS < yS)
            return 1;
        if (xS > yS)
            return -1;
        return 0;
    };
    alphabet.sort(myComparefn);
    result = true;
    for (i = 0; i < 26; i++) {
        if (alphabetR[i] !== alphabet[i])
            result = false;
    }
    if (result !== true) {
        testFailed('#1: CHECK RUSSIAN ALPHABET');
    }
} catch (ex) {
    sputnikException = ex;
}
var successfullyParsed = true;