function main() {
    const v3 = [
        13.37,
        13.37
    ];
    const v4 = [
        'object',
        v3,
        13.37
    ];
    const v5 = {
        length: v3,
        toString: 13.37,
        c: 92937497,
        constructor: v4,
        __proto__: v4,
        d: v4
    };
    const v8 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v9 = [];
    let v10 = v9;
    function v11(v12, v13) {
        let v16 = 0;
        while (v16 < 10) {
            const v24 = [1337];
            let v25 = v24;
            let v28 = 0;
            while (v28 < 10) {
                let v34 = 0;
                const v35 = v34 + 1;
                const v42 = [
                    13.37,
                    13.37,
                    13.37,
                    13.37,
                    13.37
                ];
                const v44 = [
                    1337,
                    1337,
                    13.37,
                    1337,
                    1337
                ];
                const v45 = [];
                const v46 = {
                    e: v44,
                    length: 13.37,
                    d: v44,
                    __proto__: Symbol,
                    valueOf: v42,
                    c: 'p76QI.ipnu'
                };
                const v48 = [];
                let v51 = 0;
                const v52 = v51 + 1;
                Symbol.__proto__ = v48;
                const v53 = v46 - 1;
                let v56 = 0;
                do {
                    const v57 = v56 + 1;
                    v56 = v57;
                } while (v56 < 7);
                v25.toString = Object;
                const v60 = v28 + 1;
                v28 = v60;
            }
            const v61 = v16 + 1;
            v16 = v61;
        }
        return v5;
    }
    const v62 = [];
    let v63 = v62;
    const v64 = v11(...v63, v10, ...v8, 10, 13.37);
}
main();