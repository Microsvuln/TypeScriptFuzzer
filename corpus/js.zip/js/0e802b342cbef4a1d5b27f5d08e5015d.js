var c = 40, g = 10, N = 24, COL_MIN = 4, ENDLINE = '<br />';
function println(msg) {
}
function getGridStyle(name, cls) {
    var ps = name.indexOf('s'), pm = name.indexOf('m'), pe = name.indexOf('e'), out = '', sw, ew, ERROR_INFO = 'Something is wrong!';
    if (/\d*[a-z]\d*/i.test(name.replace(/s/, '').replace(/m/, '').replace(/e/, '')) || (ps === -1 || pm === -1) || !/.*m0.*/i.test(name)) {
        return ERROR_INFO;
    }
    cls = cls || '.grid-' + name;
    if (pe === -1) {
        if (ps < pm) {
            sw = parseInt(name.substring(ps + 1, pm), 10);
            out += cls + ' .main-wrap { margin-left: ' + (sw + g) + 'px; }' + ENDLINE;
            out += cls + ' .col-sub { width: ' + sw + 'px; margin-left: -100%; }' + ENDLINE;
        } else {
            sw = parseInt(name.substring(ps + 1), 10);
            out += cls + ' .main-wrap { margin-right: ' + (sw + g) + 'px; }' + ENDLINE;
            out += cls + ' .col-sub { width: ' + sw + 'px; margin-left: -' + sw + 'px; }' + ENDLINE;
        }
    } else {
        if (ps < pm && pm < pe) {
            sw = parseInt(name.substring(ps + 1, pm), 10);
            ew = parseInt(name.substring(pe + 1), 10);
            out += cls + ' .main-wrap { margin: 0 ' + (ew + g) + 'px 0 ' + (sw + g) + 'px; }' + ENDLINE;
            out += cls + ' .col-sub { width: ' + sw + 'px; margin-left: -100%; }' + ENDLINE;
            out += cls + ' .col-extra { width: ' + ew + 'px; margin-left: -' + ew + 'px; }' + ENDLINE;
        } else if (pe < pm && pm < ps) {
            sw = parseInt(name.substring(ps + 1), 10);
            ew = parseInt(name.substring(pe + 1, pm), 10);
            out += cls + ' .main-wrap { margin: 0 ' + (sw + g) + 'px 0 ' + (ew + g) + 'px; }' + ENDLINE;
            out += cls + ' .col-sub { width: ' + sw + 'px; margin-left: -' + sw + 'px; }' + ENDLINE;
            out += cls + ' .col-extra { width: ' + ew + 'px; margin-left: -100%; }' + ENDLINE;
        } else if (pm < ps && ps < pe) {
            sw = parseInt(name.substring(ps + 1, pe), 10);
            ew = parseInt(name.substring(pe + 1), 10);
            out += cls + ' .main-wrap { margin-right: ' + (sw + ew + 2 * g) + 'px; }' + ENDLINE;
            out += cls + ' .col-sub { width: ' + sw + 'px; margin-left: -' + (sw + ew + g) + 'px; }' + ENDLINE;
            out += cls + ' .col-extra { width: ' + ew + 'px; margin-left: -' + ew + 'px; }' + ENDLINE;
        } else if (pm < pe && pe < ps) {
            sw = parseInt(name.substring(ps + 1), 10);
            ew = parseInt(name.substring(pe + 1, ps), 10);
            out += cls + ' .main-wrap { margin-right: ' + (sw + ew + 2 * g) + 'px; }' + ENDLINE;
            out += cls + ' .col-sub { width: ' + sw + 'px; margin-left: -' + sw + 'px; }' + ENDLINE;
            out += cls + ' .col-extra { width: ' + ew + 'px; margin-left: -' + (ew + sw + g) + 'px; }' + ENDLINE;
        } else if (ps < pe && pe < pm) {
            sw = parseInt(name.substring(ps + 1, pe), 10);
            ew = parseInt(name.substring(pe + 1, pm), 10);
            out += cls + ' .main-wrap { margin-left: ' + (sw + ew + 2 * g) + 'px; }' + ENDLINE;
            out += cls + ' .col-sub { width: ' + sw + 'px; margin-left: -100%; }' + ENDLINE;
            out += cls + ' .col-extra { width: ' + ew + 'px; margin-left: -100%; position: relative; left: ' + (sw + g) + 'px; }' + ENDLINE;
        } else if (pe < ps && ps < pm) {
            sw = parseInt(name.substring(ps + 1, pm), 10);
            ew = parseInt(name.substring(pe + 1, ps), 10);
            out += cls + ' .main-wrap { margin-left: ' + (sw + ew + 2 * g) + 'px; }' + ENDLINE;
            out += cls + ' .col-sub { width: ' + sw + 'px; margin-left: -100%; position: relative; left: ' + (ew + g) + 'px; }' + ENDLINE;
            out += cls + ' .col-extra { width: ' + ew + 'px; margin-left: -100%; }' + ENDLINE;
        }
    }
    return out || 'Something is wrong!' + ENDLINE;
}
function printAll() {
    var i, j, sw, ew, S_MAX, E_MAX, sum = [
            0,
            0
        ];
    println('/** \uFFFD\uFFFD\uFFFD\uFFFD\uFFFDٶ\uFFFD\uFFFD\uFFFDa. \uFFFDܿ\uFFFD\uFFFD\uFFFDΪ 950px; b. \uFFFDп\uFFFD\uFFFD\uFFFDС\uFFFD\uFFFD 150px. **/' + ENDLINE);
    println('/** \uFFFD\uFFFD\uFFFD\uFFFD\uFFFD\uFFFD\uFFFD\uFFFD **/');
    S_MAX = N - COL_MIN;
    for (i = COL_MIN; i <= S_MAX; ++i) {
        sw = i * c - g;
        println(getGridStyle('s' + sw + 'm0', '.grid-s' + i + 'm0'));
        println(getGridStyle('m0s' + sw, '.grid-m0s' + i));
        sum[0] += 2;
    }
    println('/** \uFFFD\uFFFD\uFFFD\uFFFD\uFFFD\uFFFD\uFFFD\uFFFD **/');
    S_MAX = N - 2 * COL_MIN;
    for (i = COL_MIN; i <= S_MAX; ++i) {
        sw = i * c - g;
        E_MAX = N - i - COL_MIN;
        for (j = COL_MIN; j <= E_MAX; ++j) {
            ew = j * c - g;
            println(getGridStyle('s' + sw + 'm0e' + ew, '.grid-s' + i + 'm0e' + j));
            println(getGridStyle('e' + ew + 'm0s' + sw, '.grid-e' + j + 'm0s' + i));
            println(getGridStyle('m0s' + sw + 'e' + ew, '.grid-m0s' + i + 'e' + j));
            println(getGridStyle('m0e' + ew + 's' + sw, '.grid-m0e' + j + 's' + i));
            println(getGridStyle('s' + sw + 'e' + ew + 'm0', '.grid-s' + i + 'e' + j + 'm0'));
            println(getGridStyle('e' + ew + 's' + sw + 'm0', '.grid-e' + j + 's' + i + 'm0'));
            sum[1] += 6;
        }
    }
    println('/** ͳ\uFFFD\uFFFD\uFFFD\uFFFD\uFFFD\uFFFD **/');
    println('/* \uFFFD\uFFFD\uFFFD\uFFFDդ\uFFFD\uD98B\uDF3E\uFFFD\uFFFD\uFFFD\uFFFD\uFFFD\uFFFD\uFFFD ' + sum[0] + ' = (20 - 4 + 1) * 2 = 17 * 2 */');
    println('/* \uFFFD\uFFFD\uFFFD\uFFFDդ\uFFFD\uD98B\uDF3E\uFFFD\uFFFD\uFFFD\uFFFD\uFFFD\uFFFD\uFFFD ' + sum[1] + ' = ((16 - 4 + 1) + (16 - 4 + 1 - 1) + ... + 2 + 1) * 6 = (13 + 12 + ... + 2 + 1) * 6 = 13 * 7 * 6 */');
}
function generateLayoutStyle(name) {
    var layoutStyleEl = document.getElementById('layout-style'), isStandardEl = document.getElementById('is-standard'), cls = '';
    if (isStandardEl.checked) {
        cls = name;
        name = name.replace(/\d+/g, function (n) {
            n = parseInt(n, 10) * 40;
            return n ? n - g : 0;
        });
    }
    layoutStyleEl.innerHTML = getGridStyle(name, cls);
}
printAll();