function test() {
    var text = 'Please contact us by phone (+359 222 222 222) or by email at example@abv.bg or at baj.ivan@yahoo.co.uk. This is not email: test@test. This also: @telerik.com. Neither this: a@a.b.';
    jsConsole.writeLine(emailsExtract(text));
}
function emailsExtract(text) {
    var email = text.match(/([\w-\.]+@[\w]+\.?[a-zA-Z]{2,4}\.[a-zA-Z]{2,4})/g);
    return email;
}