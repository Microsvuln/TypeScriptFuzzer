function main() {
    const v3 = Symbol[-3287037233];
    const v4 = {
        defineProperty: Symbol,
        get: v3,
        deleteProperty: Symbol,
        getOwnPropertyDescriptor: Symbol,
        preventExtensions: Symbol
    };
    const v6 = new Proxy(Symbol, v4);
    for (let v10 = 0; v10 < 100; v10++) {
        const v11 = v6();
    }
}
main();