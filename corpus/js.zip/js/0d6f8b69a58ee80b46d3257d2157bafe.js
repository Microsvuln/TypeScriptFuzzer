function main() {
    const v4 = [
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v7 = [];
    let v8 = v7;
    for (let v12 = 0; v12 < 128; v12++) {
        try {
            let v14 = v8;
            let v16 = String;
            const v17 = v16.fromCharCode(v14, v12, v8, 100, v12);
            const v18 = RegExp(v17);
        } catch (v19) {
            v8 = v12;
        }
    }
    const v20 = [1337];
    const v21 = [];
    const v22 = {
        length: 'search',
        b: v4
    };
    const v23 = { c: v22 };
    let v24 = v23;
    const v26 = [
        1337,
        1337
    ];
    const v29 = [
        13.37,
        13.37,
        13.37,
        13.37,
        v26
    ];
    const v30 = [];
    let v31 = v30;
    function v32(v33, v34) {
        const v40 = [
            13.37,
            13.37,
            13.37,
            13.37,
            13.37
        ];
        const v42 = [1337];
        const v43 = [
            13.37,
            v40
        ];
        const v44 = {
            __proto__: 1337,
            constructor: v43,
            length: v43,
            c: v40
        };
        const v45 = {
            __proto__: v44,
            toString: 13.37
        };
        let v46 = 1337;
        const v54 = [13.37];
        const v58 = v42.__proto__;
        'WQ5WyJcxo3'.length = 1;
        const v60 = parseInt('WQ5WyJcxo3');
        v46 = v42;
        const v61 = {
            toString: v60,
            c: v45,
            valueOf: 1337,
            __proto__: v44,
            constructor: v42,
            a: v40
        };
        for (let v63 = 0; v63 < 127; v63 = v63 + 3) {
            for (let v67 = 10; v67 < 100; v67 = v67 + 4) {
                try {
                    let v69 = String;
                    const v70 = v69.fromCharCode(v54, v63, v67, 100, v63);
                    const v71 = Function(v70);
                    const v72 = v43 + 10;
                    let v73 = v71;
                    try {
                        const v74 = new v73(v67, v42, v73);
                        v73 = String;
                    } catch (v75) {
                        const v76 = v69 < v63;
                        let v77 = 4;
                        if (v75) {
                            const v78 = new v71(10);
                            v77 = v67;
                        } else {
                            let v81 = 0;
                            do {
                                for (let v85 = 0; v85 < 7; v85++) {
                                    const v86 = v54.__proto__;
                                }
                                const v87 = v81 + 1;
                                v81 = v87;
                            } while (v81 < 2);
                            v77 = 100;
                        }
                        v73 = 100;
                    }
                } catch (v88) {
                }
            }
        }
        const v91 = [
            13.37,
            13.37
        ];
        function v96(v97, v98) {
            const v100 = Math.floor(v98);
            const v101 = 1337 * 1741133611;
            return v92;
        }
        for (let v103 = 0; v103 < 1000; v103++) {
        }
        return 1000;
    }
    const v108 = [];
    let v109 = v108;
    const v110 = v32(...v109, v31, ...v29, 10, 13.37);
}
main();