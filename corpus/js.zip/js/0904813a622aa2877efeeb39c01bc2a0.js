function main() {
    const v3 = [13.37];
    const v5 = [
        1337,
        1337,
        1337
    ];
    const v6 = [];
    const v7 = {
        d: v6,
        toString: -2147483649
    };
    const v8 = {
        e: 'description',
        d: v5,
        constructor: v6,
        valueOf: v7,
        __proto__: v3
    };
    const v10 = new Float32Array(v8);
    const v12 = new Int16Array(v10);
}
main();