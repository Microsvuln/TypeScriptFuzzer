function main() {
    const v1 = [];
    const v4 = [arguments];
    const v5 = [v4];
    const v6 = [13.37];
    const v8 = [
        v5,
        'replace',
        -441746.4139016614,
        -441746.4139016614,
        -441746.4139016614
    ];
    let v9 = v6;
    function v10(v11, v12) {
        for (let v17 = 0; v17 < 100; v17++) {
            try {
                const v20 = [
                    -441746.4139016614,
                    -441746.4139016614,
                    v6,
                    -441746.4139016614,
                    -441746.4139016614
                ];
                const v21 = [];
                let v22 = v21;
                function v23(v24, v25) {
                    let v27 = Function;
                    const v30 = [
                        v25,
                        129,
                        981509.8915850616
                    ];
                    const v31 = v17.toLocaleString();
                    const v32 = v30.join('b');
                    const v33 = v32.padStart(v31, v23);
                    const v34 = eval(v33);
                }
                const v35 = v23(...v1, ...v22, v20, 129, -441746.4139016614);
            } catch (v36) {
            }
        }
    }
    const v37 = [];
    let v38 = v37;
    const v39 = v10(...v38, ...v9, ...v8, 13.37, -441746.4139016614);
}
main();