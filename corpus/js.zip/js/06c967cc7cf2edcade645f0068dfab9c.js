function main() {
    const v1 = [13.37];
    for (let v5 = 0; v5 < 100; v5++) {
        try {
            const v8 = [
                -441746.4139016614,
                -441746.4139016614,
                -441746.4139016614,
                -441746.4139016614,
                -441746.4139016614
            ];
            const v9 = [];
            let v10 = v9;
            function v11(v12, v13) {
                const v16 = [
                    719904.8518018327,
                    719904.8518018327,
                    719904.8518018327,
                    719904.8518018327,
                    719904.8518018327
                ];
                const v18 = [];
                let v19 = v18;
                function v20(v21, v22) {
                    const v24 = [
                        13.37,
                        13.37,
                        13.37,
                        13.37,
                        13.37
                    ];
                    let v27 = eval;
                    const v28 = Int16Array > v24;
                    v16.toString = eval;
                    const v29 = 719904.8518018327[v22];
                    const v31 = {
                        set: v11,
                        get: eval
                    };
                    const v33 = Object.defineProperty(v24, -9007199254740992, v31);
                    const v34 = v24.__proto__;
                    try {
                        const v39 = [
                            'd3lNGSucR3',
                            -731466.7500826023,
                            -731466.7500826023,
                            -731466.7500826023
                        ];
                        const v40 = v19[268435456];
                        const v41 = v39.some(v40, v18);
                        let v44 = 0;
                        while (v44 < 6) {
                            for (let v48 = 0; v48 < 10; v48++) {
                                const v49 = v20(6, v1);
                            }
                            const v50 = v44 + 1;
                            v44 = v50;
                        }
                        function v51(v52, ...v53) {
                        }
                    } catch (v55) {
                    }
                    const v56 = v20.toLocaleString();
                    const v57 = v56.substring(1000, 128);
                    const v58 = eval(v57);
                }
                const v59 = [];
                let v60 = v59;
                const v61 = v20(...v60, v19, ...v16, 10, 719904.8518018327);
            }
            const v62 = [];
            let v63 = v62;
            const v64 = v11(...v63, ...v10, ...v8, 1337, -441746.4139016614);
        } catch (v65) {
        }
    }
}
main();