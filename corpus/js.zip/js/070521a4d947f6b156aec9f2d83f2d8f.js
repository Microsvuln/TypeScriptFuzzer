function main() {
    for (let v4 = 0; v4 < 127; v4++) {
        for (let v8 = 2; v8 < 100; v8 = v8 + 9) {
            try {
                const v12 = [
                    257,
                    1000
                ];
                let v13 = String;
                const v14 = v13.fromCharCode(100, v4, v8, 1000, v12);
                const v15 = Function(v14);
            } catch (v16) {
            }
        }
    }
}
main();