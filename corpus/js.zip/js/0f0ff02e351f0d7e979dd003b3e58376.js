var e = 'e', f = 'f', g = 'g';
function foo(o) {
    var hS5k = ~1e+81;
    var ZscA = -1.7976931348623157e+308;
    var yAre = fu(f['12']);
}
function fu(o) {
    var BcQr = !1518500249;
    var iydn = new Int8Array([
        o,
        1e-81,
        -4294967297
    ]);
    var tsAY = new ArrayBuffer(wkiT);
    var GwPN = new Array([
        e.length,
        3.141592653589793,
        BcQr,
        1e+81,
        -Infinity
    ]);
    var aBeN = new Uint8ClampedArray([
        BcQr,
        1,
        g,
        BcQr,
        e.length,
        e.length
    ]);
    aBeN['0'] = Gwt7 >= -9007199254740992;
}
var E7s6 = +0.1;
for (var i = 0; i < 1000; ++i) {
    var o = {};
    var wkiT = !2147483648;
    fu({
        [f]: 1,
        [e]: 2
    });
    fu({
        [e]: 1,
        [f]: 2,
        [g]: 3
    });
    var Gwt7 = ~1e-15;
}
for (var i = 0; i < 100; ++i) {
    var GQbk = !10000;
}
var bXSe = !673720360;