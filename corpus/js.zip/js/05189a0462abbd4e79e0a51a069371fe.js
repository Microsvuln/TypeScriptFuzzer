function main() {
    const v1 = [
        1337,
        1337,
        1337,
        1337
    ];
    const v6 = String.fromCodePoint(65536);
    const v8 = [];
    let v10 = undefined;
    const v12 = v6.split(v8, 6);
    let v15 = 0;
    let v17 = 0;
    let v23 = 0;
    const v24 = v23 + 1;
    v23 = v24;
    const v25 = v17 + 1;
    v17 = v25;
}
main();