function main() {
    try {
        const v2 = [
            13.37,
            13.37,
            13.37,
            13.37,
            13.37
        ];
        const v3 = [];
        let v4 = v3;
        function v5(v6, v7) {
            const v9 = [
                13.37,
                13.37,
                13.37,
                13.37,
                13.37
            ];
            const v11 = v5(Symbol);
        }
        const v15 = [];
        let v16 = v15;
        const v17 = v5(...v16, v4, ...v2, 1337, 13.37);
    } catch (v18) {
    }
}
main();