function main() {
    const v2 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v3 = [];
    let v4 = v3;
    function v5(v6, v7) {
        let v10 = 0;
        while (v10 < 10) {
            function v12(v13, v14) {
                const v15 = {
                    ownKeys: Boolean,
                    apply: v14,
                    setPrototypeOf: v6,
                    set: v14,
                    deleteProperty: v13,
                    preventExtensions: v5
                };
            }
            const v21 = Object.freeze(arguments);
            const v22 = v10 + 1;
            v10 = v22;
        }
    }
    const v23 = [];
    let v24 = v23;
    const v25 = v5(...v24, v4, ...v2, 10, 13.37);
}
main();