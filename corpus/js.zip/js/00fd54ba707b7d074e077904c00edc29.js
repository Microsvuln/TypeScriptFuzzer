try {
    var __num = 11.001002;
    var PyeA = __num.toString(__num);
    var ZTZe = __num.toExponential(__num);
    var AkBW = __num.toPrecision(__num);
    var tpWc = __num.toExponential(__num);
    var MPKY = __num.toExponential(__num);
    var Pfma = __num.valueOf();
    var HwxR = new Uint8Array([
        Pfma,
        tpWc,
        AkBW.length,
        -Infinity,
        -4294967296,
        MPKY
    ]);
    Number.prototype.substring = String.prototype.substring;
    if (__num.substring() !== '11.001002') {
        testFailed('#1: var __num = 11.001002; Number.prototype.substring = String.prototype.substring; __num.substring()==="11.001002". Actual: ' + __num.substring());
        var DyHc = new WeakSet([
            [],
            [
                4,
                0,
                -4294967295,
                1200,
                0.1,
                -9007199254740990,
                3.141592653589793
            ]
        ]);
    }
} catch (ex) {
    sputnikException = ex;
}
var successfullyParsed = true;