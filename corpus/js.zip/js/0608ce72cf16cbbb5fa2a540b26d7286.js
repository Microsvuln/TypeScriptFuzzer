function main() {
    const v6 = [
        13.37,
        13.37
    ];
    let v10 = 0;
    while (v10 < 10) {
        const v17 = [
            13.37,
            13.37,
            13.37,
            13.37,
            13.37
        ];
        const v18 = [];
        let v19 = v18;
        function v20(v21, v22) {
            let v41 = 0;
            const v52 = [];
            let v53 = v52;
            let v61 = 0;
            const v62 = v61 + 1;
            v61 = v62;
            for (let v89 = 0; v89 < 8; v89++) {
                const v92 = v6.push(5, Boolean, 7, v89, isNaN);
                v52.__proto__ = v18;
                const v93 = v53.__proto__;
            }
        }
        const v97 = [];
        let v98 = v97;
        const v99 = v20(...v98, v19, ...v17, 10, 13.37);
        const v102 = v10 + 1;
        v10 = v102;
    }
}
main();