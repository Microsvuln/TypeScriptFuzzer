var e = 'e', f = 'f', g = 'g';
var RdkR = +4294967296;
var w6dc = - -Infinity;
var BwBA = ~759250124;
var hzWc = -3;
var txXj = +2147483648;
function foo(o) {
}
var CBmd = foo(o);
foo(-9007199254740991);
foo(-9007199254740990);
var YGNb = foo(0);
foo(g.length);
var eQZZ = foo(-2147483649);
var rCZD = foo(o);
foo(153);
var tpsy = foo(o);
function bar(func, o) {
    var Mxdc = !9007199254740991;
    var yWAr = foo(10000);
    var xiGs = foo(2147483647);
    var adrN = foo(3);
    var FXTh = foo(o);
    var fRWD = new WeakSet([
        [1200],
        [
            1.3,
            2147483647,
            0.1,
            9007199254740991,
            9007199254740992,
            673720360,
            -4294967295
        ]
    ]);
    var DQNE = foo(o);
    var znjA = foo(o);
    var bwah = foo(3.141592653589793);
    var baAA = foo(o);
    var SdnS = foo(2147483649);
}
for (var i = 0; i < 1000; ++i) {
    var o = {};
    var HtMi = foo(o);
    var kmZT = foo(o);
    foo(o);
    var Kz7X = +-4294967296;
    foo(o);
    var EcXZ = foo(-Infinity);
    var Swft = - -4294967297;
    foo(o);
    foo(o);
    var NPNm = foo(1.7976931348623157e+308);
    var tSzR = new Uint8Array([]);
    o['i' + i] = 42;
    var EnmX = new Uint16Array([Kz7X]);
    var twXt = 9007199254740994 != -2147483648;
    var xkMC = new Int16Array([
        -1.7976931348623157e+308,
        2147483647,
        w6dc,
        f['0'],
        1e-15,
        1518500249,
        1e+81,
        9007199254740990,
        RdkR
    ]);
    var eCEx = foo(o);
    var TWmE = new ArrayBuffer(xkMC['3']);
    nrs6 = BwBA.valueOf();
    var GxCE = foo(o);
    var pDNZ = foo(o);
    var WRMw = foo(o);
    var mwWk = foo(o);
    var Nxmf;
    var THcX = foo(o);
    var XKRT = new WeakSet([
        [
            g.length,
            BwBA,
            RdkR,
            9007199254740994,
            Kz7X,
            g.length,
            Swft,
            1518500249,
            g.length
        ],
        [
            759250124,
            10000,
            1e-81
        ]
    ]);
    var TQZM = new ArrayBuffer(xkMC);
    var ywrX = foo(o);
    f = new Int16Array([Swft]);
    pH3Q = new Int16Array([]);
    console = new Map([
        [
            9007199254740991,
            5e-324,
            e.length,
            9007199254740992,
            -9007199254740991,
            nrs6,
            5e-324,
            3.141592653589793
        ],
        [
            3.141592653589793,
            pH3Q,
            f,
            i,
            pH3Q,
            g,
            9007199254740991,
            f,
            i
        ]
    ]);
    foo(o);
    var nrs6 = - -9007199254740991;
    var pH3Q = !4294967296;
}
for (var i = 0; i < 100; ++i) {
    var TfAQ = +9007199254740992;
}
var HNje = +-9007199254740992;