function main() {
    let v4 = 0;
    do {
        const v7 = [
            13.37,
            13.37,
            13.37,
            13.37,
            13.37
        ];
        function v9(v10, v11) {
            function v12(v13, v14) {
                Array[-651804911] = 9007199254740991;
                let v16 = 0;
                function v17(v18, v19) {
                    v16 = v19;
                }
            }
            const v20 = v12();
            const v23 = new Uint32Array(11105);
            for (const v24 of v23) {
            }
        }
        const v25 = [];
        let v26 = v25;
        const v27 = v9(...v26, 13.37, ...v7, 10, 13.37);
        const v28 = v4 + 1;
        v4 = v28;
    } while (v4 < 10);
}
main();