function main() {
    const v2 = [
        2.220446049250313e-16,
        2.220446049250313e-16,
        2.220446049250313e-16,
        2.220446049250313e-16,
        2.220446049250313e-16
    ];
    const v3 = [];
    let v4 = v3;
    function v5(v6, v7) {
        const v9 = -Infinity;
        const v10 = [
            v9,
            v9,
            v9,
            v9,
            2.220446049250313e-16
        ];
        const v11 = [];
        let v12 = v11;
        function v13(v14, v15) {
            const v18 = [13.37];
            for (let v22 = 0; v22 < 100; v22++) {
                const v26 = { __proto__: -4294967296 };
                const v27 = {
                    valueOf: 'size',
                    b: eval,
                    constructor: v26,
                    toString: v18,
                    d: eval
                };
                let v28 = v27;
                const v31 = [
                    13.37,
                    13.37,
                    13.37,
                    v28,
                    13.37
                ];
                let v32 = eval;
                function v33(v34, v35) {
                    try {
                        const v40 = [
                            9,
                            10
                        ];
                        let v41 = String;
                        const v43 = v41.fromCharCode(10, v22, 37438.65257969173, 10, v40);
                        const v44 = v34(v43);
                    } catch (v45) {
                    }
                }
                const v46 = [];
                let v47 = v46;
                const v48 = v33(...v47, v32, ...v31, 65537, 13.37);
                for (let v52 = 0; v52 < 100; v52++) {
                    const v53 = v33(Number, -4294967296);
                }
            }
        }
        const v54 = [];
        let v55 = v54;
        const v56 = v13(...v55, v12, ...v10, 10, v9);
    }
    const v57 = [];
    let v58 = v57;
    const v59 = v5(v58, v4, ...v2, 1337, 2.220446049250313e-16);
}
main();