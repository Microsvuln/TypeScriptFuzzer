var isort = function (arr) {
    var count = arr.length;
    for (var i = 1; i <= count; i++) {
        var j = i;
        var tmp = arr[i];
        while (arr[j] >= 0 && arr[j - 1] > arr[j]) {
            arr[j] = arr[j - 1];
            arr[j - 1] = tmp;
            j--;
        }
    }
    return arr;
};
var unsorted = [
    3,
    2,
    4,
    5,
    1,
    8,
    11,
    0
];
var sorted = isort(unsorted);