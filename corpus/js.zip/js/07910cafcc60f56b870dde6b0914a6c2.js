function main() {
    const v4 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v6 = [
        1337,
        1337,
        1337
    ];
    const v7 = [
        v6,
        -2147483647,
        Boolean
    ];
    const v8 = {
        e: v6,
        valueOf: v4,
        b: 1337,
        toString: v4
    };
    const v9 = {
        b: v4,
        d: 1337,
        c: 'LJY0iNfVol'
    };
    let v10 = 1337;
    const v14 = [
        13.37,
        13.37,
        13.37
    ];
    const v16 = {
        get: Boolean,
        set: Boolean
    };
    const v18 = Object.defineProperty(v14, 1000, v16);
    let v21 = 0;
    while (v21 < 10) {
        const v24 = new Uint8ClampedArray(28825);
        const v25 = v21 + 1;
        v24.valueOf = Boolean;
        const v28 = new Uint8Array(11235);
        const v30 = Symbol.split;
        v30[v30] = v6;
        let v33 = 0;
        const v34 = v33 + 1;
        v33 = v34;
        v21 = v25;
    }
    const v36 = [
        5,
        1337
    ];
    const v37 = {
        b: WeakSet,
        __proto__: 13.37,
        constructor: v14,
        a: WeakSet,
        d: WeakSet,
        length: WeakSet
    };
    const v38 = [
        1337,
        v36,
        WeakSet,
        v37
    ];
    v38[v37] = v36;
    const v39 = v36['LJY0iNfVol'];
    v14[11235] = v37;
    const v41 = v38.reverse();
    const v48 = [1337];
    function v49(v50, v51) {
        const v53 = typeof v50;
        for (const v54 in v9) {
            const v55 = v48.sort(v39);
        }
        v36.constructor = v51;
        let v56 = undefined;
        if (v39) {
            delete v36.length;
            v56 = v16;
        } else {
            const v58 = [1337];
            v56 = Boolean;
        }
        const v59 = Symbol[7];
        const v61 = v53 === 'number';
        const v62 = v38[-1];
        v51.a = '__proto__';
        v6[Symbol] = v51;
        v50.a = v50;
        v50.d = v61;
        const v63 = Symbol[10000];
        const v64 = Symbol.replace;
        return Symbol;
    }
    let v67 = 0;
    while (v67 < 10) {
        v10 = 0;
        let v69 = 1337;
        const v70 = 0 | v69;
        v9[v10] = 0;
        v69 = 0;
        function v71(v72, v73) {
            let v76 = 0;
            while (v76 < 0) {
                for (const v77 in v8) {
                    v69 = 'LJY0iNfVol';
                }
                const v78 = v76 + 1;
            }
        }
        v69 = 0;
        delete v16[-65537];
        const v79 = 0 + v9;
        let v82 = 0;
        while (v82 < 5) {
            const v84 = v82 + 1;
            v82 = v84;
        }
        for (let v88 = 0; v88 < 100; v88++) {
            const v89 = v49(v48, '__proto__');
        }
        const v91 = v67 + 1;
        v67 = v91;
    }
}
main();