function main() {
    const v26 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v27 = [];
    let v28 = v27;
    function v29(v30, v31) {
    }
    const v62 = [];
    let v63 = v62;
    const v65 = v29(...v63, v28, ...v26, 10, 13.37);
    const v83 = new Float32Array(v65);
    for (let v97 = 0; v97 < 7; v97++) {
        with (v83) {
            for (const v104 of 'p76QI.ipnu') {
                const v110 = [
                    13.37,
                    13.37,
                    13.37,
                    13.37,
                    13.37
                ];
                const v111 = [];
                let v112 = v111;
                function v113(v114, v115) {
                    eval.toString = Object;
                    const v119 = [
                        13.37,
                        13.37,
                        13.37,
                        13.37,
                        13.37
                    ];
                    const v122 = new Proxy(Symbol, v119);
                    v122.valueOf = Symbol;
                    const v125 = [
                        -675673.488005732,
                        -675673.488005732,
                        -675673.488005732,
                        -675673.488005732
                    ];
                    const v127 = Math.pow(1337, v125);
                    let v138 = 0;
                    while (v138 < 10) {
                        for (let v142 = 0; v142 < 8; v142++) {
                        }
                        const v145 = v138 + 1;
                        v138 = v145;
                    }
                }
                const v146 = [];
                let v147 = v146;
                const v148 = v113(...v147, v112, ...v110, 10, 13.37);
            }
        }
    }
}
main();