var ChorusAds = ChorusAds || {};
ChorusAds.recorded_slots = [
    {
        'name': 'cfa_athena',
        'sizes': [[
                1030,
                590
            ]],
        'context': {
            'device_type': null,
            'browser_width': {
                'min': 0,
                'max': 0
            }
        }
    },
    {
        'name': 'reskin',
        'sizes': [[
                2,
                2
            ]],
        'context': {
            'device_type': ['desktop'],
            'browser_width': {
                'min': '881',
                'max': 0
            }
        }
    },
    {
        'name': 'cfa_cardstack_interstitial',
        'sizes': [[
                1400,
                900
            ]],
        'context': {
            'device_type': null,
            'browser_width': {
                'min': 0,
                'max': 0
            }
        }
    },
    {
        'name': 'cfa_maps',
        'sizes': [[
                300,
                250
            ]],
        'context': {
            'device_type': null,
            'browser_width': {
                'min': 0,
                'max': 0
            }
        }
    },
    {
        'name': 'cfa_cardstack_mobile_leaderboard',
        'sizes': [[
                320,
                50
            ]],
        'context': {
            'device_type': null,
            'browser_width': {
                'min': 0,
                'max': 0
            }
        }
    },
    {
        'name': 'cfa_cardstack_leaderboard',
        'sizes': [[
                728,
                90
            ]],
        'context': {
            'device_type': null,
            'browser_width': {
                'min': 0,
                'max': 0
            }
        }
    },
    {
        'name': 'prelude_front_page',
        'sizes': [[
                1400,
                600
            ]],
        'context': {
            'device_type': ['desktop'],
            'browser_width': {
                'min': '881',
                'max': 0
            }
        }
    },
    {
        'name': 'prelude',
        'sizes': [[
                1400,
                600
            ]],
        'context': {
            'device_type': ['desktop'],
            'browser_width': {
                'min': '881',
                'max': 0
            }
        }
    },
    {
        'name': 'desktop_leaderboard_variable',
        'sizes': [
            [
                728,
                90
            ],
            [
                970,
                250
            ],
            [
                970,
                90
            ],
            [
                1020,
                90
            ]
        ],
        'context': {
            'device_type': ['desktop'],
            'browser_width': {
                'min': '881',
                'max': 0
            }
        }
    },
    {
        'name': 'tablet_leaderboard',
        'sizes': [[
                728,
                90
            ]],
        'context': {
            'device_type': ['tablet'],
            'browser_width': {
                'min': '601',
                'max': 0
            }
        }
    },
    {
        'name': 'mobile_leaderboard',
        'sizes': [
            [
                320,
                50
            ],
            [
                300,
                250
            ]
        ],
        'context': {
            'device_type': ['mobile'],
            'browser_width': {
                'min': '0',
                'max': '728'
            }
        }
    },
    {
        'name': 'mobile_med_rec_athena',
        'sizes': [
            [
                300,
                250
            ],
            [
                1030,
                590
            ],
            [
                300,
                265
            ]
        ],
        'context': {
            'device_type': ['mobile'],
            'browser_width': {
                'min': '0',
                'max': '728'
            }
        }
    },
    {
        'name': 'mobile_footer',
        'sizes': [
            [
                320,
                50
            ],
            [
                300,
                250
            ]
        ],
        'context': {
            'device_type': ['mobile'],
            'browser_width': {
                'min': '0',
                'max': '728'
            }
        }
    },
    {
        'name': 'mobile_article_body',
        'sizes': [
            [
                300,
                250
            ],
            [
                1030,
                590
            ],
            [
                300,
                265
            ]
        ],
        'context': {
            'device_type': ['mobile'],
            'browser_width': {
                'min': '0',
                'max': '600'
            }
        }
    },
    {
        'name': 'btf_leaderboard_variable',
        'sizes': [
            [
                728,
                90
            ],
            [
                1020,
                90
            ]
        ],
        'context': {
            'device_type': ['desktop'],
            'browser_width': {
                'min': '881',
                'max': 0
            }
        }
    },
    {
        'name': 'tablet_btf_leaderboard',
        'sizes': [[
                728,
                90
            ]],
        'context': {
            'device_type': ['tablet'],
            'browser_width': {
                'min': '601',
                'max': 0
            }
        }
    },
    {
        'name': 'medium_rectangle_variable',
        'sizes': [
            [
                300,
                250
            ],
            [
                300,
                600
            ]
        ],
        'context': {
            'device_type': ['desktop'],
            'browser_width': {
                'min': '0',
                'max': 0
            }
        }
    },
    {
        'name': 'btf_medium_rectangle_variable',
        'sizes': [[
                300,
                250
            ]],
        'context': {
            'device_type': ['desktop'],
            'browser_width': {
                'min': '0',
                'max': 0
            }
        }
    },
    {
        'name': 'tablet_medium_rectangle',
        'sizes': [[
                300,
                250
            ]],
        'context': {
            'device_type': ['tablet'],
            'browser_width': {
                'min': '601',
                'max': 0
            }
        }
    },
    {
        'name': 'btf_tablet_medium_rectangle',
        'sizes': [[
                300,
                250
            ]],
        'context': {
            'device_type': ['tablet'],
            'browser_width': {
                'min': '601',
                'max': 0
            }
        }
    },
    {
        'name': 'athena',
        'sizes': [
            [
                1030,
                590
            ],
            [
                970,
                250
            ]
        ],
        'context': {
            'device_type': ['desktop'],
            'browser_width': {
                'min': '601',
                'max': 0
            }
        }
    },
    {
        'name': 'tablet_athena',
        'sizes': [[
                1030,
                590
            ]],
        'context': {
            'device_type': ['tablet'],
            'browser_width': {
                'min': '0',
                'max': 0
            }
        }
    },
    {
        'name': 'native_ad_video',
        'sizes': [[
                200,
                200
            ]],
        'context': {
            'device_type': null,
            'browser_width': {
                'min': 0,
                'max': 0
            }
        }
    },
    {
        'name': 'native_ad_latest',
        'sizes': [[
                300,
                100
            ]],
        'context': {
            'device_type': [
                'desktop',
                'tablet',
                'mobile'
            ],
            'browser_width': {
                'min': '0',
                'max': 0
            }
        }
    },
    {
        'name': 'native_ad_content_link',
        'sizes': [[
                650,
                150
            ]],
        'context': {
            'device_type': [
                'desktop',
                'tablet',
                'mobile'
            ],
            'browser_width': {
                'min': '0',
                'max': 0
            }
        }
    },
    {
        'name': 'native_ad_mobile',
        'sizes': [[
                300,
                265
            ]],
        'context': {
            'device_type': ['mobile'],
            'browser_width': {
                'min': '0',
                'max': 0
            }
        }
    },
    {
        'name': 'native_ad_linkset_link',
        'sizes': [[
                1200,
                100
            ]],
        'context': {
            'device_type': [
                'desktop',
                'tablet',
                'mobile'
            ],
            'browser_width': {
                'min': '0',
                'max': 0
            }
        }
    },
    {
        'name': 'in_map',
        'sizes': [[
                300,
                250
            ]],
        'context': {
            'device_type': null,
            'browser_width': {
                'min': '0',
                'max': 0
            }
        }
    }
];
var ChorusAds = ChorusAds || {}, googletag = googletag || {};
googletag.cmd = googletag.cmd || [], ChorusAds.log = function (e) {
}, ChorusAds.Technorati = {
    enabled: 'undefined' != typeof TN8 && TN8.SmartWrapper,
    attachSlot: function (e, o) {
        try {
        } catch (t) {
            ChorusAds.log(t);
        }
    }
}, ChorusAds.Campaigns = {};
var SBN = SBN || {};
SBN.Campaigns = SBN.Campaigns || {}, SBN.Campaigns.Components = {}, function (e, o) {
}(ChorusAds.Campaigns, SBN.Campaigns.Components);
var amznads = amznads || {};
