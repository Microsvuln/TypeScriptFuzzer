;
(function () {
    'use strict';
    var message = {
        true: 'yes',
        false: 'no'
    };
    function alertIsMozilla() {
    }
    alertIsMozilla();
}());