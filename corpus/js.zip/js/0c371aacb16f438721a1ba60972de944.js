function main() {
    const v2 = [
        13.37,
        13.37,
        13.37,
        13.37
    ];
    v2[1024] = Math;
    const v10 = new Float32Array(v2);
}
main();