var app = {
    pi: Math.PI,
    r: Math.random,
    m: Math,
    init: function () {
        var self = this;
        this.count = 0;
        self.factor = 1;
        self.iter = self.osc(1, 10, 0.01);
        this.reset();
    },
    reset: function () {
        var self = this;
        self.paths = [];
        for (var i = 0; i < 1200; i++) {
            if (i % 50 == 1) {
                var x = this.r() * self.width;
            }
            self.paths.push();
        }
        ;
    },
    clear: function () {
        var self = this;
    },
    fade: function () {
        var self = this;
        this.ctx.fillStyle = 'rgba(255,255,255,0.01)';
        self.ctx.fill();
    },
    draw: function () {
        var self = app;
        self.factor = self.iter();
        for (var i = 0; i < self.paths.length; i++) {
            self.paths[i].updatePosition();
        }
        ;
    },
    osc: function (low, high, inc) {
        if (low > high || inc < 0 || 2 * (high - low) < inc)
            return function () {
                return NaN;
            };
        var curr = low;
        return function () {
            var ret = curr;
            curr += inc;
            if (curr > high || curr < low) {
                curr = inc > 0 ? 2 * high - curr : 2 * low - curr;
                inc = -inc;
            }
            ;
            return app.roundNumber(ret, 2);
        };
    },
    roundNumber: function (number, decimals) {
        if (!decimals) {
            decimals = 0;
        }
        ;
        var newnumber = new Number(number + '').toFixed(parseInt(decimals));
        return parseFloat(newnumber);
    }
};
function Path(startX, startY) {
    var a = app;
    var ctx = a.$obj[0].getContext('2d');
    var that = this;
    var opacity = a.roundNumber(a.r() * 0.5, 1);
    var red = a.r() * 256 << 0;
    var green = 0;
    var blue = 0;
    var width = a.roundNumber(a.r() * 2, 2);
    var lastaction = 'arc';
    var angle = a.r() * 2 * Math.PI;
    var distance = 0;
    var direction = 1;
    var lastdata = {};
    ctx.save();
    this.updatePosition = function () {
        lastaction = lastaction == 'arc' ? 'line' : 'arc';
        direction = direction > 0 ? -1 : 1;
        switch (lastaction) {
        case 'arc':
        case 'line':
            dist = app.r() * 12 << 0;
            angle = a.r() * 360 << 0;
            angle = this.getAngle();
            var coords = {
                x: dist * Math.cos(angle),
                y: dist * Math.sin(angle)
            };
            ctx.beginPath();
            ctx.moveTo(startX, startY);
            ctx.strokeStyle = 'rgba(' + red + ',' + green + ',' + blue + ',' + opacity + ')';
            ctx.lineWidth = width;
            ctx.stroke();
            distance += dist;
            lastdata.coords = coords;
            lastdata.angle = angle;
            startX = startX + coords.x;
            break;
        }
        return lastaction;
    };
    this.getAngle = function () {
        return direction * (a.roundNumber(a.r() * 2, 2) * Math.PI);
    };
    return that;
}
app.init();