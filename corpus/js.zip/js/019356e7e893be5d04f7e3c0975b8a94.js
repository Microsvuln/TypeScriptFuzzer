function main() {
    const v2 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v3 = [];
    let v4 = v3;
    function v5(v6, v7) {
        const v11 = typeof '3RRchelia0';
        const v13 = v11 === 'name';
        const v14 = v13 + 1;
        let v15 = 0;
        while (v15 < 10) {
            function v18(v19, v20, v21, v22, v23) {
                return v18;
            }
            for (let v25 = 0; v25 < 256; v25++) {
                for (let v29 = 0; v29 < 256; v29++) {
                }
            }
            const v30 = v15 + 1;
            v15 = v30;
        }
    }
    const v31 = [];
    let v32 = v31;
    const v33 = v5(...v32, v4, ...v2, 10, 13.37);
}
main();