function main() {
    const v1 = Math.trunc(Math);
}
main();