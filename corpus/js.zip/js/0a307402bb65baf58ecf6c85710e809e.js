;
var toStringingObj = {
    toString: function () {
        return 'A string';
    }
};
var throwingObj = {
    toString: function () {
        throw 'Error';
    }
};
var aDate = new Date(441532800000);
var throwingSequence = {
    length: 4,
    0: 'hello',
    3: 'world'
};
Object.defineProperty(throwingSequence, '1', {
    get: function () {
        throw new Error('Misbehaving property');
    },
    enumerable: true,
    configurable: true
});
Object.defineProperty(throwingSequence, '2', {
    get: function () {
        throw new Error('This should not be thrown');
    },
    enumerable: true,
    configurable: true
});