function main() {
    let v1 = 0;
    const v5 = [1337];
    const v6 = [];
    const v7 = {
        constructor: v6,
        d: parseInt,
        __proto__: v5,
        valueOf: 1782977947,
        e: v5
    };
    let v8 = v7;
    const v10 = [
        v1,
        1337,
        1337,
        1337,
        1337
    ];
    let v11 = v10;
    let v13 = v8;
    let v16 = 5;
    const v20 = JSON.stringify(v13, v11, v13);
    const v21 = JSON.parse(v20, v11);
}
main();