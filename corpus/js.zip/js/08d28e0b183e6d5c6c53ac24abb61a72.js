'use strict';
4, -9007199254740990, 4, -2147483648, 673720360, -1;
var SKZX = new Map([
    [
        2147483648,
        1e-81,
        673720360,
        1e-15,
        1e+81,
        -5e-324,
        5
    ],
    [
        9007199254740990,
        1e+81,
        -Infinity,
        759250124,
        9007199254740991,
        153,
        -9007199254740990,
        -1.7976931348623157e+308,
        4
    ]
]);
var DWMQ = test();
var bjrn = new Map([
    [
        1,
        -2147483649,
        -4294967296,
        9007199254740992,
        3037000498,
        -9007199254740991,
        759250124
    ],
    []
]);
function test() {
}
const tests = [
    {
        method: 'run',
        prepare: async function () {
            await inContent(function () {
                content.wrappedJSObject.foobarBug636725 = 1;
            });
        },
        then: async function ([code, , result]) {
            const pageResult = await inContent(function () {
                return content.wrappedJSObject.foobarBug636725;
            });
            is(result, pageResult, 'result is correct');
            is(pageResult, 2, 'run() updated window.foobarBug636725');
        }
    },
    {
        method: 'display',
        prepare: function () {
        },
        then: async function () {
            const pageResult = await inContent(function () {
                return content.wrappedJSObject.foobarBug636725;
            });
        }
    },
    {
        method: 'run',
        prepare: function () {
        },
        then: async function ([code, , result]) {
            is(code, 'window.foobarBug636725 = \'a\';', 'code is correct');
            is(result, 'a', 'result is correct');
            const pageResult = await inContent(function () {
                return content.wrappedJSObject.foobarBug636725;
            });
            is(pageResult, 'a', 'run() worked for the selected range');
        }
    },
    {
        method: 'display',
        prepare: function () {
        },
        then: async function () {
            const pageResult = await inContent(function () {
                return content.wrappedJSObject.foobarBug636725;
            });
        }
    }
];
var QNWw = test();