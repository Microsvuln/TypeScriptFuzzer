function main() {
    try {
        const v2 = [
            13.37,
            13.37,
            13.37,
            13.37,
            13.37
        ];
        const v3 = [];
        let v4 = v3;
        function v5(v6, v7) {
            v2.toString = v5;
            const v11 = '78Nn4hCo7P'.__proto__;
            const v12 = v11.codePointAt(arguments, -65537);
            const v15 = [
                13.37,
                13.37,
                13.37,
                13.37,
                13.37
            ];
            const v16 = [];
            let v17 = v16;
            function v18(v19, v20) {
                const v22 = -9007199254740991 << v2;
            }
            const v23 = [];
            let v24 = v23;
            const v25 = v18(...v24, v17, ...v15, 10, 13.37);
        }
        const v26 = [];
        let v27 = v26;
        const v28 = v5(...v27, v4, ...v2, -2147483649, 13.37);
    } catch (v29) {
    }
}
main();