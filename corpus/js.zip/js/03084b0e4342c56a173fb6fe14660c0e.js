function main() {
    const v2 = [
        Map,
        Map,
        1337
    ];
    const v5 = [
        1,
        1,
        1,
        1,
        1
    ];
    const v6 = [];
    let v7 = v2;
    function v8(v9, v10) {
        try {
            const v11 = v8();
        } catch (v12) {
            let v14 = v12;
            const v16 = new Proxy(v14, Reflect);
            const v17 = v16 >> v6;
        }
    }
    let v18 = v7;
    const v19 = v8(v18, v7, ...v5, -258611160, 1);
}
main();