function main() {
    const v2 = [
        1337,
        1337,
        1337,
        1337
    ];
    for (let v6 = 0; v6 < 1337; v6++) {
        function v8(v9, v10) {
            const v12 = Math.fround(v10);
            const v13 = typeof 257;
            const v15 = v13 === 'object';
            let v16 = 1337;
            for (let v20 = 0; v20 < 10; v20++) {
            }
            const v21 = !v12;
            v16 = v21;
            'symbol'.b = v16;
            if (v9) {
            } else {
            }
        }
        const v22 = v2.map(v8);
    }
}
main();