function main() {
    let v1 = 13.37;
    const v4 = {
        toString: 13.37,
        d: 13.37,
        __proto__: 13.37,
        length: 13.37
    };
    const v10 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v11 = {};
    const v13 = 3357878976 > v11;
    let v16 = 0;
    const v17 = v16 + 1;
    v16 = v17;
    const v18 = [
        1337,
        1337,
        1337,
        1337,
        1337
    ];
    let v21 = 0;
    const v22 = v21 + 1;
    v21 = v22;
    let v25 = 0;
    const v26 = v25 + 1;
    v25 = v26;
    for (const v27 in v18) {
        for (const v28 in v4) {
            const v32 = v28 instanceof Proxy;
            if (v32) {
                const v33 = 13.37 instanceof v1;
            } else {
            }
        }
    }
    let v36 = 0;
    const v37 = v36 + 1;
    v36 = v37;
}
main();