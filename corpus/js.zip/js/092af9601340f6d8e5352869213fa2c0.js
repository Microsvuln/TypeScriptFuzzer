function main() {
    const v3 = [
        1337,
        1337
    ];
    const v6 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v7 = [];
    let v8 = v7;
    function v9(v10, v11) {
        try {
            const v12 = 13.37 in 10;
        } catch (v13) {
        }
        const v16 = v9.toLocaleString();
        const v17 = v16.replace(13.37, v16);
        const v18 = eval(v17);
        return v9;
    }
    const v19 = [];
    let v20 = v19;
    const v21 = v9(...v20, v8, ...v6, 10, 13.37);
    const v22 = v3.reduce(v21, v7);
    const v23 = v22(1000);
}
main();