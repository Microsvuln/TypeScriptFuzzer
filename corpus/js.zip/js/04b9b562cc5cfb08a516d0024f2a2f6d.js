'use strict';
function DateKeeper(props) {
    this.init(props);
}
{
    const DAYS_IN_A_WEEK = 7, MONTHS_IN_A_YEAR = 12, YEAR_VIEW_SIZE = 200, YEAR_BUFFER_SIZE = 10, MIN_DATE = -62135596800000, MAX_DATE = 8640000000000000, MAX_YEAR = 275760, MAX_MONTH = 9;
    DateKeeper.prototype = {
        get year() {
            return this.state.dateObj.getUTCFullYear();
        },
        get month() {
            return this.state.dateObj.getUTCMonth();
        },
        get selection() {
            return this.state.selection;
        },
        init({year, month, day, min, max, step, stepBase, firstDayOfWeek = 0, weekends = [0], calViewSize = 42}) {
            const today = new Date();
            this.state = {
                step,
                firstDayOfWeek,
                weekends,
                calViewSize,
                min: new Date(Number.isNaN(min) ? MIN_DATE : min),
                max: new Date(Number.isNaN(max) ? MAX_DATE : max),
                stepBase: new Date(stepBase),
                today: this._newUTCDate(today.getFullYear(), today.getMonth(), today.getDate()),
                weekHeaders: this._getWeekHeaders(firstDayOfWeek, weekends),
                years: [],
                dateObj: new Date(0),
                selection: {
                    year,
                    month,
                    day
                }
            };
            this.setCalendarMonth({
                year: year === undefined ? today.getFullYear() : year,
                month: month === undefined ? today.getMonth() : month
            });
        },
        setCalendarMonth({year = this.year, month = this.month}) {
            if (year > MAX_YEAR || year === MAX_YEAR && month >= MAX_MONTH) {
                this.state.dateObj.setUTCFullYear(MAX_YEAR, MAX_MONTH - 1, 1);
            } else if (year < 1 || year === 1 && month < 0) {
                this.state.dateObj.setUTCFullYear(1, 0, 1);
            } else {
                this.state.dateObj.setUTCFullYear(year, month, 1);
            }
        },
        setSelection({year, month, day}) {
            this.state.selection.year = year;
            this.state.selection.month = month;
            this.state.selection.day = day;
        },
        setMonth(month) {
            this.setCalendarMonth({
                year: this.year,
                month
            });
        },
        setYear(year) {
            this.setCalendarMonth({
                year,
                month: this.month
            });
        },
        setMonthByOffset(offset) {
            this.setCalendarMonth({
                year: this.year,
                month: this.month + offset
            });
        },
        getMonths() {
            let months = [];
            for (let i = 0; i < MONTHS_IN_A_YEAR; i++) {
                months.push({
                    value: i,
                    enabled: true
                });
            }
            return months;
        },
        getYears() {
            let years = [];
            const firstItem = this.state.years[0];
            const lastItem = this.state.years[this.state.years.length - 1];
            const currentYear = this.year;
            if (!firstItem || !lastItem || currentYear <= firstItem.value + YEAR_BUFFER_SIZE || currentYear >= lastItem.value - YEAR_BUFFER_SIZE) {
                for (let i = -(YEAR_VIEW_SIZE / 2); i < YEAR_VIEW_SIZE / 2; i++) {
                    const year = currentYear + i;
                    if (year >= 1 && year <= MAX_YEAR) {
                        years.push({
                            value: year,
                            enabled: true
                        });
                    }
                }
                this.state.years = years;
            }
            return this.state.years;
        },
        getDays() {
            const firstDayOfMonth = this._getFirstCalendarDate(this.state.dateObj, this.state.firstDayOfWeek);
            const month = this.month;
            let days = [];
            for (let i = 0; i < this.state.calViewSize; i++) {
                const dateObj = this._newUTCDate(firstDayOfMonth.getUTCFullYear(), firstDayOfMonth.getUTCMonth(), firstDayOfMonth.getUTCDate() + i);
                let classNames = [];
                let enabled = true;
                const isValid = dateObj.getTime() >= MIN_DATE && dateObj.getTime() <= MAX_DATE;
                if (!isValid) {
                    classNames.push('out-of-range');
                    enabled = false;
                    days.push({
                        classNames,
                        enabled
                    });
                    continue;
                }
                const isWeekend = this.state.weekends.includes(dateObj.getUTCDay());
                const isCurrentMonth = month == dateObj.getUTCMonth();
                const isSelection = this.state.selection.year == dateObj.getUTCFullYear() && this.state.selection.month == dateObj.getUTCMonth() && this.state.selection.day == dateObj.getUTCDate();
                const isOutOfRange = dateObj.getTime() < this.state.min.getTime() || dateObj.getTime() > this.state.max.getTime();
                const isToday = this.state.today.getTime() == dateObj.getTime();
                const isOffStep = this._checkIsOffStep(dateObj, this._newUTCDate(dateObj.getUTCFullYear(), dateObj.getUTCMonth(), dateObj.getUTCDate() + 1));
                if (isWeekend) {
                    classNames.push('weekend');
                }
                if (!isCurrentMonth) {
                    classNames.push('outside');
                }
                if (isSelection && !isOutOfRange && !isOffStep) {
                    classNames.push('selection');
                }
                if (isOutOfRange) {
                    classNames.push('out-of-range');
                    enabled = false;
                }
                if (isToday) {
                    classNames.push('today');
                }
                if (isOffStep) {
                    classNames.push('off-step');
                    enabled = false;
                }
                days.push({
                    dateObj,
                    content: dateObj.getUTCDate(),
                    classNames,
                    enabled
                });
            }
            return days;
        },
        _checkIsOffStep(start, next) {
            if (next - start >= this.state.step) {
                return false;
            }
            const lastValidStep = Math.floor((next - 1 - this.state.stepBase) / this.state.step);
            const lastValidTimeInMs = lastValidStep * this.state.step + this.state.stepBase.getTime();
            return lastValidTimeInMs < start.getTime();
        },
        _getWeekHeaders(firstDayOfWeek, weekends) {
            let headers = [];
            let dayOfWeek = firstDayOfWeek;
            for (let i = 0; i < DAYS_IN_A_WEEK; i++) {
                headers.push({
                    content: dayOfWeek % DAYS_IN_A_WEEK,
                    classNames: weekends.includes(dayOfWeek % DAYS_IN_A_WEEK) ? ['weekend'] : []
                });
                dayOfWeek++;
            }
            return headers;
        },
        _getFirstCalendarDate(dateObj, firstDayOfWeek) {
            const daysOffset = 1 - DAYS_IN_A_WEEK;
            let firstDayOfMonth = this._newUTCDate(dateObj.getUTCFullYear(), dateObj.getUTCMonth());
            let dayOfWeek = firstDayOfMonth.getUTCDay();
            return this._newUTCDate(firstDayOfMonth.getUTCFullYear(), firstDayOfMonth.getUTCMonth(), firstDayOfWeek == dayOfWeek ? daysOffset : (firstDayOfWeek - dayOfWeek + daysOffset) % DAYS_IN_A_WEEK);
        },
        _newUTCDate(...parts) {
            return new Date(new Date(0).setUTCFullYear(...parts));
        }
    };
}