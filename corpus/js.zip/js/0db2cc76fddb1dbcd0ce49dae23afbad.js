function main() {
    for (let v7 = 0; v7 < 100; v7++) {
        const v11 = [
            1337,
            13.37,
            13.37,
            13.37,
            13.37
        ];
        const v12 = [];
        let v13 = v12;
        function v14(v15, v16) {
            let v19 = 0;
            while (v19 < 10) {
                const v22 = [
                    13.37,
                    13.37,
                    13.37,
                    13.37,
                    13.37
                ];
                const v23 = [];
                let v24 = v23;
                function v25(v26, v27) {
                    const v31 = [
                        1337,
                        13.37,
                        13.37,
                        13.37,
                        13.37
                    ];
                    const v32 = [];
                    let v33 = v32;
                    function v34(v35, v36) {
                        for (const v38 in 0) {
                            with (v35) {
                            }
                            let v44 = 0;
                        }
                        const v46 = [v25];
                        let v47 = 13.37;
                        const v49 = new Set(v46);
                        const v50 = v49.add(v47);
                    }
                    const v51 = [];
                    let v52 = v51;
                    const v53 = v34(...v52, v33, ...v31, 10, 13.37);
                }
                const v54 = [];
                let v55 = v54;
                const v56 = v25(...v55, v24, ...v22, 10, 13.37);
                const v57 = v19 + 1;
                v19 = v57;
            }
        }
        const v58 = [];
        let v59 = v58;
        const v60 = v14(...v59, v13, ...v11, 10, 13.37);
    }
}
main();