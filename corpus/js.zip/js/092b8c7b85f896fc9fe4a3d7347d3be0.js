(function () {
    'use strict';
    let AsyncModule;
    class Debouncer {
        constructor() {
            this._asyncModule = null;
            this._callback = null;
            this._timer = null;
        }
        setConfig(asyncModule, cb) {
            this._asyncModule = asyncModule;
            this._callback = cb;
            this._timer = this._asyncModule.run(() => {
                this._timer = null;
                this._callback();
            });
        }
        cancel() {
            if (this.isActive()) {
                this._asyncModule.cancel(this._timer);
                this._timer = null;
            }
        }
        flush() {
            if (this.isActive()) {
                this.cancel();
                this._callback();
            }
        }
        isActive() {
            return this._timer != null;
        }
        static debounce(debouncer, asyncModule, cb) {
            if (debouncer instanceof Debouncer) {
                debouncer.cancel();
            } else {
                debouncer = new Debouncer();
            }
            debouncer.setConfig(asyncModule, cb);
            return debouncer;
        }
    }
}());