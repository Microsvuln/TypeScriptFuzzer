function main() {
    const v4 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v6 = [1337];
    const v7 = [];
    const v8 = {
        d: 'string',
        valueOf: 13.37
    };
    const v9 = { valueOf: v6 };
    let v10 = v8;
    for (let v18 = 0; v18 < 100; v18++) {
        const v19 = Symbol('string');
    }
    const v20 = 'string'.__proto__;
    Symbol.valueOf = Symbol;
    'string'.length = Symbol;
    for (let v24 = 0; v24 < 7; v24++) {
        for (let v28 = 0; v28 < 10; v28++) {
            const v29 = Symbol('string');
        }
    }
    const v30 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v32 = [
        1337,
        1337,
        1337,
        1337
    ];
    const v34 = 'split'.match;
    const v35 = [
        Symbol,
        1337,
        Symbol
    ];
    const v36 = {};
    const v37 = {
        toString: 13.37,
        valueOf: v32,
        b: v30,
        c: 'string'
    };
    let v38 = 13.37;
    const v41 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    let v43 = 0;
    const v44 = v43 + 1;
    v43 = v44;
    const v45 = [];
    let v46 = v45;
    const v47 = [
        13.37,
        v44
    ];
    v47.constructor = v45;
    const v48 = v45.__proto__;
    const v49 = v35.map(v34, v34);
    function v50(v51, v52) {
        const v57 = new Uint8ClampedArray('p76QI.ipnu');
        let v59 = 0;
        while (v59 < 10) {
            for (let v63 = 0; v63 < 8; v63++) {
                for (let v67 = 0; v67 < 5; v67 = v67 + 663632694) {
                    let v70 = 0;
                    while (v70 < 10) {
                        const v71 = v70 + 1;
                        v70 = v71;
                    }
                }
            }
            const v72 = v59 + 1;
            v59 = v72;
        }
        return v57;
    }
    const v73 = [];
    let v74 = v73;
    const v75 = v50(...v74, v46, ...v41, 10, 13.37);
}
main();