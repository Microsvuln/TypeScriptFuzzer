function ReadCookie(cookieName) {
        return '';
    var ind1 = theCookie.indexOf(';', ind);
    if (ind1 == -1)
        ind1 = theCookie.length;
    return unescape(theCookie.substring(ind + cookieName.length + 1, ind1));
}
function ReadZagi(zagiName) {
    var zagi = ReadCookie('zagi');
    var ind = zagi.indexOf(zagiName);
    if (ind == -1 || zagiName == '')
        return '';
    var ind1 = zagi.indexOf('&', ind);
    if (ind1 == -1)
        ind1 = zagi.length - 1;
    return zagi.substring(ind + zagiName.length + 1, ind1);
}
var zip = ReadZagi('zip_code');
var city = ReadZagi('city');
var state = ReadZagi('state');
var gender = ReadZagi('gender') == 'M' ? 'm' : ReadZagi('gender') == 'F' ? 'f' : '';
var subscribes = String(parseInt(ReadZagi('subscriber') || '0') > 0);
function AgeToRange(years_old) {
    if (isNaN(years_old)) {
        return '';
    }
    if (years_old < 13) {
        return '';
    } else if (years_old < 18) {
        return '13-17';
    } else if (years_old < 21) {
        return '18-20';
    } else if (years_old < 25) {
        return '21-24';
    } else if (years_old < 30) {
        return '25-29';
    } else if (years_old < 35) {
        return '30-34';
    } else if (years_old < 40) {
        return '35-39';
    } else if (years_old < 45) {
        return '40-44';
    } else if (years_old < 50) {
        return '45-49';
    } else if (years_old < 55) {
        return '50-54';
    } else if (years_old < 60) {
        return '55-59';
    } else if (years_old < 65) {
        return '60-64';
    }
    return '65plus';
}
var age_range = AgeToRange(ReadZagi('age'));
function IncToRange(inc) {
    var idx = 0;
    var numstr = '';
    for (idx = 0; idx < inc.length && inc[idx] != '+'; idx++)
        if (!isNaN(parseInt(inc[idx])))
            numstr += inc[idx];
    inc = parseInt(numstr);
    if (isNaN(inc)) {
        return '';
    } else if (inc <= 24999) {
        return 'less25000';
    } else if (inc <= 34999) {
        return '25000-34999';
    } else if (inc <= 49999) {
        return '35000-49999';
    } else if (inc <= 74999) {
        return '50000-74999';
    } else if (inc <= 99999) {
        return '75000-99999';
    } else if (inc <= 149999) {
        return '100000-149999';
    } else if (inc <= 249999) {
        return '150000-249999';
    } else if (inc >= 250000) {
        return '250000plus';
    }
}
var inc_range = IncToRange(ReadZagi('income'));
var _ord = _ord || Math.random() * 1000000000000000000;
var _tile_params = ';ord=' + _ord;
var _demo_params = '';
if (age_range)
    _demo_params += ';age=' + age_range;
if (gender)
    _demo_params += ';gender=' + gender;
if (inc_range)
    _demo_params += ';income=' + inc_range;
if (subscribes)
    _demo_params += ';sub=' + subscribes;
var yld_mgr = {
    place_ad_here: function () {
    }
};