function fileList($scope, $http, $sce) {
    $scope.root = location.hash ? location.hash.replace(/^\W/, '') : '.';
    $scope.setRoot = function (root, type) {
        var $root = root === '../' ? $scope.root.match(/^(.*?)(\/*[^\/]*)?$/)[1] : $scope.root + '/' + root;
        console.log($root);
        if (!type || type === 'folder') {
            $http.get($root + '/?type=json').success(function (files) {
                if (files instanceof Array) {
                    $scope.root = $root;
                    location.hash = '#' + $root.replace(/^\W/, '') + '/';
                    $scope.files = [{
                            name: '../',
                            type: 'folder'
                        }].concat(files.map(function (f) {
                        var t = f.match(/\.(\w+)$/) || [
                            0,
                            'folder'
                        ];
                        return {
                            name: f,
                            type: t[1],
                            txt: [
                                'html',
                                'js',
                                'css',
                                'md',
                                'log'
                            ].indexOf(t[1]) != -1,
                            img: [
                                '.jpg',
                                'gif',
                                'png',
                                'jepg',
                                'ico'
                            ].indexOf(t[1]) != -1
                        };
                    }));
                } else {
                    alert(files);
                }
            }).error(function (e) {
                alert('请求失败\uFF01 请重试');
            });
        } else {
            window.open($root);
        }
    };
    $scope.setRoot('../');
    $scope.showTxt = function (name) {
        $http.get($scope.root + '/' + name + '?handle=false&middleware=false').success(function (txt) {
            $http.post('/prettify', { code: txt }).success(function (res) {
                $scope.show = $sce.trustAsHtml(res.output + '<style>' + res.style + '</style>');
            });
        });
    };
    $scope.showImg = function (name) {
        $scope.show = $sce.trustAsHtml('<img src="' + $scope.root + '/' + name + '" alt="' + name + '" />');
    };
}