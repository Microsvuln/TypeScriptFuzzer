var 함수 = function () {
};
함수();