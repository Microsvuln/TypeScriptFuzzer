function main() {
    const v2 = [
        -441746.4139016614,
        -441746.4139016614,
        -441746.4139016614,
        -441746.4139016614,
        -441746.4139016614
    ];
    const v3 = [];
    let v4 = v3;
    function v5(v6, v7) {
        for (let v11 = 0; v11 < 100; v11++) {
            try {
                const v12 = [];
                let v14 = v11;
                const v17 = [
                    v11,
                    13.37,
                    13.37,
                    v14,
                    13.37
                ];
                let v18 = v11;
                function v19(v20, v21) {
                    let v24 = String;
                    const v25 = v24.fromCharCode(255, v11, 100, v6, v20);
                    const v26 = eval(v25);
                }
                let v27 = v12;
                const v28 = v19(...v27, v18, ...v17, 65537, 13.37);
            } catch (v29) {
            }
        }
        const v30 = [];
        let v31 = v30;
        const v32 = v31.__proto__;
    }
    const v33 = [];
    let v34 = v33;
    const v35 = v5(...v34, ...v4, ...v2, 1337, -441746.4139016614);
}
main();