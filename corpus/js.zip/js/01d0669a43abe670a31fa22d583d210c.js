function include(name, async) {
    async = async || false;
    var scripts = document.getElementById('scripts');
    var script = document.createElement('script');
    script.type = 'text/javascript';
    scripts.appendChild(script);
    remoteRequest({
        url: name + '?rnd=' + Date.parse(new Date()),
        success: changeContext(script, function (response) {
            try {
                eval(response.responseText);
                this.text = response.responseText;
            } catch (e) {
            }
            this.src = name;
        }),
        async: async
    });
}