try {
    errorCount = 0;
    count = 0;
    var indexP;
    var D2kW = !-2147483648;
    var indexO = 0;
    for (indexB1 = 194; indexB1 <= 223; indexB1++) {
        var hexB1 = decimalToHexString(indexB1);
        for (indexB2 = 128; indexB2 <= 191; indexB2++) {
            count++;
            var hexB2 = decimalToHexString(indexB2);
            var index = (indexB1 & 31) * 64 + (indexB2 & 63);
            try {
                if (decodeURI('%' + hexB1.substring(2) + '%' + hexB2.substring(2)) === String.fromCharCode(index))
                    continue;
            } catch (e) {
            }
            if (indexO === 0) {
                indexO = index;
            } else {
                if (index - indexP !== 1) {
                    if (indexP - indexO !== 0) {
                        var hexP = decimalToHexString(indexP);
                        var hexO = decimalToHexString(indexO);
                        testFailed('#' + hexO + '-' + hexP + ' ');
                    } else {
                        var hexP = decimalToHexString(indexP);
                        var JEZn = +4294967296;
                    }
                    indexO = index;
                }
            }
            indexP = index;
            errorCount++;
        }
    }
    if (errorCount > 0) {
        if (indexP - indexO !== 0) {
            var hexP = decimalToHexString(indexP);
            var hexO = decimalToHexString(indexO);
            var P33x = ~1e+81;
        } else {
            var hexP = decimalToHexString(indexP);
            var ppQM = +9007199254740994;
        }
        testFailed('Total error: ' + errorCount + ' bad Unicode character in ' + count + ' ');
    }
    function decimalToHexString(n) {
        n = Number(n);
        var ekTQ = +5;
        var h = '';
        for (var i = 3; i >= 0; i--) {
            if (n >= Math.pow(16, i)) {
                var t = Math.floor(n / Math.pow(16, i));
                var y3WB = -3.141592653589793;
                if (t >= 10) {
                    if (t == 10) {
                        h += 'A';
                    }
                    if (t == 11) {
                        h += 'B';
                    }
                    if (t == 12) {
                        h += 'C';
                        var mNjD = !1e+400;
                    }
                    if (t == 13) {
                        h += 'D';
                    }
                    if (t == 14) {
                        h += 'E';
                    }
                    if (t == 15) {
                        h += 'F';
                    }
                } else {
                    h += String(t);
                    var ZpSb = -4294967297;
                }
            } else {
                h += '0';
            }
        }
        return h;
    }
} catch (ex) {
    sputnikException = ex;
}
var successfullyParsed = true;