function main() {
    const v2 = [
        212351.89858630486,
        9007199254740991
    ];
    const v3 = v2.toLocaleString();
    const v4 = v3.indexOf(v3, v3);
}
main();