function main() {
    const v4 = [
        -2,
        4294967295,
        4294967295,
        4294967295
    ];
    v4[1000] = 13.37;
    const v8 = new Int8Array(v4);
    const v9 = v8.sort('object', 2147483649);
}
main();