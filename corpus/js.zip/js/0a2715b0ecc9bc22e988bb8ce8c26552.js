function main() {
    for (let v6 = 0; v6 < 10; v6++) {
        const v11 = [
            13.37,
            13.37,
            13.37,
            13.37,
            13.37
        ];
        try {
            const v16 = [
                13.37,
                -1389891735,
                13.37,
                13.37,
                13.37
            ];
            const v17 = [];
            let v18 = v17;
            function v19(v20, v21) {
                const v23 = [
                    13.37,
                    13.37,
                    13.37,
                    13.37,
                    13.37
                ];
                const v26 = [
                    1337,
                    1337,
                    1337,
                    1337,
                    1337
                ];
                const v27 = {
                    b: 1337,
                    a: v26,
                    valueOf: 1337,
                    e: 1337,
                    d: Symbol
                };
                const v39 = {
                    setPrototypeOf: Symbol,
                    get: Function,
                    defineProperty: Symbol,
                    has: Symbol,
                    preventExtensions: Symbol,
                    construct: Symbol,
                    call: Symbol,
                    ownKeys: Symbol,
                    set: Symbol,
                    getPrototypeOf: Infinity,
                    apply: gc
                };
                const v41 = new Proxy(v27, v39);
                Symbol.__proto__ = v41;
            }
            const v42 = [];
            let v43 = v42;
            const v44 = v19(...v43, v18, ...v16, 1337, 13.37);
        } catch (v45) {
        }
        const v46 = [
            1337,
            1337,
            1337,
            1337,
            1337
        ];
        const v47 = {
            e: v46,
            length: 13.37,
            d: v46,
            __proto__: Symbol,
            valueOf: v11,
            c: 'p76QI.ipnu'
        };
        const v52 = 'arguments' in v47;
    }
    let v63 = -4096;
}
main();