function main() {
const v2 = {};
// v2 = .object(ofGroup: Object, withProperties: ["__proto__"])
let v3 = v2;
const v6 = new Int8Array(39929);
// v6 = .object(ofGroup: Int8Array, withProperties: ["byteLength", "buffer", "byteOffset", "length", "constructor", "__proto__"], withMethods: ["includes", "every", "reduceRight", "find", "findIndex", "slice", "indexOf", "set", "keys", "filter", "some", "copyWithin", "subarray", "reduce", "lastIndexOf", "fill", "join", "values", "map", "forEach", "entries", "sort", "reverse"])
const v8 = [1337,1337,1337,1337,1337];
// v8 = .object(ofGroup: Array, withProperties: ["__proto__", "constructor", "length"], withMethods: ["includes", "fill", "reduceRight", "join", "pop", "reduce", "reverse", "copyWithin", "sort", "some", "indexOf", "every", "flatMap", "filter", "map", "splice", "findIndex", "toString", "keys", "flat", "slice", "toLocaleString", "entries", "concat", "push", "unshift", "forEach", "shift", "find", "values", "lastIndexOf"])
const v10 = v6[v8];
// v10 = .unknown
const v11 = {construct:Object,preventExtensions:isFinite,ownKeys:Object,setPrototypeOf:v10};
// v11 = .object(ofGroup: Object, withProperties: ["__proto__", "setPrototypeOf"], withMethods: ["ownKeys", "construct", "preventExtensions"])
const v13 = new Proxy(v3,v11);
// v13 = .unknown
const v14 = {__proto__:v6,d:1337,b:v11,e:1337,...v11,...v11,...v13,...Proxy};
// v14 = .object(ofGroup: Object, withProperties: ["setPrototypeOf", "e", "d", "b", "__proto__"], withMethods: ["preventExtensions", "ownKeys", "construct"])
}
main();
