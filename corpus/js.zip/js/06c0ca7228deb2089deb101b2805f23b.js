function main() {
    const v4 = [-3179590583];
    for (let v8 = 0; v8 < 1000; v8++) {
        try {
            let v10 = Function;
            const v12 = [
                13.37,
                13.37,
                13.37,
                v10,
                13.37
            ];
            let v13 = v8;
            function v14(v15, v16) {
                let v18 = String;
                const v19 = v18.fromCharCode(v15, v8, 1337, v8, 1902352450);
                const v20 = v13[v8];
                const v21 = v10(...v19, v20);
            }
            let v22 = v4;
            const v23 = v14(v22, v13, ...v12, 1337, 13.37);
        } catch (v24) {
        }
    }
}
main();