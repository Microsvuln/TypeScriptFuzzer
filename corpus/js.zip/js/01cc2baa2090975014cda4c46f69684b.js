function main() {
    const v5 = [
        1337,
        1337,
        1337,
        1337
    ];
    const v6 = {
        c: 13.37,
        d: 1337,
        valueOf: 'byteLength'
    };
    const v7 = -Infinity;
    const v9 = [
        1337,
        1337
    ];
    const v12 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v13 = [];
    let v16 = 0;
    while (v16 < 9) {
        const v17 = v13.push(v7, 1337);
        const v18 = v16 + 1;
        v16 = v18;
    }
    let v19 = v13;
    function v20(v21, v22) {
        const v26 = [
            13.37,
            13.37,
            13.37,
            13.37,
            13.37
        ];
        let v29 = 0;
        do {
            const v30 = 13.37 + 1;
            v29 = v20;
            v13[4] = v30;
        } while (v29 < 10);
        const v31 = v20.toLocaleString();
        const v32 = v31.replace(13.37, v19);
        const v33 = eval(v32);
        return v20;
    }
    const v34 = [];
    let v35 = v34;
    const v36 = v20(...v35, v19, ...v12, 10, 13.37);
    const v37 = v9.reduce(v36, v13);
    const v38 = v37();
    const v40 = v38(Promise, v13, 0, 0, v6);
    let v43 = 0;
    do {
        for (let v47 = 0; v47 < 100; v47++) {
            const v48 = v40(v5, 13.37, 9);
        }
        const v49 = v43 + 1;
        v43 = v49;
    } while (v43 < 2);
}
main();