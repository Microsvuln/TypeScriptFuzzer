function main() {
    const v2 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v3 = [];
    let v4 = v3;
    function v5(v6, v7) {
        let v10 = 0;
        while (v10 < 10) {
            for (let v14 = 0; v14 < 8; v14++) {
                const v19 = [
                    13.37,
                    13.37,
                    13.37,
                    13.37,
                    13.37
                ];
                const v21 = [
                    1337,
                    1337,
                    1337,
                    1337,
                    1337
                ];
                const v22 = {
                    e: v19,
                    length: 13.37,
                    d: v21,
                    __proto__: Symbol,
                    valueOf: v19,
                    c: 'p76QI.ipnu'
                };
                const v27 = { set: Symbol };
                const v29 = Object.defineProperty(Symbol, 2365454094, v27);
                const v31 = Object.entries('p76QI.ipnu');
            }
            const v34 = v10 + 1;
            v10 = v34;
        }
    }
    const v35 = [];
    let v36 = v35;
    const v37 = v5(...v36, v4, ...v2, 10, 13.37);
}
main();