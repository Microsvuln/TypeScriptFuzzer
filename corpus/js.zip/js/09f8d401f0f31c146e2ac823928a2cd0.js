var flagActive = '002';
var flagArray = new Array();
flagArray['001'] = new Object();
flagArray['001']['img'] = 'fran';
flagArray['001']['caption'] = 'France';
flagArray['002'] = new Object();
flagArray['002']['img'] = 'germ';
flagArray['002']['caption'] = 'Germany';
flagArray['003'] = new Object();
flagArray['003']['img'] = 'ital';
flagArray['003']['caption'] = 'Italy';
flagArray['004'] = new Object();
flagArray['004']['img'] = 'scan';
flagArray['004']['caption'] = 'Scandinavia';
flagArray['005'] = new Object();
flagArray['005']['img'] = 'span';
flagArray['005']['caption'] = 'Spain';
flagArray['006'] = new Object();
flagArray['006']['img'] = 'uk';
flagArray['006']['caption'] = 'United Kingdom';
flagArray['007'] = new Object();
flagArray['007']['img'] = 'usa';
flagArray['007']['caption'] = 'USA';
for (var flagKey in flagArray) {
    var furtherOptions = new Object();
    furtherOptions['iconPrefix'] = flagArray[flagKey]['img'] + '_';
}