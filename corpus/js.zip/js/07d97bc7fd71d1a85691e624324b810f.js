function opt(arr, arr2) {
    arr2[0];
    arr[0] = 1.1;
    arr2.reverse();
    arr[0] = 2.3023e-320;
}
function main() {
    let arr = [
        1.1,
        2.2,
        3.3
    ];
    arr.__proto__ = null;
    delete arr[1];
    let arr2 = [
        ,
        {}
    ];
    var AaJ4 = +1e-81;
    var jdWj = !9007199254740990;
    for (let i = 0; i < 10000; i++) {
        opt(arr, arr2);
    }
    Array.prototype.sort.call(arr, () => {
        arr2.__proto__.__proto__ = arr;
    });
    opt(arr, arr2);
}
main();