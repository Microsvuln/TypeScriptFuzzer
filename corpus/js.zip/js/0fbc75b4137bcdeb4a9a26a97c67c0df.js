try {
    uriReserved = [
        ';',
        '/',
        '?',
        ':',
        '@',
        '&',
        '=',
        '+',
        '$',
        ','
    ];
    var K2kd = - -9007199254740992;
    uriReserved.unshift(4294967296, -9007199254740992, 1.7976931348623157e+308, 3);
    var DGzN = - -1.7976931348623157e+308;
    var AAAX = !NaN;
    uriUnescaped = [
        '-',
        '_',
        '.',
        '!',
        '~',
        '*',
        '\'',
        '(',
        ')',
        'A',
        'B',
        'C',
        'D',
        'E',
        'F',
        'G',
        'H',
        'I',
        'J',
        'K',
        'L',
        'M',
        'N',
        'O',
        'P',
        'Q',
        'R',
        'S',
        'T',
        'U',
        'V',
        'W',
        'X',
        'Y',
        'Z',
        'a',
        'b',
        'c',
        'd',
        'e',
        'f',
        'g',
        'h',
        'i',
        'j',
        'k',
        'l',
        'm',
        'n',
        'o',
        'p',
        'q',
        'r',
        's',
        't',
        'u',
        'v',
        'w',
        'x',
        'y',
        'z',
        '0',
        '1',
        '2',
        '3',
        '4',
        '5',
        '6',
        '7',
        '8',
        '9'
    ];
    uriUnescaped.push(0.1, -5e-324, 9007199254740991, -9007199254740990, -4294967297, -9007199254740991, 3, 2147483648, 1e+400, 1e+81, 3.141592653589793, 4294967296, 9007199254740994, -4294967295, -2147483649, 1.7976931348623157e+308, -1, -1, 9007199254740994, -5e-324, 673720360, 4294967295, -2147483647, NaN, -Infinity, -1, 1e-81, 1e-81, 42, 4294967295, 1.3, 3.141592653589793, 9007199254740994, 9007199254740991, -9007199254740992, 9007199254740991, 1e+400, 9007199254740991, 1e-81, 1200, -9007199254740994, 5e-324, 4294967296, 1e+400, 0, -1, 0, 4294967297, 9007199254740990, 1e-15, 0, 1e+81, 4294967297, 2147483648, -4294967295, NaN, 0.2, 759250124, 1.7976931348623157e+308, 9007199254740991, 0, 4, 1e+400, 1e-81, -9007199254740990, -1.7976931348623157e+308, 153, -4294967297, -1.7976931348623157e+308, 673720360, 673720360, 2147483648, 3.141592653589793, 4294967296, -1, 10000, -9007199254740991, -2147483647, 5e-324, 4294967297, 9007199254740991, 153, -9007199254740991, 42, 4294967297, -1, 10000, 4294967296, NaN, -9007199254740990, 5e-324, 3.141592653589793, -1.7976931348623157e+308, 4294967295, -9007199254740990, -1, 673720360, 2147483648, 759250124, -9007199254740991, NaN, 4294967296, -9007199254740991, 3.141592653589793, NaN, 0, -2147483647, -9007199254740991, 5e-324, 9007199254740990, 3037000498, 9007199254740991, 10000, 3, 153, 759250124, 42, 1200, -9007199254740991, 0, 9007199254740994);
    var M6J3 = +1200;
    var mQBX = ~4294967296;
    var NnPm = - -Infinity;
    var PAT4 = !1.3;
    errorCount = 0;
    var YFGi = !10000;
    var BAiY = +4294967296;
    var JjdY = ~42;
    count = 0;
    var indexP;
    var indexO = 0;
    l:
        for (index = 0; index <= 127; index++) {
            var HzDJ = !2147483647;
            HzDJ.toString(0, -9007199254740990, -Infinity);
            str = String.fromCharCode(index);
            var YXkk = +-2147483648;
            str.concat(-1, 1.3, -9007199254740992, 673720360, 1.7976931348623157e+308);
            var K7Rz = !3037000498;
            var Y8fM = -2147483648;
            for (indexC = 0; indexC < uriReserved.length; indexC++) {
                if (uriReserved[indexC] === str)
                    continue l;
            }
            for (indexC = 0; indexC < uriUnescaped.length; indexC++) {
                if (uriUnescaped[indexC] === str)
                    continue l;
            }
            if ('#' === str)
                continue l;
            try {
                if (encodeURI(str).toUpperCase() === '%' + decimalToHexString(index).substring(2))
                    continue l;
            } catch (e) {
            }
            if (indexO === 0) {
                indexO = index;
            } else {
                if (index - indexP !== 1) {
                    if (indexP - indexO !== 0) {
                        var hexP = decimalToHexString(indexP);
                        var hexO = decimalToHexString(indexO);
                        testFailed('#' + hexO + '-' + hexP + ' ');
                    } else {
                        var hexP = decimalToHexString(indexP);
                        testFailed('#' + hexP + ' ');
                    }
                    indexO = index;
                }
            }
            indexP = index;
            errorCount++;
        }
    if (errorCount > 0) {
        if (indexP - indexO !== 0) {
            var hexP = decimalToHexString(indexP);
            var hexO = decimalToHexString(indexO);
            testFailed('#' + hexO + '-' + hexP + ' ');
        } else {
            var hexP = decimalToHexString(indexP);
            testFailed('#' + hexP + ' ');
        }
        testFailed('Total error: ' + errorCount + ' bad Unicode character in ' + count + ' ');
    }
    function decimalToHexString(n) {
        n = Number(n);
        var h = '';
        for (var i = 3; i >= 0; i--) {
            if (n >= Math.pow(16, i)) {
                var t = Math.floor(n / Math.pow(16, i));
                n -= t * Math.pow(16, i);
                if (t >= 10) {
                    if (t == 10) {
                        h += 'A';
                    }
                    if (t == 11) {
                        h += 'B';
                    }
                    if (t == 12) {
                        h += 'C';
                    }
                    if (t == 13) {
                        h += 'D';
                    }
                    if (t == 14) {
                        h += 'E';
                    }
                    if (t == 15) {
                        h += 'F';
                    }
                } else {
                    h += String(t);
                }
            } else {
                h += '0';
            }
        }
        return h;
    }
} catch (ex) {
    sputnikException = ex;
}
var successfullyParsed = true;