var globals = [];
function onload() {
    var foo = { foo: 'foo' };
    var bar = { bar: 'bar' };
    bar.__proto__ = foo;
    var array = [
        'test',
        'test2'
    ];
    array.length = 10;
    array.foo = {};
    array[4] = 'test4';
    console.log(array);
    console.log('%o', array);
    console.log('%O', array);
    console.log('Test for zero "%f" in formatter', 0);
    var regex1 = /^url\(\s*(?:(?:"(?:[^\\\"]|(?:\\[\da-f]{1,6}\s?|\.))*"|'(?:[^\\\']|(?:\\[\da-f]{1,6}\s?|\.))*')|(?:[!#$%&*-~\w]|(?:\\[\da-f]{1,6}\s?|\.))*)\s*\)/i;
    var regex2 = new RegExp('foo\\\\bar\\sbaz', 'i');
    var str = 'test';
    var str2 = 'test named "test"';
    var error = new Error();
    var node = document.getElementById('p');
    var func = function () {
        return 1;
    };
    var multilinefunc = function () {
        return 2;
    };
    var num = 0.12;
    var linkify = 'http://webkit.org/';
    var valuelessAttribute = document.createAttribute('attr');
    var valuedAttribute = document.createAttribute('attr');
    valuedAttribute.value = 'value';
    var existingAttribute = document.getElementById('x').attributes[0];
    var throwingLengthGetter = {
        get length() {
            throw 'Length called';
        }
    };
    globals = [
        regex1,
        regex2,
        str,
        str2,
        error,
        node,
        func,
        multilinefunc,
        num,
        linkify,
        null,
        undefined,
        valuelessAttribute,
        valuedAttribute,
        existingAttribute,
        throwingLengthGetter,
        NaN,
        Number.POSITIVE_INFINITY,
        Number.NEGATIVE_INFINITY,
        array,
        {},
        [function () {
            }],
        bar
    ];
    runTest();
}
function log(current) {
    console.log(globals[current]);
    console.log([globals[current]]);
}
function test() {
    InspectorTest.evaluateInPage('globals.length', loopOverGlobals.bind(this, 0));
    function loopOverGlobals(current, total) {
        function advance() {
            var next = current + 1;
            if (next == total.description) {
                InspectorTest.expandConsoleMessages();
                InspectorTest.dumpConsoleMessages();
                InspectorTest.completeTest();
            } else
                loopOverGlobals(next, total);
        }
        InspectorTest.evaluateInPage('log(' + current + ')');
        InspectorTest.runAfterPendingDispatches(evalInConsole);
        function evalInConsole() {
            InspectorTest.evaluateInConsole('globals[' + current + ']');
            InspectorTest.runAfterPendingDispatches(advance);
        }
    }
}