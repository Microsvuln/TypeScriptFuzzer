try {
    var arr = /\s/.exec('\n');
    var tbMM = arr.toString(arr);
    var yYXF = arr.every(function () {
    }, -9007199254740994);
    var CRsW = arr.reduce(function () {
    }, arr.length);
    var YxaK = arr.reverse();
    if (arr === null || arr[0] !== '\n') {
        testFailed('#1: var arr = /\\s/.exec("\\u000A"); arr[0] === "\\u000A". Actual. ' + (arr && arr[0]));
    }
    var arr = /\s/.exec('\r');
    YxaK = YxaK.toString(arr.length, arr.length, arr.length);
    yYXF = YxaK.valueOf();
    YxaK = YxaK.includes(1.7976931348623157e+308, YxaK);
    if (arr === null || arr[0] !== '\r') {
        testFailed('#2: var arr = /\\s/.exec("\\u000D"); arr[0] === "\\u000D". Actual. ' + (arr && arr[0]));
    }
    var arr = /\s/.exec('\u2028');
    YxaK = YxaK.sort(function () {
    }, 1518500249);
    if (arr === null || arr[0] !== '\u2028') {
        testFailed('#3: var arr = /\\s/.exec("\\u2028"); arr[0] === "\\u2028". Actual. ' + (arr && arr[0]));
    }
    var arr = /\s/.exec('\u2029');
    YxaK = YxaK.values(YxaK);
    arr = arr.forEach(function () {
    }, NaN);
    var hPPZ = new Int8Array([
        1e+81,
        9007199254740990,
        -5e-324,
        0,
        4294967296,
        -4294967296,
        1e+81,
        1.7976931348623157e+308,
        -5e-324
    ]);
    if (arr === null || arr[0] !== '\u2029') {
        testFailed('#4: var arr = /\\s/.exec("\\u2029"); arr[0] === "\\u2029". Actual. ' + (arr && arr[0]));
    }
} catch (ex) {
    sputnikException = ex;
}
var successfullyParsed = true;