function main() {
    const v3 = [
        13.37,
        13.37,
        13.37
    ];
    v3[1337] = parseFloat;
    const v5 = [
        1337,
        1337,
        1337,
        1337
    ];
    const v6 = {
        d: v3,
        b: 2,
        __proto__: v5
    };
    const v7 = { toString: v6 };
    const v10 = [v7];
    let v11 = 13.37;
    function v12(v13, v14) {
        let v20 = 0;
        return v14;
    }
    const v21 = JSON.stringify(v10, v12, v11);
}
main();