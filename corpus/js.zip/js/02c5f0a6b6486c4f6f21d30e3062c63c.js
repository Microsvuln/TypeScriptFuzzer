function main() {
    let v2 = 0;
    while (v2 < 10) {
        const v4 = [13.37];
        const v7 = [
            13.37,
            13.37,
            13.37,
            13.37,
            13.37
        ];
        const v8 = [];
        let v9 = v8;
        function v10(v11, v12) {
            for (const v13 in v12) {
                throw v4;
            }
            function v15(v16, v17) {
                'use strict';
            }
            const v18 = {
                defineProperty: v15,
                get: isNaN,
                apply: isNaN,
                getPrototypeOf: v15,
                getOwnPropertyDescriptor: isNaN,
                call: isNaN,
                deleteProperty: v15,
                construct: isNaN,
                preventExtensions: isNaN,
                isExtensible: v15,
                setPrototypeOf: isNaN,
                set: v15
            };
            with (v12) {
            }
            for (let v22 = -65537; v22 < 8; v22++) {
            }
        }
        const v23 = [];
        let v24 = v23;
        const v25 = v10(...v24, v9, ...v7, 1337, 13.37);
        let v29 = 0;
        const v30 = v29 + 1;
        v29 = v30;
        const v34 = [];
        let v37 = 0;
        const v38 = v37 + 1;
        v37 = v38;
        let v41 = 0;
        const v42 = v41 + 1;
        v41 = v42;
        const v45 = v2 + 1;
        v2 = v45;
    }
}
main();