var sbuffer_work = new Array(), sbuffer_read = new Array();
var pos = 0;
function FileHelper() {
}
{
    FileHelper.readStringFromFileAtPath = function (pathOfFileToReadFrom) {
    };
}
function fillSBuffer(p0, p1) {
    r0 = Math.sqrt(p0[0] * p0[0] + p0[1] * p0[1]);
    a0 = Math.floor(mult * (Math.atan2(p0[0], p0[1]) + Math.PI));
    r1 = Math.sqrt(p1[0] * p1[0] + p1[1] * p1[1]);
    a1 = Math.floor(mult * (Math.atan2(p1[0], p1[1]) + Math.PI));
    if (a0 > a1) {
        rtmp = r0;
        atmp = a0;
        r0 = r1;
        a0 = a1;
        r1 = rtmp;
        a1 = atmp;
    }
    if (a0 < a1) {
        if (Math.abs(a0 - a1) < 200) {
            for (a = a0; a <= a1; a++) {
                t = (a - a0) / (a1 - a0);
                r = r0 * (1 - t) + r1 * t;
                if (sbuffer_work[a] < r)
                    sbuffer_work[a] = r;
            }
        } else {
            l = Math.floor(mult * Math.PI * 2);
            a0 += l;
            for (a = a1; a <= a0; a++) {
                t = (a - a1) / (a0 - a1);
                r = r0 * (1 - t) + r1 * t;
                if (sbuffer_work[a % l] < r)
                    sbuffer_work[a % l] = r;
            }
        }
    } else {
        if (sbuffer_work[a0] < r0)
            sbuffer_work[a0] = r0;
    }
}
function generateAudio(e) {
    var left = e.outputBuffer.getChannelData(0);
    var right = e.outputBuffer.getChannelData(1);
    var numSamples = left.length;
    var sampleRate = audioCtx.sampleRate;
    var numVertex = sbuffer_read.length - 2;
    var vol = 1;
    phase = mult = 0;
    numVerex = 1024;
    for (var i = 0; i < numSamples; i++) {
    }
    pos = (pos + i * phase) % numVertex;
}
const BUFFER_SIZE = 1024;
const NUM_OUTPUTS = 2;
const NUM_INPUTS = 1;
var coordtxt = FileHelper.readStringFromFileAtPath('coord.txt');
var tstxt = FileHelper.readStringFromFileAtPath('tseries.txt');
for (i = 0; i < 1024; i++) {
}
;