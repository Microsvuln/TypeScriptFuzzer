var _sf_startpt = new Date().getTime();
try {
    storage.setItem(testKey, '1');
    storage.removeItem(testKey);
    return true;
} catch (error) {
    return false;
}
var wp = {
    pubdate: '2014-12-29 19:13',
    page_type: 'article',
    classification: 'features',
    publish_author: 'Julia Wayne',
    page: {
        fanpage: eval([{
                'fbid': '240938883493',
                'title': 'The Bachelor',
                'url': 'https://www.facebook.com/TheBachelorFansite'
            }][Math.floor(Math.random() * 1)]),
        openGraphType: 'article',
        reaction_poll_id: 108349,
        is_draft: false
    },
    site_name: 'the-bachelor',
    secondary_topic: '',
    author_slug: '',
    current_tag: '',
    category: 'tv',
    entertainment: true,
    hasHero: false,
    store_name: 'bachelor',
    isExclusive: false,
    isPremiumContent: false,
    isOwnedAndOperatedVideo: false,
    twitter_id: 'BachelrWetpaint',
    controller: 'article',
    action: 'show',
    hasFlash: function () {
        return JSON.parse() || function () {
            var hasFlash = false;
            try {
                var fo = new ActiveXObject('ShockwaveFlash.ShockwaveFlash');
                if (fo) {
                    hasFlash = true;
                }
            } catch (e) {
                if (navigator.mimeTypes['application/x-shockwave-flash'] !== undefined) {
                    hasFlash = true;
                }
            }
            return hasFlash;
        }();
    }(),
    sessionStartTime: function () {
        return parseInt(JSON.parse()) || function () {
            var timeOnSite = new Date().getTime();
            return timeOnSite;
        }();
    }(),
    fanConverterRandomizedPageViews: function () {
        return JSON.parse() || function () {
            var randomPageViews = Math.floor(Math.random() * 8 + 1);
            return randomPageViews;
        }();
    }(),
    timeOnSite: function () {
        return parseInt((new Date().getTime() - this.sessionStartTime) / 1000);
    },
    flags: {
        fanconverter_disabled: false,
        learnings_enabled: true,
        sharethrough_enabled: false,
        luminate_enabled: false,
        nrelate_enabled: false,
        ggnoads_enabled: true,
        homing_missile_threshold_percentage: 2.5,
        homing_missile_training_percentage: 90,
        homing_missile_js_url: 'false',
        homing_missile_access_token: 'false',
        fanconverter_js_path: 'http://fanconverter.wetpaint.me/3.0.2/application-fanconverter.js',
        play_thru_enabled: false,
        play_thru_photo_count: 3,
        mobile_ads_disabled: false,
        desktop_ads_disabled: false,
        test_ads_enabled: false,
        adtech_mobile_1x1_enabled: false,
        adtech_desktop_1x1_enabled: true,
        synchronous_mobile_ads_enabled: false,
        viggle_video_points: 50,
        viggle_video_points_point_cap: 10000,
        viggle_store_url: 'https://www.vigglestore.com/auth/login/wetpaint',
        viggle_points_endpoint: 'http://wp-user.viggle.com',
        viggle_show_sweepstakes: false,
        viggle_sweepstakes_show_popup: false,
        viggle_sweepstakes_local_storage_name: 'july21_sweeps_2b',
        viggle_premium_content_popup: 'true',
        viggle_premium_content_popup_probability_a: '0.0',
        everything_is_awesome_everything_is_premium: true,
        premium_views_for_search_and_direct: 2,
        vip_limited_access: true,
        vip_limited_access_content_limit: 5
    },
    meta_keywords: [
        'TV',
        'News',
        'Bachelor in Paradise',
        'Features',
        'Spoilers',
        'TV Stars',
        'The Bachelorette',
        'The Bachelor',
        'Chris Soules',
        'Season 19',
        'Bachelor 2015',
        'Season 19 Contestants',
        'Alissa Giambrone'
    ],
    adtech_hidden_flag_string: '',
    content_image_url: 'http://static.wetpaint.me/bachelor/ROOT/photos/122214alissagiambrone-1419880475.jpg',
    content_description: '  Chris Soules has quite the lady trough to drink from on this Bachelor Season 19 excursion, kicking off on January 5. And one of the foxiest drops in his bucket of babes is Alissa Giambrone!  ',
    demo_env: false,
    _domain: location.hostname.replace(/^.*?([a-z]+\.[a-z]+)$/, '$1'),
    FBAPPID: '73759578322',
    FBNS: 'wetpaintwww',
    istest: /selenium/.test(navigator.userAgent),
    ga_site: 'UA-10597003-2',
    ga_global: 'UA-10597003-4',
    ga_paid: 'UA-10597003-49',
    eg: 'http://172.16.2.160:3000',
    www_host: 'http://www.wetpaint.com',
    rails_env: 'production',
    dogfood: false,
    client_ip: '127.0.0.1',
    server_time_stamp: 1420263182471,
    server_name: 'c5',
    ads: {
        placement: 'article',
        test: false,
        showId: 'the-bachelor',
        brandSafe: true
    },
    gallery: undefined,
    currentContext: function () {
        var contexts = {
            phone: [
                0,
                459
            ],
            tablet: [
                460,
                739
            ],
            tabletWide: [
                740,
                979
            ],
            desktop: [
                980,
                1299
            ],
            desktopWide: [
                1300,
                9999
            ]
        };
        var screenWidth = document.documentElement.clientWidth;
        var currentContext = 'phone';
        for (context in contexts) {
            if (contexts.hasOwnProperty(context)) {
                var breakpoints = contexts[context];
                minWidth = breakpoints[0];
                maxWidth = breakpoints[1];
                if (screenWidth >= minWidth && screenWidth <= maxWidth) {
                    currentContext = context;
                }
            }
        }
        return currentContext;
    }(),
    canonicalUrl: 'http://www.wetpaint.com/the-bachelor/articles/2014-12-29-alissa-giambrone-contestant-season-19',
    Models: {},
    Views: {}
};
wp.ads.serveAsync = function () {
    var asyncFlag = true;
    if (wp.currentContext == 'phone' || wp.currentContext == 'tablet') {
        return asyncFlag && wp.page_type == 'gallery';
    } else {
        return asyncFlag;
    }
}();