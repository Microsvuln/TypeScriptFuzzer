function main() {
    const v2 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v3 = [];
    let v4 = v3;
    function v5(v6, v7) {
        let v13 = 0;
        while (v13 < 10) {
            for (let v17 = 0; v17 < 8; v17++) {
                const v19 = [
                    1337,
                    1337,
                    1337
                ];
                let v22 = 0;
                while (v22 < 10) {
                    const v25 = new Float32Array(0);
                    for (const v26 in v19) {
                        v25.toString = Symbol;
                    }
                    const v27 = v22 + 1;
                    v22 = v27;
                }
            }
            const v28 = v13 + 1;
            v13 = v28;
        }
    }
    const v29 = [];
    let v30 = v29;
    const v31 = v5(...v30, v4, ...v2, 10, 13.37);
}
main();