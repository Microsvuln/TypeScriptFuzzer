var _qsAbortNext = false;
var _tipsIdx = 0;
var _tipIds;
function clearQsTips() {
    document.getElementById('quicksearch_tips').innerHTML = '';
}
function hideQsTips() {
    setTimeout('document.getElementById(\'quicksearch_tips\').style.display = \'none\'', 100);
}
function showQsTips() {
    document.getElementById('quicksearch_tips').style.display = '';
}
function qsTipsVisible() {
    return document.getElementById('quicksearch_tips').style.display != 'none';
}
function updateQsTips(evt) {
    if (qsTipsVisible() && evt && (evt.keyCode == 40 || evt.keyCode == 38 || evt.keyCode == 13)) {
        switch (evt.keyCode) {
        case 38:
        case 40:
            if (_tipsIdx >= 0)
                document.getElementById(_tipIds[_tipsIdx]).style.backgroundColor = '';
            evt.keyCode == 38 ? _tipsIdx-- : _tipsIdx++;
            if (_tipsIdx > _tipIds.length)
                _tipsIdx = 0;
            if (_tipsIdx < 0)
                _tipsIdx = _tipIds.length - 1;
            if (_tipsIdx >= 0)
                document.getElementById(_tipIds[_tipsIdx]).style.backgroundColor = '#ddd';
            break;
        case 13:
            if (_tipsIdx >= 0 && _tipIds[_tipsIdx]) {
                document.location.replace('#' + _tipIds[_tipsIdx].substr(3));
            }
            break;
        }
        return;
    }
    _tipsIdx = -1;
    _tipIds = [];
    var str = document.getElementById('quicksearch').value.toLowerCase();
    var matches = {};
    var match = false;
    if (str) {
        if ('_basequery'.indexOf(str) != -1) {
            match = true;
            matches['qs_attr__baseQuery'] = '_baseQuery';
        }
        if ('_db'.indexOf(str) != -1) {
            match = true;
            matches['qs_attr__db'] = '_db';
        }
        if ('_limit'.indexOf(str) != -1) {
            match = true;
            matches['qs_attr__limit'] = '_limit';
        }
        if ('_offset'.indexOf(str) != -1) {
            match = true;
            matches['qs_attr__offset'] = '_offset';
        }
        if ('_position'.indexOf(str) != -1) {
            match = true;
            matches['qs_attr__position'] = '_position';
        }
        if ('_records'.indexOf(str) != -1) {
            match = true;
            matches['qs_attr__records'] = '_records';
        }
        if ('_columnnames'.indexOf(str) != -1) {
            match = true;
            matches['qs_attr__columnNames'] = '_columnNames';
        }
        if ('_numrecords'.indexOf(str) != -1) {
            match = true;
            matches['qs_attr__numRecords'] = '_numRecords';
        }
        if ('_query'.indexOf(str) != -1) {
            match = true;
            matches['qs_attr__query'] = '_query';
        }
        if ('sra_resultset'.indexOf(str) != -1) {
            match = true;
            matches['qs_method_SRA_ResultSet'] = 'SRA_ResultSet';
        }
        if ('add'.indexOf(str) != -1) {
            match = true;
            matches['qs_method_add'] = 'add';
        }
        if ('count'.indexOf(str) != -1) {
            match = true;
            matches['qs_method_count'] = 'count';
        }
        if ('eof'.indexOf(str) != -1) {
            match = true;
            matches['qs_method_eof'] = 'eof';
        }
        if ('getcount'.indexOf(str) != -1) {
            match = true;
            matches['qs_method_getCount'] = 'getCount';
        }
        if ('getdelimitedresults'.indexOf(str) != -1) {
            match = true;
            matches['qs_method_getDelimitedResults'] = 'getDelimitedResults';
        }
        if ('gettotalcount'.indexOf(str) != -1) {
            match = true;
            matches['qs_method_getTotalCount'] = 'getTotalCount';
        }
        if ('isvalid'.indexOf(str) != -1) {
            match = true;
            matches['qs_method_isValid'] = 'isValid';
        }
        if ('next'.indexOf(str) != -1) {
            match = true;
            matches['qs_method_next'] = 'next';
        }
        if ('reset'.indexOf(str) != -1) {
            match = true;
            matches['qs_method_reset'] = 'reset';
        }
        if ('seek'.indexOf(str) != -1) {
            match = true;
            matches['qs_method_seek'] = 'seek';
        }
        if ('sra_workflow'.indexOf(str) != -1) {
            match = true;
            matches['qs_class_SRA_Workflow'] = 'SRA_Workflow';
        }
        if ('sra_workflowconstraint'.indexOf(str) != -1) {
            match = true;
            matches['qs_class_SRA_WorkflowConstraint'] = 'SRA_WorkflowConstraint';
        }
        if ('sra_workflowconstraintgroup'.indexOf(str) != -1) {
            match = true;
            matches['qs_class_SRA_WorkflowConstraintGroup'] = 'SRA_WorkflowConstraintGroup';
        }
        if ('sra_workflowdecision'.indexOf(str) != -1) {
            match = true;
            matches['qs_class_SRA_WorkflowDecision'] = 'SRA_WorkflowDecision';
        }
        if ('sra_workflowmanager'.indexOf(str) != -1) {
            match = true;
            matches['qs_class_SRA_WorkflowManager'] = 'SRA_WorkflowManager';
        }
        if ('sra_workflowstep'.indexOf(str) != -1) {
            match = true;
            matches['qs_class_SRA_WorkflowStep'] = 'SRA_WorkflowStep';
        }
        if ('sra_workflowtask'.indexOf(str) != -1) {
            match = true;
            matches['qs_class_SRA_WorkflowTask'] = 'SRA_WorkflowTask';
        }
        if ('workflow.dtd'.indexOf(str) != -1) {
            match = true;
            matches['qs_dtd_workflow.dtd'] = 'workflow.dtd';
        }
        if ('etc'.indexOf(str) != -1) {
            match = true;
            matches['qs_package_etc'] = 'etc';
        }
        if ('etc.l10n'.indexOf(str) != -1) {
            match = true;
            matches['qs_package_etc.l10n'] = 'etc.l10n';
        }
        if ('auth'.indexOf(str) != -1) {
            match = true;
            matches['qs_package_auth'] = 'auth';
        }
        if ('core'.indexOf(str) != -1) {
            match = true;
            matches['qs_package_core'] = 'core';
        }
        if ('model'.indexOf(str) != -1) {
            match = true;
            matches['qs_package_model'] = 'model';
        }
        if ('sql'.indexOf(str) != -1) {
            match = true;
            matches['qs_package_sql'] = 'sql';
        }
        if ('test'.indexOf(str) != -1) {
            match = true;
            matches['qs_package_test'] = 'test';
        }
        if ('util'.indexOf(str) != -1) {
            match = true;
            matches['qs_package_util'] = 'util';
        }
        if ('util.installer'.indexOf(str) != -1) {
            match = true;
            matches['qs_package_util.installer'] = 'util.installer';
        }
        if ('util.l10n'.indexOf(str) != -1) {
            match = true;
            matches['qs_package_util.l10n'] = 'util.l10n';
        }
        if ('workflow'.indexOf(str) != -1) {
            match = true;
            matches['qs_package_workflow'] = 'workflow';
        }
    }
    if (match) {
        var html = '';
        for (var i in matches) {
            _tipIds.push(i);
            html += '<div id="' + i + '" style="background-color: white; cursor: pointer;" onclick="document.location.replace(\'#\' + this.id.substr(3))">' + matches[i] + '</div>\n';
        }
        document.getElementById('quicksearch_tips').innerHTML = html;
        showQsTips();
    } else {
        hideQsTips();
    }
}