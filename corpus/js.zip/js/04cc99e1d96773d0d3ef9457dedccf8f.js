function main() {
    const v6 = [
        1337,
        1337
    ];
    const v7 = [1337];
    const v8 = {
        e: v7,
        a: v7,
        valueOf: 1337,
        b: v6,
        constructor: 1337
    };
    try {
        const v11 = [
            13.37,
            13.37,
            13.37,
            13.37,
            13.37
        ];
        const v12 = [];
        let v13 = v12;
        function v14(v15, v16) {
            v11.toString = v14;
            const v19 = [
                2.2250738585072014e-308,
                2.2250738585072014e-308,
                2.2250738585072014e-308,
                v16,
                2.2250738585072014e-308
            ];
            const v20 = [];
            let v21 = v20;
            function v22(v23, v24) {
                const v25 = v8 - v11;
            }
            const v26 = [];
            let v27 = v26;
            const v33 = [1337];
            const v34 = [
                v33,
                Map,
                Map,
                v33
            ];
            const v36 = {};
            const v37 = [
                v36,
                v34
            ];
            const v38 = v37.copyWithin(10, 10, 10);
            const v41 = { set: Symbol };
            const v43 = Object.fromEntries(v38, 1337, v41);
            const v44 = v22(...v27, v21, ...v19, 9007199254740992, 2.2250738585072014e-308);
        }
        const v45 = [];
        let v46 = v45;
        const v47 = v14(...v46, v13, ...v11, 1337, 13.37);
    } catch (v48) {
    }
}
main();