function main() {
    let v5 = 0;
    for (let v9 = 0; v9 < 10; v9++) {
        const v12 = [
            1337,
            1337,
            1337,
            1337,
            1337
        ];
        const v13 = {
            b: 1337,
            a: v12,
            valueOf: 1337,
            e: 1337,
            d: Symbol
        };
        with (v13) {
            let v16 = 0;
            while (v16 < 10) {
                function v17(v18, v19, v20, v21, ...v22) {
                    const v25 = [
                        1337,
                        1337,
                        1337,
                        1337,
                        1337
                    ];
                    const v26 = {
                        b: 1337,
                        a: v25,
                        valueOf: 1337,
                        e: 1337,
                        d: Symbol
                    };
                }
                for (let v30 = 0; v30 < 10; v30++) {
                    const v31 = v17();
                }
                const v32 = v16 + 1;
                v16 = v32;
            }
        }
    }
}
main();