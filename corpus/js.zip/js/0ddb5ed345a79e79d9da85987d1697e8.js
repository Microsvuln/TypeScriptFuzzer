function main() {
    const v4 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v5 = [];
    let v6 = v5;
    function v7(v8, v9) {
        const v12 = [
            100,
            425598.49603206525,
            425598.49603206525,
            425598.49603206525,
            425598.49603206525
        ];
        const v13 = [];
        let v14 = v13;
        function v15(v16, v17) {
            for (let v21 = 0; v21 < 10000; v21++) {
                const v24 = [
                    v17,
                    3232391318
                ];
                let v25 = String;
                let v26 = v21;
                const v27 = v25.fromCharCode(v26, v16, String, v21, v24);
                const v28 = parseFloat(v27);
            }
        }
        const v29 = [];
        let v30 = v29;
        const v31 = v15(...v30, ...v14, ...v12, -256, 425598.49603206525);
    }
    const v32 = [];
    let v33 = v32;
    const v34 = v7(...v33, v6, ...v4, 10, 13.37);
}
main();