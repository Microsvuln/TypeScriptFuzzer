function main() {
    let v3 = 0;
    do {
        const v7 = [];
        v7[10] = Symbol;
        const v11 = v7.unshift(Symbol);
        const v12 = v3 + 1;
        v3 = v12;
    } while (v3 < 4);
    let v18 = 0;
    const v19 = v18 + 1;
    v18 = v19;
}
main();