(function () {
    var t0 = Date.now();
    var id = new Uint8Array(256 * 256 * 4);
    id.width = 256;
    id.height = 256;
    for (var y = 0; y < 256; y++) {
        for (var x = 0; x < 256; x++) {
            var off = y * 256 + x | 0;
            var off2 = (y + 17) % 256 * 256 + (x + 37) % 256 | 0;
            var v = 256 * Math.random() | 0;
            id[off * 4] = id[off2 * 4 + 1] = v;
            id[off * 4 + 2] = 256 * Math.random() | 0;
            id[off * 4 + 3] = 256 * Math.random() | 0;
        }
    }
        console.log('Create random texture: ' + (Date.now() - t0) + ' ms');
    t0 = Date.now();
    var gl;
    try {
        gl = glc.getContext('webgl');
        if (!gl) {
            gl = glc.getContext('experimental-webgl');
        }
    } catch (e) {
    }
    if (!gl) {
        return;
    }
    gl.clearColor(1, 1, 1, 1);
    var ext = gl.getExtension('OES_texture_float');
    if (DEBUG)
        console.log('WebGL context creation: ' + (Date.now() - t0) + ' ms');
    t0 = Date.now();
}());