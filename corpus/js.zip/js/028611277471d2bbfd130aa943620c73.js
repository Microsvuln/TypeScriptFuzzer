function main() {
    const v2 = [
        -2.220446049250313e-16,
        -2.220446049250313e-16,
        -2.220446049250313e-16,
        -2.220446049250313e-16,
        -2.220446049250313e-16
    ];
    const v4 = [
        v2,
        v2,
        v2,
        -2147483647
    ];
    const v5 = {
        d: 1337,
        constructor: v2,
        e: 1337,
        c: v4,
        length: -2.220446049250313e-16
    };
    const v9 = [
        13.37,
        10,
        13.37,
        13.37,
        13.37
    ];
    const v10 = [];
    let v11 = v10;
    function v12(v13, v14) {
        const v17 = [
            13.37,
            13.37,
            13.37,
            13.37,
            13.37
        ];
        let v18 = v14;
        function v19(v20, v21) {
            const v24 = [
                1337,
                1337
            ];
            const v25 = [1337];
            const v26 = {
                e: 1337,
                __proto__: v24,
                toString: 13.37,
                d: v25
            };
            const v28 = 128 .toLocaleString(128, 128, v26, v24, v25);
            'object'[v28] = v28;
        }
        const v29 = [];
        let v30 = v29;
        const v31 = v19(...v30, v18, ...v17, 1337, 13.37);
    }
    const v32 = [];
    let v33 = v32;
    const v34 = v12(...v33, v11, ...v9, 10, 13.37);
    const v37 = new Int8Array(1337);
    const v39 = {
        constructor: v5,
        d: v37
    };
    const v42 = [
        v39,
        1337,
        1337
    ];
    const v43 = {
        toString: v42,
        c: 'e'
    };
    const v44 = [v43];
    const v45 = [v44];
    const v46 = [v45];
    const v48 = JSON.stringify(v46, JSON, v45);
    const v49 = eval(v48);
}
main();