function main() {
    const v2 = [
        13.37,
        13.37,
        13.37,
        13.37,
        13.37
    ];
    const v3 = [];
    let v4 = v3;
    function v5(v6, v7) {
        let v11 = 0;
        while (v11 < 8) {
            const v12 = v11 + 1;
            let v16 = 0;
            while (v16 < 4) {
                const v17 = 'p76QI.ipnu'.constructor;
                let v23 = 0;
                const v24 = 'p76QI.ipnu'.constructor;
                for (let v28 = 0; v28 < 8; v28++) {
                    const v30 = Object(v28);
                    const v31 = 0 > v24;
                    v30.toString = Object;
                }
                const v32 = v23 + 1;
                v23 = v32;
                const v33 = v17.split;
                const v34 = Symbol[v33];
                const v35 = v16 + 1;
                v16 = v35;
                let v37 = 0;
            }
            v11 = v12;
        }
        let v39 = 0;
        while (v39 < 10) {
            for (let v43 = 0; v43 < 8; v43++) {
                for (let v47 = 0; v47 < 5; v47++) {
                }
            }
            const v48 = v39 + 1;
            v39 = v48;
        }
    }
    const v49 = [];
    let v50 = v49;
    const v51 = v5(...v50, v4, ...v2, 10, 13.37);
}
main();